!(function (e, t) {
  "object" == typeof exports && "undefined" != typeof module
    ? (module.exports = t())
    : "function" == typeof define && define.amd
    ? define(t)
    : ((e = "undefined" != typeof globalThis ? globalThis : e || self).gdp =
        t());
})(this, function () {
  "use strict";
  const e = ["web", "wxwv", "minp", "alip", "baidup", "qq", "bytedance"],
    t = {
      autotrack: {
        type: "boolean",
        default: !0,
      },
      compress: {
        type: "boolean",
        default: !0,
      },
      dataCollect: {
        type: "boolean",
        default: !0,
      },
      debug: {
        type: "boolean",
        default: !1,
      },
      hashtag: {
        type: "boolean",
        default: !1,
      },
      touch: {
        type: "boolean",
        default: !1,
      },
      version: {
        type: "string",
        default: "1.0.0",
      },
      platform: {
        type: "string",
        default: "web",
      },
      cookieDomain: {
        type: "string",
        default: "",
      },
    },
    i = {
      enableIdMapping: {
        type: "boolean",
        default: !1,
      },
      gtouchHost: {
        type: "string",
        default: "",
      },
      host: {
        type: "string",
        default: "",
      },
      ignoreFields: {
        type: "array",
        default: [],
      },
      penetrateHybrid: {
        type: "boolean",
        default: !0,
      },
      scheme: {
        type: "string",
        default:
          location.protocol.indexOf("http") > -1
            ? location.protocol.replace(":", "")
            : "https",
      },
      sessionExpires: {
        type: "number",
        default: 30,
      },
      performance: {
        type: "object",
        default: {
          monitor: !0,
          exception: !0,
        },
      },
      embeddedIgnore: {
        type: "array",
        default: [],
      },
    },
    n = {},
    r = [
      "clearUserId",
      "getGioInfo",
      "getLocation",
      "getOption",
      "init",
      "setDataCollect",
      "setOption",
      "setUserId",
      "track",
      "setGeneralProps",
      "clearGeneralProps",
      "enableDebug",
      "enableHT",
      "setAutotrack",
      "setTrackerHost",
      "setTrackerScheme",
      "setUserAttributes",
      "getVisitorId",
      "getDeviceId",
      "registerPlugins",
      "getPlugins",
      "sendPage",
      "sendVisit",
      "trackTimerStart",
      "trackTimerPause",
      "trackTimerResume",
      "trackTimerEnd",
      "removeTimer",
      "clearTrackTimer",
    ],
    s = [
      "autotrack",
      "dataCollect",
      "dataSourceId",
      "debug",
      "host",
      "hashtag",
      "scheme",
    ],
    o = {
      autotrack: "无埋点采集",
      dataCollect: "数据采集",
      debug: "调试模式",
    },
    a = ["send", "setConfig", "collectImp", "setPlatformProfile"],
    d = ["screenHeight", "screenWidth"],
    l = {
      click: "VIEW_CLICK",
      change: "VIEW_CHANGE",
      submit: "FORM_SUBMIT",
    };
  var c,
    h,
    u,
    g,
    p,
    f,
    m,
    v =
      "undefined" != typeof globalThis
        ? globalThis
        : "undefined" != typeof window
        ? window
        : "undefined" != typeof global
        ? global
        : "undefined" != typeof self
        ? self
        : {},
    I =
      "function" == typeof Array.from
        ? Array.from
        : (h ||
            ((h = 1),
            (u = function (e) {
              return "function" == typeof e;
            }),
            (g = function (e) {
              var t = (function (e) {
                var t = Number(e);
                return isNaN(t)
                  ? 0
                  : 0 !== t && isFinite(t)
                  ? (t > 0 ? 1 : -1) * Math.floor(Math.abs(t))
                  : t;
              })(e);
              return Math.min(Math.max(t, 0), 9007199254740991);
            }),
            (p = function (e) {
              if (null != e) {
                if (
                  ["string", "number", "boolean", "symbol"].indexOf(typeof e) >
                  -1
                )
                  return Symbol.iterator;
                if (
                  "undefined" != typeof Symbol &&
                  "iterator" in Symbol &&
                  Symbol.iterator in e
                )
                  return Symbol.iterator;
                if ("@@iterator" in e) return "@@iterator";
              }
            }),
            (f = function (e, t) {
              if (null != e && null != t) {
                var i = e[t];
                if (null == i) return;
                if (!u(i)) throw new TypeError(i + " is not a function");
                return i;
              }
            }),
            (m = function (e) {
              var t = e.next();
              return !t.done && t;
            }),
            (c = function (e) {
              var t,
                i,
                n,
                r = this,
                s = arguments.length > 1 ? arguments[1] : void 0;
              if (void 0 !== s) {
                if (!u(s))
                  throw new TypeError(
                    "Array.from: when provided, the second argument must be a function"
                  );
                arguments.length > 2 && (t = arguments[2]);
              }
              var o = f(e, p(e));
              if (void 0 !== o) {
                i = u(r) ? Object(new r()) : [];
                var a,
                  d,
                  l = o.call(e);
                if (null == l)
                  throw new TypeError(
                    "Array.from requires an array-like or iterable object"
                  );
                for (n = 0; ; ) {
                  if (!(a = m(l))) return (i.length = n), i;
                  (d = a.value), (i[n] = s ? s.call(t, d, n) : d), n++;
                }
              } else {
                var c = Object(e);
                if (null == e)
                  throw new TypeError(
                    "Array.from requires an array-like object - not null or undefined"
                  );
                var h,
                  v = g(c.length);
                for (i = u(r) ? Object(new r(v)) : Array(v), n = 0; v > n; )
                  (h = c[n]), (i[n] = s ? s.call(t, h, n) : h), n++;
                i.length = v;
              }
              return i;
            })),
          c);
  const w = (e) => L(["undefined", "null"], X(e)),
    O = (e) => "string" === X(e),
    b = (e) => "number" === X(e),
    y = (e) => {
      const t = Number(e);
      return t != t;
    },
    E = (e) => "boolean" === X(e),
    S = (e) => "object" === X(e) && !w(e),
    _ = (e) => "regexp" === X(e),
    T = (e) => "function" === X(e),
    N = (e) => Array.isArray(e) && "array" === X(e),
    C = (e) => "date" === X(e),
    A = (e) => {
      try {
        return k(e)[0];
      } catch (e) {
        return;
      }
    },
    x = (e) => {
      try {
        const t = k(e);
        return t[t.length - 1];
      } catch (e) {
        return;
      }
    },
    P = (e, t = 1) => (N(e) && b(t) ? e.slice(t > 0 ? t : 1, e.length) : e),
    D = (e) => {
      if (N(e)) {
        let t = 0;
        const i = [];
        for (const n of e) n && !$(n) && (i[t++] = n);
        return i;
      }
      return e;
    },
    R = (e, t) => {
      let i;
      return (
        N(e) &&
          e.forEach((e) => {
            t(e) && void 0 === i && (i = e);
          }),
        i
      );
    },
    L = (e, t) => ("array" === X(e) || "string" === X(e)) && e.indexOf(t) >= 0,
    k = I,
    j = (e) => (w(e) ? "" : "" + e),
    U = (e, t) => ("string" == typeof e ? e.split(t) : e),
    G = (e) => {
      if (O(e)) {
        const t = U(e, "");
        return `${A(t).toLowerCase()}${P(t).join("")}`;
      }
      return e;
    },
    q = (e, t) => !!O(e) && e.slice(0, t.length) === t,
    H = (e, t) => {
      if (O(e)) {
        const { length: i } = e;
        let n = i;
        n > i && (n = i);
        const r = n;
        return (n -= t.length), n >= 0 && e.slice(n, r) === t;
      }
      return !1;
    },
    B = {}.hasOwnProperty,
    K = (e, t) => !w(e) && B.call(e, t),
    V = (e) => (S(e) ? Object.keys(e) : []),
    W = (e, t) => {
      V(e).forEach((i) => t(e[i], i));
    },
    M = (e, t) => {
      const i = V(e);
      return !(
        !S(e) ||
        !S(t) ||
        i.length !== V(t).length ||
        L(
          i.map((i, n) => (S(e[i]) ? M(e[i], t[i]) : e[i] === t[i])),
          !1
        )
      );
    },
    F = (e, t) => {
      if (!S(e)) return !1;
      try {
        return "string" === X(t)
          ? delete e[t]
          : "array" === X(t)
          ? t.map((t) => delete e[t])
          : (_(t) &&
              V(e).forEach((i) => {
                t.test(i) && F(e, i);
              }),
            !0);
      } catch (e) {
        return !1;
      }
    },
    $ = (e) => (N(e) ? 0 === e.length : S(e) ? 0 === V(e).length : !e),
    X = (e) => ({}.toString.call(e).slice(8, -1).toLowerCase());
  var z = Object.freeze({
    __proto__: null,
    isNil: w,
    isString: O,
    isNumber: b,
    isNaN: y,
    isBoolean: E,
    isObject: S,
    isRegExp: _,
    isFunction: T,
    isArray: N,
    isDate: C,
    fixed: (e, t) =>
      b(e)
        ? Number(e.toFixed(b(t) ? t : 2))
        : O(e) && "NaN" !== j(Number(e))
        ? Number(Number(e).toFixed(b(t) ? t : 2))
        : e,
    head: A,
    last: x,
    drop: P,
    dropWhile: (e, t) => (N(e) ? e.filter((e) => !t(e)) : e),
    compact: D,
    find: R,
    includes: L,
    arrayFrom: k,
    toString: j,
    split: U,
    lowerFirst: G,
    upperFirst: (e) => {
      if (O(e)) {
        const t = U(e, "");
        return `${A(t).toUpperCase()}${P(t).join("")}`;
      }
      return e;
    },
    startsWith: q,
    endsWith: H,
    hasOwnProperty: B,
    has: K,
    keys: V,
    forEach: W,
    isEqual: M,
    get: (e, t, i) => {
      let n = e;
      return S(e)
        ? (t.split(".").forEach((e) => {
            n = n ? n[e] : i;
          }),
          n)
        : i;
    },
    unset: F,
    isEmpty: $,
    typeOf: X,
    formatDate: (e) => {
      if (C(e)) {
        const t = (e) => (10 > e ? "0" + e : e);
        return (
          e.getFullYear() +
          "-" +
          t(e.getMonth() + 1) +
          "-" +
          t(e.getDate()) +
          " " +
          t(e.getHours()) +
          ":" +
          t(e.getMinutes()) +
          ":" +
          t(e.getSeconds()) +
          "." +
          t(e.getMilliseconds())
        );
      }
      return e;
    },
  });
  const J = (e, t) => {
      console.log(
        "%c [GrowingIO]：" + e,
        {
          info: "color: #3B82F6;",
          error: "color: #EF4444;",
          warn: "color: #F59E0B;",
          success: "color: #10B981;",
        }[t] || ""
      );
    },
    Z = (e) => {
      try {
        return e();
      } catch (e) {
        return;
      }
    },
    Y = (e) => {
      const t = {};
      return (
        S(e) &&
          W(e, (e, i) => {
            var n;
            const r = j(i).slice(0, 100);
            S(e)
              ? (t[r] = Y(e))
              : N(e)
              ? ((t[r] = e.slice(0, 100)),
                "cdp" ===
                  (null === (n = window.vds) || void 0 === n
                    ? void 0
                    : n.gioEnvironment) && (t[r] = t[r].join("||")))
              : (t[r] = w(e) ? "" : j(e).slice(0, 1e3));
          }),
        t
      );
    },
    Q = (e, t, i, n = {}) => {
      document.addEventListener
        ? e.addEventListener(
            t,
            i,
            Object.assign(
              Object.assign(
                {},
                {
                  capture: !0,
                }
              ),
              n
            )
          )
        : e.attachEvent
        ? e.attachEvent("on" + t, i)
        : (e["on" + t] = i);
    },
    ee = (e, t) =>
      O(e) && !$(e) && e.match(/^[a-zA-Z_][0-9a-zA-Z_]{0,100}$/)
        ? t()
        : (J(
            "事件名格式不正确，只能包含数字、字母和下划线，且不能以数字开头，字符总长度不能超过100!",
            "error"
          ),
          !1);
  var te = Object.freeze({
    __proto__: null,
    consoleText: J,
    niceTry: Z,
    limitObject: Y,
    addListener: Q,
    flattenObject: (e = {}) => {
      const t = Object.assign({}, e);
      return (
        V(t).forEach((e) => {
          S(t[e])
            ? (V(t[e]).forEach((i) => {
                t[`${e}_${i}`] = j(t[e][i]);
              }),
              F(t, e))
            : N(t[e])
            ? (t[e].forEach((i, n) => {
                S(i)
                  ? V(i).forEach((r) => {
                      t[`${e}_${n}_${r}`] = j(i[r]);
                    })
                  : (t[`${e}_${n}`] = j(i));
              }),
              F(t, e))
            : w(t[e]) || "" === t[e]
            ? F(t, e)
            : (t[e] = j(t[e]));
        }),
        t
      );
    },
    eventNameValidate: ee,
  });
  const ie = (e) => (O(e) && e.length > 0) || (b(e) && e > 0),
    ne = (e) => {
      var t;
      return e.vdsConfig ||
        e.gioSDKInitialized ||
        (null === (t = window.vds) || void 0 === t
          ? void 0
          : t.gioSDKInitialized)
        ? (J(
            "SDK重复初始化，请检查是否重复加载SDK或接入其他平台SDK导致冲突!",
            "warn"
          ),
          !1)
        : !(
            L(["", "localhost", "127.0.0.1"], location.hostname) &&
            !window._gr_ignore_local_rule &&
            (J("当前SDK不允许在本地环境初始化!", "warn"), 1)
          );
    },
    re = (e) =>
      !$(D(e)) ||
      (J(
        'SDK初始化失败，请使用 gdp("init", "您的GrowingIO项目 accountId", "您项目的 dataSourceId", options); 进行初始化!',
        "error"
      ),
      !1),
    se = (e) => {
      const t = A(e);
      let i = x(e);
      return ie(j(t).trim())
        ? ((S(i) && i) || (i = {}),
          {
            projectId: t,
            userOptions: i,
          })
        : (J("SDK初始化失败，accountId 参数不合法!", "error"), !1);
    },
    oe = (e) => {
      const t = e[1],
        i = e[2],
        n = x(e);
      return t && O(t)
        ? S(n) && n.host
          ? {
              dataSourceId: t,
              appId: O(i) ? i : "",
              cdpOptions: n,
            }
          : (J("SDK初始化失败，未在配置中指定 host!", "error"), !1)
        : (J("SDK初始化失败，dataSourceId 参数不合法!", "error"), !1);
    },
    ae =
      /^((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})(\.((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})){3}/i,
    de =
      /^(https?:\/\/)|(([a-zA-Z0-9_-])+(\.)?)*(:\d+)?(\/((\.)?(\?)?=?&?[a-zA-Z0-9_-](\?)?)*)*$/i;
  var le = "SDK_INITIALIZED",
    ce = "USERID_UPDATE",
    he = "USERKEY_UPDATE",
    ue = "SESSIONID_UPDATE",
    ge = {},
    pe = {}.hasOwnProperty;

  function fe(e) {
    try {
      return decodeURIComponent(e.replace(/\+/g, " "));
    } catch (e) {
      return null;
    }
  }

  function me(e) {
    try {
      return encodeURIComponent(e);
    } catch (e) {
      return null;
    }
  }
  (ge.stringify = function (e, t) {
    t = t || "";
    var i,
      n,
      r = [];
    for (n in ("string" != typeof t && (t = "?"), e))
      if (pe.call(e, n)) {
        if (
          ((i = e[n]) || (null != i && !isNaN(i)) || (i = ""),
          (n = me(n)),
          (i = me(i)),
          null === n || null === i)
        )
          continue;
        r.push(n + "=" + i);
      }
    return r.length ? t + r.join("&") : "";
  }),
    (ge.parse = function (e) {
      for (var t, i = /([^=?#&]+)=?([^&]*)/g, n = {}; (t = i.exec(e)); ) {
        var r = fe(t[1]),
          s = fe(t[2]);
        null === r || null === s || r in n || (n[r] = s);
      }
      return n;
    });
  var ve = {
      name: "gioCompress",
      method: class {
        constructor(e) {
          (this.growingIO = e),
            (this._compress = function (e, t, i) {
              if (null === e) return "";
              let n,
                r,
                s,
                o = {},
                a = {},
                d = "",
                l = "",
                c = "",
                h = 2,
                u = 3,
                g = 2,
                p = [],
                f = 0,
                m = 0;
              for (s = 0; s < e.length; s += 1)
                if (
                  ((d = e.charAt(s)),
                  {}.hasOwnProperty.call(o, d) || ((o[d] = u++), (a[d] = !0)),
                  (l = c + d),
                  {}.hasOwnProperty.call(o, l))
                )
                  c = l;
                else {
                  if ({}.hasOwnProperty.call(a, c)) {
                    if (256 > c.charCodeAt(0)) {
                      for (n = 0; g > n; n++)
                        (f <<= 1),
                          m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++;
                      for (r = c.charCodeAt(0), n = 0; 8 > n; n++)
                        (f = (f << 1) | (1 & r)),
                          m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++,
                          (r >>= 1);
                    } else {
                      for (r = 1, n = 0; g > n; n++)
                        (f = (f << 1) | r),
                          m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++,
                          (r = 0);
                      for (r = c.charCodeAt(0), n = 0; 16 > n; n++)
                        (f = (f << 1) | (1 & r)),
                          m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++,
                          (r >>= 1);
                    }
                    h--, 0 === h && ((h = Math.pow(2, g)), g++), delete a[c];
                  } else
                    for (r = o[c], n = 0; g > n; n++)
                      (f = (f << 1) | (1 & r)),
                        m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++,
                        (r >>= 1);
                  h--,
                    0 === h && ((h = Math.pow(2, g)), g++),
                    (o[l] = u++),
                    (c = d + "");
                }
              if ("" !== c) {
                if ({}.hasOwnProperty.call(a, c)) {
                  if (256 > c.charCodeAt(0)) {
                    for (n = 0; g > n; n++)
                      (f <<= 1),
                        m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++;
                    for (r = c.charCodeAt(0), n = 0; 8 > n; n++)
                      (f = (f << 1) | (1 & r)),
                        m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++,
                        (r >>= 1);
                  } else {
                    for (r = 1, n = 0; g > n; n++)
                      (f = (f << 1) | r),
                        m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++,
                        (r = 0);
                    for (r = c.charCodeAt(0), n = 0; 16 > n; n++)
                      (f = (f << 1) | (1 & r)),
                        m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++,
                        (r >>= 1);
                  }
                  h--, 0 === h && ((h = Math.pow(2, g)), g++), delete a[c];
                } else
                  for (r = o[c], n = 0; g > n; n++)
                    (f = (f << 1) | (1 & r)),
                      m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++,
                      (r >>= 1);
                h--, 0 === h && ((h = Math.pow(2, g)), g++);
              }
              for (r = 2, n = 0; g > n; n++)
                (f = (f << 1) | (1 & r)),
                  m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++,
                  (r >>= 1);
              for (;;) {
                if (((f <<= 1), m === t - 1)) {
                  p.push(i(f));
                  break;
                }
                m++;
              }
              return p.join("");
            }),
            (this.compress = (e) => {
              const t = this;
              return this._compress(e, 16, function (e) {
                return t.f(e);
              });
            }),
            (this.compressToUTF16 = (e) => {
              const t = this;
              return null === e
                ? ""
                : this._compress(e, 15, function (e) {
                    return t.f(e + 32);
                  }) + " ";
            }),
            (this.compressToUint8Array = (e) => {
              const t = this.compress(e),
                i = new Uint8Array(2 * t.length);
              for (let e = 0, n = t.length; n > e; e++) {
                const n = t.charCodeAt(e);
                (i[2 * e] = n >>> 8), (i[2 * e + 1] = n % 256);
              }
              return i;
            }),
            (this.compressToEncodedURIComponent = (e) =>
              null == e
                ? ""
                : this._compress(e, 6, function (e) {
                    return this.keyStrUriSafe.charAt(e);
                  })),
            (this.f = String.fromCharCode),
            (this.keyStrUriSafe =
              "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-$");
        }
      },
    },
    Ie = {
      name: "gioCustomTracking",
      method: class {
        constructor(e) {
          (this.growingIO = e),
            (this.getValidResourceItem = (e) => {
              if (e && S(e) && e.id && e.key) {
                const t = {
                  id: O(e.id) ? e.id : j(e.id),
                  key: O(e.key) ? e.key : j(e.key),
                };
                return e.attributes && (t.attributes = e.attributes), t;
              }
            }),
            (this.getDynamicAttributes = (e) => (
              w(e) ||
                V(e).forEach((t) => {
                  T(e[t])
                    ? (e[t] = e[t]())
                    : S(e[t])
                    ? F(e, t)
                    : N(e[t]) || (e[t] = j(e[t]));
                }),
              e
            )),
            (this.buildCustomEvent = (e, t, i, n) => {
              ee(e, () => {
                const {
                  dataStore: {
                    eventContextBuilder: r,
                    eventConverter: s,
                    currentPage: o,
                  },
                } = this.growingIO;
                let a = Object.assign(
                  {
                    eventType: "CUSTOM",
                    eventName: e,
                    pageShowTimestamp: null == o ? void 0 : o.time,
                    attributes: Y(
                      this.getDynamicAttributes(S(t) && !$(t) ? t : void 0)
                    ),
                    resourceItem: Y(this.getValidResourceItem(i)),
                  },
                  r()
                );
                $(n) || (a = Object.assign(Object.assign({}, a), n)), s(a);
              });
            }),
            (this.buildUserAttributesEvent = (e, t) => {
              const {
                dataStore: { eventContextBuilder: i, eventConverter: n },
              } = this.growingIO;
              let r = Object.assign(
                {
                  eventType: "LOGIN_USER_ATTRIBUTES",
                  attributes: Y(e),
                },
                i()
              );
              $(t) || (r = Object.assign(Object.assign({}, r), t)), n(r);
            });
        }
      },
    };
  const we = {
      gioprojectid: "projectId",
      giodatacollect: "dataCollect",
      gioappid: "domain",
      giodatasourceid: "dataSourceId",
      gios: "sessionId",
      giou: "uid",
      giocs1: "userId",
      gioid: "gioId",
      giouserkey: "userKey",
      gioappchannel: "appChannel",
      giodevicebrand: "deviceBrand",
      giodevicemodel: "deviceModel",
      giodevicetype: "deviceType",
      giolanguage: "language",
      gionetworkstate: "networkState",
      giooperatingsystem: "operatingSystem",
      gioplatform: "platform",
      gioplatformversion: "platformVersion",
      gioscreenheight: "screenHeight",
      gioscreenwidth: "screenWidth",
    },
    Oe = [
      "giodatasourceid",
      "gioplatform",
      "gioappchannel",
      "giodevicebrand",
      "giodevicemodel",
      "giodevicetype",
      "giolanguage",
      "gionetworkstate",
      "giooperatingsystem",
      "gioplatformversion",
      "gioscreenheight",
      "gioscreenwidth",
    ],
    be = ["giocs1", "gios", "giou", "gioid", "giouserkey"],
    ye = "gio_search_cookie_gioenc";
  var Ee = {
      name: "gioEmbeddedAdapter",
      method: class {
        constructor(e) {
          (this.growingIO = e),
            (this.main = (e) => {
              var t;
              const { projectId: i, appId: n } = e,
                r = this.getGQS();
              let s = !1;
              return (
                "none" !== this.qsFrom &&
                  r.gioprojectid === i &&
                  r.gioappid === n &&
                  ($(r)
                    ? this.growingIO.storage.removeItem(ye)
                    : this.growingIO.storage.setItem(ye, ge.stringify(r)),
                  K(r, "giodatacollect") &&
                    (this.growingIO.vdsConfig.dataCollect = L(
                      ["true", !0],
                      r.giodatacollect
                    )),
                  null === (t = this.growingIO.emitter) ||
                    void 0 === t ||
                    t.on("SDK_INITIALIZED", () => {
                      const {
                        userStore: e,
                        vdsConfig: { sessionExpires: t },
                        dataStore: { eventContextBuilderInst: i },
                      } = this.growingIO;
                      be.forEach((t) => {
                        var i;
                        e[we[t]] = null !== (i = r[t]) && void 0 !== i ? i : "";
                      }),
                        window.setInterval(() => {
                          e.sessionId = r.gios;
                        }, 0.8 * t * 60 * 1e3),
                        Oe.forEach((e) => {
                          K(r, e) && (i.minpExtraParams[we[e]] = r[e]);
                        });
                    }),
                  (this.growingIO.setUserId = () => {}),
                  (this.growingIO.clearUserId = () => {}),
                  K(r, "giodatacollect") &&
                    ((this.growingIO.setDataCollect = () => {}),
                    (this.growingIO.setOption = () => {})),
                  (s = !0)),
                this.gioURLRewrite(),
                s
              );
            }),
            (this.getGQS = () => {
              const { hashtag: e } = this.growingIO.vdsConfig,
                t = this.growingIO.storage.getItem(ye),
                i = window.location.search,
                n = window.location.hash,
                r = e ? n.substring(n.indexOf("?") + 1) : "",
                s = ge.parse(i),
                o = ge.parse(r),
                a = ge.parse((t || "").replace("gioenc-", ""));
              let d = {};
              if (K(s, "gioprojectid")) (d = s), (this.qsFrom = "search");
              else if (K(o, "gioprojectid")) (d = o), (this.qsFrom = "hash");
              else {
                if (!K(a, "gioprojectid")) return (this.qsFrom = "none"), {};
                (d = a), (this.qsFrom = "cookie");
              }
              const l = {},
                c = {},
                h = [
                  "gioappid",
                  "gioprojectid",
                  "giodatacollect",
                  ...be,
                  ...Oe,
                ];
              return (
                V(d).forEach((e) => {
                  const t = e.toLowerCase();
                  L(h, t)
                    ? L(["", "undefined", "null", void 0, null], d[e]) ||
                      ((l[t] = d[e]),
                      L(["true", "TRUE", !0], d[e]) && (l[t] = !0),
                      L(["false", "FALSE", !1], d[e]) && (l[t] = !1))
                    : (c[e] = d[e]);
                }),
                (this.gqs = l),
                (this.ngqs = c),
                l
              );
            }),
            (this.gioURLRewrite = () => {
              const { hashtag: e } = this.growingIO.vdsConfig;
              let t = window.location.search,
                i = window.location.hash,
                n = !1;
              if (
                ("search" === this.qsFrom &&
                  ((t = ge.stringify(this.ngqs, !0)), (n = !0)),
                e &&
                  "hash" === this.qsFrom &&
                  ((i = `${i.split("?")[0]}${ge.stringify(this.ngqs, !0)}`),
                  (n = !0)),
                n)
              ) {
                const e = `${window.location.pathname}${t || ""}${i || ""}`;
                window.history.replaceState(null, document.title, e);
              }
            }),
            (this.gqs = {}),
            (this.ngqs = {}),
            (this.qsFrom = "search");
        }
      },
    },
    Se = {},
    _e = {};
  !(function (e) {
    var t =
      (v && v.__spreadArray) ||
      function (e, t, i) {
        if (i || 2 === arguments.length)
          for (var n, r = 0, s = t.length; s > r; r++)
            (!n && r in t) ||
              (n || (n = [].slice.call(t, 0, r)), (n[r] = t[r]));
        return e.concat(n || [].slice.call(t));
      };
    Object.defineProperty(e, "__esModule", {
      value: !0,
    }),
      (e.GROWING_TITLE_OLD =
        e.GROWING_TITLE =
        e.GROWING_GTITLE =
        e.GROWING_CDP_INDEX =
        e.GROWING_INDEX_OLD =
        e.GROWING_INDEX =
        e.GROWING_CONTAINER =
        e.GROWING_TRACK =
        e.GROWING_IGNORE =
        e.VALID_CLASS_SELECTOR =
        e.VALID_ID_SELECTOR =
        e.EXCLUDE_CLASS_RE =
        e.UNSUPPORTED_TAGS =
        e.TEXT_NODE =
        e.UNSUPPORTED_CLICK_TAGS =
        e.SUPPORTED_ICON_TAGS =
        e.SUPPORTED_CHANGE_TYPES =
        e.SUPPORTED_CLICK_INPUT_TYPES =
        e.SUPPORTED_CONTAINER_TAGS =
        e.LIST_TAGS =
          void 0),
      (e.LIST_TAGS = ["TR", "LI", "DL"]),
      (e.SUPPORTED_CONTAINER_TAGS = t(["A", "BUTTON"], e.LIST_TAGS, !0)),
      (e.SUPPORTED_CLICK_INPUT_TYPES = ["button", "submit", "reset"]),
      (e.SUPPORTED_CHANGE_TYPES = ["radio", "checkbox", "search"]),
      (e.SUPPORTED_ICON_TAGS = ["I", "EM", "svg", "IMG"]),
      (e.UNSUPPORTED_CLICK_TAGS = ["TEXTAREA", "HTML", "BODY"]),
      (e.TEXT_NODE = ["I", "SPAN", "EM", "B", "STRONG"]),
      (e.UNSUPPORTED_TAGS = [
        "tspan",
        "text",
        "g",
        "rect",
        "path",
        "defs",
        "clippath",
        "desc",
        "title",
        "math",
        "use",
      ]),
      (e.EXCLUDE_CLASS_RE =
        /(^| |[^ ]+\-)(clear|clearfix|active|hover|enabled|current|selected|unselected|hidden|display|focus|disabled|undisabled|open|checked|unchecked|undefined|null|ng-|growing-)[^\. ]*/g),
      (e.VALID_ID_SELECTOR = /^[a-zA-Z-\_][a-zA-Z\-\_0-9]+$/),
      (e.VALID_CLASS_SELECTOR = /^([a-zA-Z\-\_0-9]+)$/),
      (e.GROWING_IGNORE = "data-growing-ignore"),
      (e.GROWING_TRACK = "data-growing-track"),
      (e.GROWING_CONTAINER = "data-growing-container"),
      (e.GROWING_INDEX = "data-growing-index"),
      (e.GROWING_INDEX_OLD = "data-growing-idx"),
      (e.GROWING_CDP_INDEX = "data-index"),
      (e.GROWING_GTITLE = "data-growing-title"),
      (e.GROWING_TITLE = "data-title"),
      (e.GROWING_TITLE_OLD = "growing-title");
  })(_e);
  var Te = {},
    Ne = {};
  Object.defineProperty(Ne, "__esModule", {
    value: !0,
  }),
    (Ne.lastFindIndex =
      Ne.findIndex =
      Ne.arrayEquals =
      Ne.rmBlank =
      Ne.normalizePath =
      Ne.splitNoEmpty =
      Ne.filterText =
        void 0),
    (Ne.filterText = function (e, t) {
      if (
        (void 0 === t && (t = !0),
        e &&
          (null == (e = e.replace(/[\n \t]+/g, " ").trim())
            ? void 0
            : e.length))
      )
        return e.slice(0, t ? 50 : void 0);
    }),
    (Ne.splitNoEmpty = function (e, t) {
      return e
        ? e.split(t).filter(function (e) {
            return !!e;
          })
        : [];
    }),
    (Ne.normalizePath = function (e) {
      var t = e.length;
      return t > 1 && "/" === e.charAt(t - 1) ? e.slice(0, t - 1) : e;
    }),
    (Ne.rmBlank = function (e) {
      return e ? e.replace(/[\n \t]+/g, "") : "";
    }),
    (Ne.arrayEquals = function (e, t) {
      if (!e || !t) return !1;
      if (e.length !== t.length) return !1;
      for (var i = 0, n = e.length; n > i; i++) if (e[i] !== t[i]) return !1;
      return !0;
    }),
    (Ne.findIndex = function (e, t) {
      if (null == e || "function" != typeof t) return -1;
      for (var i = 0; i < e.length; i++) {
        var n = e[i];
        if (t.call(void 0, n)) return i;
      }
      return -1;
    }),
    (Ne.lastFindIndex = function (e, t) {
      if (null == e || "function" != typeof t) return -1;
      for (var i = e.length - 1; i >= 0; i--) {
        var n = e[i];
        if (t.call(void 0, n)) return i;
      }
      return -1;
    }),
    (function (e) {
      var t =
          (v && v.__spreadArray) ||
          function (e, t, i) {
            if (i || 2 === arguments.length)
              for (var n, r = 0, s = t.length; s > r; r++)
                (!n && r in t) ||
                  (n || (n = [].slice.call(t, 0, r)), (n[r] = t[r]));
            return e.concat(n || [].slice.call(t));
          },
        i =
          (v && v.__importDefault) ||
          function (e) {
            return e && e.__esModule
              ? e
              : {
                  default: e,
                };
          };
      Object.defineProperty(e, "__esModule", {
        value: !0,
      }),
        (e.removeDiffTagOnHeadAndTail =
          e.computeXpath =
          e.getMarkIndex =
          e.getEffectiveNode =
          e.isIgnore =
          e.depthInside =
          e.changeableInput =
          e.clickableInput =
          e.onlyContainsTextChildren =
          e.onlyContainsIconChildren =
          e.supportIconTag =
          e.isContainerTag =
          e.isListTag =
          e.isParentOfLeaf =
          e.isLeaf =
          e.getChildren =
          e.getDeepChildren =
          e.findParent =
          e.isRootNode =
          e.hasValidAttribute =
            void 0);
      var n = Ne,
        r = _e,
        s = i(I);
      (e.hasValidAttribute = function (e, t) {
        return (
          e instanceof Element &&
          e.hasAttribute(t) &&
          "false" !== e.getAttribute(t)
        );
      }),
        (e.isRootNode = function (e) {
          return !e || -1 !== ["BODY", "HTML", "#document"].indexOf(e.nodeName);
        }),
        (e.findParent = function (t, i) {
          for (var n = t.parentNode; n && !(0, e.isRootNode)(n); ) {
            if (i(n)) return n;
            n = n.parentNode;
          }
        }),
        (e.getDeepChildren = function (i) {
          return (0, s.default)(
            (null == i ? void 0 : i.childNodes) || []
          ).reduce(function (i, n) {
            return n instanceof Element
              ? t(t(t([], i, !0), [n], !1), (0, e.getDeepChildren)(n), !0)
              : i;
          }, []);
        }),
        (e.getChildren = function (e) {
          return (0, s.default)(
            (null == e ? void 0 : e.childNodes) || []
          ).filter(function (e) {
            return e instanceof Element;
          });
        }),
        (e.isLeaf = function (t) {
          return (
            !t.hasChildNodes() ||
            "svg" === t.nodeName ||
            0 === (0, e.getChildren)(t).length
          );
        }),
        (e.isParentOfLeaf = function (t) {
          return (
            !(!t.hasChildNodes() || "svg" === t.nodeName) &&
            0 ===
              (0, s.default)(t.childNodes).filter(function (t) {
                return !(0, e.isLeaf)(t);
              }).length
          );
        }),
        (e.isListTag = function (e) {
          return -1 !== r.LIST_TAGS.indexOf(e.nodeName);
        }),
        (e.isContainerTag = function (t) {
          return (
            (0, e.hasValidAttribute)(t, r.GROWING_CONTAINER) ||
            -1 !== r.SUPPORTED_CONTAINER_TAGS.indexOf(t.nodeName)
          );
        }),
        (e.supportIconTag = function (e) {
          var t = e.nodeName;
          return -1 !== r.SUPPORTED_ICON_TAGS.indexOf(t);
        }),
        (e.onlyContainsIconChildren = function (t) {
          if (t.textContent) return !1;
          var i = (0, e.getChildren)(t);
          if (0 === i.length) return !1;
          for (var n = 0, r = i; n < r.length; n++) {
            var s = r[n];
            if (!(0, e.supportIconTag)(s) && "SPAN" !== s.nodeName) return !1;
          }
          return !0;
        }),
        (e.onlyContainsTextChildren = function (t) {
          return (
            0 !== (0, e.getChildren)(t).length &&
            !(0, e.getDeepChildren)(t)
              .map(function (e) {
                return e.tagName;
              })
              .some(function (e) {
                return -1 === r.TEXT_NODE.indexOf(e);
              })
          );
        }),
        (e.clickableInput = function (e) {
          return (
            e instanceof HTMLInputElement &&
            "INPUT" === e.tagName &&
            -1 !== r.SUPPORTED_CLICK_INPUT_TYPES.indexOf(e.type)
          );
        }),
        (e.changeableInput = function (e) {
          return (
            e instanceof HTMLInputElement &&
            "INPUT" === e.tagName &&
            -1 !== r.SUPPORTED_CHANGE_TYPES.indexOf(e.type)
          );
        }),
        (e.depthInside = function (t, i, n) {
          if ((void 0 === i && (i = 4), void 0 === n && (n = 1), n > i))
            return !1;
          for (
            var r = "svg" === t.tagName ? [] : (0, e.getChildren)(t), s = 0;
            s < r.length;
            s++
          ) {
            var o = r[s];
            if (!(0, e.depthInside)(o, i, n + 1)) return !1;
          }
          return i >= n;
        }),
        (e.isIgnore = function (t) {
          if (
            !(t instanceof Element) ||
            (0, e.hasValidAttribute)(t, r.GROWING_IGNORE)
          )
            return !0;
          for (var i = t.parentNode; i && !(0, e.isRootNode)(i); ) {
            if ((0, e.hasValidAttribute)(i, r.GROWING_IGNORE)) return !0;
            i = i.parentNode;
          }
          return !1;
        }),
        (e.getEffectiveNode = function (t) {
          for (
            var i, n;
            t &&
            ((n = void 0),
            !(
              (i = t) instanceof Element &&
              -1 ===
                r.UNSUPPORTED_TAGS.indexOf(
                  null === (n = i.tagName) || void 0 === n
                    ? void 0
                    : n.toLowerCase()
                )
            )) &&
            t.parentNode;

          )
            t = t.parentNode;
          var s,
            o = t.parentNode;
          return !(0, e.isRootNode)(o) &&
            ((0, e.onlyContainsIconChildren)(o) ||
              ("BUTTON" === (s = o).tagName &&
                (0, e.onlyContainsTextChildren)(s)))
            ? o
            : t;
        }),
        (e.getMarkIndex = function (e) {
          if (e instanceof Element) {
            var t =
              e.getAttribute(r.GROWING_INDEX) ||
              e.getAttribute(r.GROWING_INDEX_OLD) ||
              e.getAttribute(r.GROWING_CDP_INDEX);
            if (t) {
              if (/^\d{1,10}$/.test(t) && +t > 0 && 2147483647 > +t) return +t;
              window.console.error(
                "[GioNode]：标记的index不符合规范（index必须是大于0且小于2147483647的整数字）。",
                t
              );
            }
          }
        }),
        (e.computeXpath = function (e) {
          for (
            var t = e.parentPaths(!0),
              i = Math.min(t.length, +(t.length >= 10) + 4),
              n = ["", "", ""],
              r = 0;
            r < t.length;
            r++
          ) {
            var s = t[r].path,
              o = t[r].name;
            (n[0] = s + n[0]),
              (n[2] = "/".concat(o) + n[2]),
              i > r && (n[1] = s + n[1]);
          }
          return n;
        }),
        (e.removeDiffTagOnHeadAndTail = function (e, t) {
          var i = function (e) {
              return e.nodeName === t.nodeName;
            },
            r = (0, n.findIndex)(e, i),
            s = (0, n.lastFindIndex)(e, i);
          return -1 === r || -1 === s ? [] : e.slice(r, s + 1);
        });
    })(Te);
  var Ce = {},
    Ae = {};
  Object.defineProperty(Ae, "__esModule", {
    value: !0,
  });
  var xe = _e,
    Pe = Ne,
    De = Te;

  function Re(e) {
    var t;
    if (e instanceof Element) {
      var i = e.getAttribute("name");
      if (i) return [i];
      if (e.hasAttribute("class")) {
        var n =
          null === (t = e.getAttribute("class")) || void 0 === t
            ? void 0
            : t.replace(xe.EXCLUDE_CLASS_RE, "").trim();
        if (null == n ? void 0 : n.length)
          return n
            .split(/\s+/)
            .filter(function (e) {
              return (
                xe.VALID_CLASS_SELECTOR.test(e) &&
                !e.match(/[a-z][A-Z][a-z][A-Z]/) &&
                !e.match(/[0-9][0-9][0-9][0-9]/)
              );
            })
            .sort();
      }
    }
    return [];
  }
  var Le = (function () {
    function e(e) {
      var t;
      (this.node = e),
        (this.tagName = this.node.nodeName),
        (this.name = this.tagName.toLowerCase()),
        (this.id =
          (t = this.node).id && xe.VALID_ID_SELECTOR.test(t.id) ? t.id : null),
        (this.classList = Re(this.node)),
        this.guessListAndIndex();
    }
    return (
      (e.prototype.guessListAndIndex = function () {
        var e,
          t = this;
        this._tagList = (0, De.isListTag)(this.node);
        var i = (0, De.removeDiffTagOnHeadAndTail)(
          (0, De.getChildren)(this.node.parentNode),
          this.node
        );
        if (
          (this._tagList &&
            -1 !==
              (s = i
                .filter(function (e) {
                  return e.tagName === t.tagName;
                })
                .indexOf(this.node)) &&
            (this._index = s + 1),
          i.length >= 3 &&
            (null === (e = this.classList) || void 0 === e ? void 0 : e.length))
        ) {
          for (var n = 0, r = 0, s = 1; s <= i.length; s++) {
            var o = i[s - 1];
            if (o.tagName !== this.tagName) {
              r = 0;
              break;
            }
            (0, Pe.arrayEquals)(this.classList, Re(o)) && (r += 1),
              this.node === o && (n = s);
          }
          3 > r || ((this._pseudoList = !0), (this._index = this._index || n));
        }
      }),
      Object.defineProperty(e.prototype, "path", {
        get: function () {
          var e;
          return (
            this._path ||
              ((this._path = "/".concat(this.name)),
              this.id && (this._path += "#".concat(this.id)),
              (null === (e = this.classList) || void 0 === e
                ? void 0
                : e.length) &&
                (this._path += ".".concat(this.classList.join(".")))),
            this._path
          );
        },
        enumerable: !1,
        configurable: !0,
      }),
      Object.defineProperty(e.prototype, "pseudoList", {
        get: function () {
          return !!this._pseudoList;
        },
        enumerable: !1,
        configurable: !0,
      }),
      Object.defineProperty(e.prototype, "list", {
        get: function () {
          return !!this._tagList || !!this._pseudoList;
        },
        enumerable: !1,
        configurable: !0,
      }),
      Object.defineProperty(e.prototype, "index", {
        get: function () {
          return (0, De.getMarkIndex)(this.node) || this._index;
        },
        enumerable: !1,
        configurable: !0,
      }),
      Object.defineProperty(e.prototype, "container", {
        get: function () {
          return (0, De.isContainerTag)(this.node) || this.list;
        },
        enumerable: !1,
        configurable: !0,
      }),
      Object.defineProperty(e.prototype, "parent", {
        get: function () {
          return this.node.parentNode ? new e(this.node.parentNode) : null;
        },
        enumerable: !1,
        configurable: !0,
      }),
      (e.prototype.parentPaths = function (e) {
        void 0 === e && (e = !1);
        for (
          var t = e ? [this] : [], i = this.parent;
          i && !(0, De.isRootNode)(i.node);

        )
          t.push(i), (i = i.parent);
        return t;
      }),
      e
    );
  })();
  Ae.default = Le;
  var ke = {};
  Object.defineProperty(ke, "__esModule", {
    value: !0,
  }),
    (ke.getElementHref = ke.getImgHref = ke.getAnchorHref = void 0);
  var je = Ne;

  function Ue(e) {
    if (e.hasAttribute("href")) {
      var t = e.getAttribute("href");
      if (t && 0 !== t.indexOf("javascript"))
        return (0, je.normalizePath)(t.slice(0, 320));
    }
  }

  function Ge(e) {
    if (e.src && -1 === e.src.indexOf("data:image")) return e.src;
  }
  (ke.getAnchorHref = Ue),
    (ke.getImgHref = Ge),
    (ke.getElementHref = function (e) {
      var t = e;
      if (t)
        switch (e.nodeName.toLowerCase()) {
          case "a":
            return Ue(t);
          case "img":
            return Ge(t);
        }
    });
  var qe = {},
    He =
      (v && v.__importDefault) ||
      function (e) {
        return e && e.__esModule
          ? e
          : {
              default: e,
            };
      };
  Object.defineProperty(qe, "__esModule", {
    value: !0,
  }),
    (qe.getElementContent = qe.getFormContent = void 0);
  var Be = Te,
    Ke = ke,
    Ve = _e,
    We = He(Ae),
    Me = Ne,
    Fe = He(I),
    $e = function (e) {
      return e.htmlFor || e.getAttribute("for");
    },
    Xe = function (e) {
      var t =
        e.getAttribute(Ve.GROWING_GTITLE) ||
        e.getAttribute(Ve.GROWING_TITLE) ||
        e.getAttribute(Ve.GROWING_TITLE_OLD) ||
        e.getAttribute("title");
      return null == t ? void 0 : t.trim();
    };

  function ze(e) {
    var t = e.node;
    return e.list ? Je(t) : (0, Me.filterText)(t.textContent) || void 0;
  }

  function Je(e) {
    for (
      var t = void 0, i = !1, n = 0, r = (0, Fe.default)(e.childNodes);
      n < r.length;
      n++
    ) {
      var s = r[n];
      if (s.nodeType === Node.TEXT_NODE) {
        var o = (0, Me.filterText)(s.textContent);
        if (o) return o;
      }
      if (
        s.nodeType === Node.ELEMENT_NODE &&
        -1 === ["INPUT", "SELECT"].indexOf(s.nodeName)
      ) {
        if (new We.default(s).pseudoList) return;
        i = (0, Be.onlyContainsIconChildren)(s) || (0, Be.supportIconTag)(s);
        var a = Ye(s);
        if (i) (t = a), (i = !1);
        else if ((a || (a = Je(s)), a)) return a;
      }
    }
    return t;
  }

  function Ze(e) {
    for (
      var t = e.getElementsByTagName("input"), i = 0, n = (0, Fe.default)(t);
      i < n.length;
      i++
    ) {
      var r = n[i];
      if (
        ("search" === r.type ||
          ("text" === r.type &&
            ("q" === r.id ||
              -1 !== r.id.indexOf("search") ||
              "q" === r.name ||
              -1 !== r.name.indexOf("search")))) &&
        !(0, Be.isIgnore)(r)
      ) {
        var s = Ye(r);
        if (s) return s;
      }
    }
  }

  function Ye(e) {
    return (
      (function (e) {
        var t = e;
        if (t) {
          var i = Xe(t);
          if (i) return i;
          var n,
            r,
            s,
            o = new We.default(e);
          switch (e.nodeName.toLowerCase()) {
            case "a":
              return (function (e) {
                if (
                  ((0, Be.isLeaf)(e) || (0, Be.onlyContainsIconChildren)(e)) &&
                  e.textContent
                ) {
                  var t = (0, Me.filterText)(e.textContent);
                  if (t) return t;
                }
                var i = (0, Ke.getAnchorHref)(e);
                if (i) {
                  var n = i.indexOf("?");
                  return n > -1 ? i.slice(0, n) : i;
                }
              })(t);
            case "svg":
              return (function (e) {
                for (
                  var t = 0, i = (0, Fe.default)(e.childNodes);
                  t < i.length;
                  t++
                ) {
                  var n = i[t];
                  if (
                    n.nodeType === Node.ELEMENT_NODE &&
                    "use" === n.tagName.toLowerCase() &&
                    n.hasAttribute("xlink:href")
                  )
                    return n.getAttribute("xlink:href");
                }
              })(t);
            case "button":
              return (
                null === (s = (r = t).name) || void 0 === s ? void 0 : s.length
              )
                ? r.name
                : (0, Me.filterText)(r.textContent) || Je(r);
            case "img":
              return (function (e) {
                if (e.alt) return e.alt;
                var t = (0, Ke.getImgHref)(e);
                if (t) {
                  var i = t.split("?")[0].split("/");
                  if (i.length > 0) return i[i.length - 1];
                }
              })(t);
            case "label":
              return ze(o);
            case "input":
              return (function (e) {
                if ((0, Be.clickableInput)(e)) return e.value;
                if (
                  "password" !== e.type &&
                  (0, Be.hasValidAttribute)(e, Ve.GROWING_TRACK)
                )
                  return e.value;
                if ((0, Be.changeableInput)(e)) {
                  var t = (0, Be.findParent)(e, function (e) {
                    return "LABEL" === e.nodeName;
                  });
                  if (!t && e.id)
                    for (
                      var i = document.body.getElementsByTagName("label"),
                        n = 0;
                      n < i.length;
                      n++
                    ) {
                      var r = i[n];
                      if ($e(r) === e.id) {
                        t = r;
                        break;
                      }
                    }
                  if (t) {
                    var s = ze(new We.default(t));
                    if (s && s.length > 0) return s + " (" + e.checked + ")";
                  }
                  return e.value;
                }
              })(t);
            case "select":
              return (
                (n = t),
                (0, Fe.default)(n.options)
                  .filter(function (e) {
                    return e.selected;
                  })
                  .map(function (e) {
                    return e.label;
                  })
                  .join(", ") || n.value
              );
            case "form":
              return Ze(t);
          }
          return (0, Be.isLeaf)(t)
            ? (function (e) {
                var t = (0, Me.filterText)(e.textContent);
                if (t) return t;
              })(t)
            : (0, Be.isParentOfLeaf)(t) && !(0, Be.onlyContainsIconChildren)(t)
            ? (function (e) {
                for (
                  var t = "", i = 0, n = (0, Fe.default)(e.childNodes);
                  i < n.length;
                  i++
                ) {
                  var r = n[i];
                  t +=
                    (r.nodeType === Node.TEXT_NODE && r.textContent
                      ? r.textContent.trim()
                      : "") + " ";
                }
                return (0, Me.filterText)(t, !1);
              })(t)
            : o.container || (0, Be.onlyContainsIconChildren)(e)
            ? Je(t)
            : void 0;
        }
      })(e) || void 0
    );
  }
  (qe.getFormContent = Ze), (qe.getElementContent = Ye);
  var Qe,
    et =
      (v && v.__extends) ||
      ((Qe = function (e, t) {
        return (
          (Qe =
            Object.setPrototypeOf ||
            ({
              __proto__: [],
            } instanceof Array &&
              function (e, t) {
                e.__proto__ = t;
              }) ||
            function (e, t) {
              for (var i in t) ({}.hasOwnProperty.call(t, i) && (e[i] = t[i]));
            }),
          Qe(e, t)
        );
      }),
      function (e, t) {
        if ("function" != typeof t && null !== t)
          throw new TypeError(
            "Class extends value " + t + " is not a constructor or null"
          );

        function i() {
          this.constructor = e;
        }
        Qe(e, t),
          (e.prototype =
            null === t
              ? Object.create(t)
              : ((i.prototype = t.prototype), new i()));
      }),
    tt =
      (v && v.__importDefault) ||
      function (e) {
        return e && e.__esModule
          ? e
          : {
              default: e,
            };
      };
  Object.defineProperty(Ce, "__esModule", {
    value: !0,
  });
  var it = tt(Ae),
    nt = ke,
    rt = qe,
    st = Te,
    ot = (function (e) {
      function t(t) {
        var i = e.call(this, t) || this;
        i.node = t;
        var n = (0, st.computeXpath)(i),
          r = n[0],
          s = n[1],
          o = n[2];
        return (i.fullXpath = r), (i.xpath = s), (i.skeleton = o), i;
      }
      return (
        et(t, e),
        Object.defineProperty(t.prototype, "href", {
          get: function () {
            return (0, nt.getElementHref)(this.node);
          },
          enumerable: !1,
          configurable: !0,
        }),
        Object.defineProperty(t.prototype, "content", {
          get: function () {
            return (0, rt.getElementContent)(this.node);
          },
          enumerable: !1,
          configurable: !0,
        }),
        t
      );
    })(it.default);
  Ce.default = ot;
  var at =
      (v && v.__assign) ||
      function () {
        return (
          (at =
            Object.assign ||
            function (e) {
              for (var t, i = 1, n = arguments.length; n > i; i++)
                for (var r in (t = arguments[i]))
                  ({}.hasOwnProperty.call(t, r) && (e[r] = t[r]));
              return e;
            }),
          at.apply(this, arguments)
        );
      },
    dt =
      (v && v.__importDefault) ||
      function (e) {
        return e && e.__esModule
          ? e
          : {
              default: e,
            };
      };
  Object.defineProperty(Se, "__esModule", {
    value: !0,
  });
  var lt = _e,
    ct = Te,
    ht = dt(Ce),
    ut = (function () {
      function e(e, t, i) {
        void 0 === t && (t = null),
          void 0 === i && (i = !0),
          (this.origin = e),
          (this.action = t),
          (this.direct = i),
          (this.target = "self" === t ? e : (0, ct.getEffectiveNode)(e)),
          (this.ignore = (0, ct.isIgnore)(this.target)),
          (this.vnode = new ht.default(this.target)),
          (this.tagName = this.vnode.tagName);
      }
      return (
        Object.defineProperty(e.prototype, "content", {
          get: function () {
            return this.vnode.content;
          },
          enumerable: !1,
          configurable: !0,
        }),
        Object.defineProperty(e.prototype, "href", {
          get: function () {
            return this.vnode.href;
          },
          enumerable: !1,
          configurable: !0,
        }),
        Object.defineProperty(e.prototype, "index", {
          get: function () {
            return this.vnode.index;
          },
          enumerable: !1,
          configurable: !0,
        }),
        (e.prototype.inferParentIndex = function () {
          var t = this;
          return (
            this.parentIndex ||
              (0, ct.findParent)(this.target, function (i) {
                var n = new e(i, t.action, !1);
                n.traceable() && n.index && (t.parentIndex = n.index);
              }),
            this.parentIndex
          );
        }),
        Object.defineProperty(e.prototype, "xpath", {
          get: function () {
            return this.vnode.xpath;
          },
          enumerable: !1,
          configurable: !0,
        }),
        Object.defineProperty(e.prototype, "fullXpath", {
          get: function () {
            return this.vnode.fullXpath;
          },
          enumerable: !1,
          configurable: !0,
        }),
        Object.defineProperty(e.prototype, "skeleton", {
          get: function () {
            return this.vnode.skeleton;
          },
          enumerable: !1,
          configurable: !0,
        }),
        (e.prototype.info = function (e) {
          return (
            void 0 === e && (e = !0),
            e && this.inferParentIndex(),
            {
              skeleton: this.skeleton,
              fullXpath: this.fullXpath,
              xpath: this.xpath,
              content: this.content,
              href: this.href,
              index: this.parentIndex || this.index,
            }
          );
        }),
        (e.prototype.traceable = function () {
          if (this.ignore) return !1;
          if (this.direct) {
            if ("click" === this.action || "hover" === this.action) {
              if (-1 !== lt.UNSUPPORTED_CLICK_TAGS.indexOf(this.target.tagName))
                return !1;
              if (
                "INPUT" === this.target.tagName &&
                !(0, ct.clickableInput)(this.target)
              )
                return !1;
              if (
                !(0, ct.isContainerTag)(this.target) &&
                !(0, ct.depthInside)(this.target, 5)
              )
                return !1;
            }
            return !0;
          }
          return this.vnode.container;
        }),
        (e.prototype.trackNodes = function () {
          if (!this.traceable()) return [];
          var e = [this];
          if ("submit" !== this.action)
            for (var t = this.parentElement; t; ) {
              if (t.ignore) return [];
              t.traceable() && e.unshift(t), (t = t.parentElement);
            }
          var i = void 0;
          return e.map(function (e) {
            var t = e.info(!1),
              n = t.index;
            return (
              !i && n && (i = n),
              at(at({}, t), {
                index: i || n,
              })
            );
          });
        }),
        Object.defineProperty(e.prototype, "parentElement", {
          get: function () {
            var t = this.target.parentNode;
            if (t && t.nodeName && !(0, ct.isRootNode)(t))
              return new e(t, this.action, !1);
          },
          enumerable: !1,
          configurable: !0,
        }),
        e
      );
    })(),
    gt = (Se.default = ut);
  class pt {
    constructor(e) {
      this.handler = e;
      const t = navigator.userAgent,
        i = /chrome/i.exec(t),
        n = /android/i.exec(t);
      this.hasTouch = "ontouchstart" in window && !(i && !n);
    }
    main() {
      const e = this.hasTouch ? ["touchstart"] : ["mousedown"],
        t = this.hasTouch
          ? ["touchend", "touchcancel"]
          : ["mouseup", "mouseleave"],
        i = this.hasTouch ? ["touchmove"] : ["mousemove"];
      for (const t of e) Q(window, t, this.touchStartHandler.bind(this));
      for (const e of i) Q(window, e, this.touchMoveHandler.bind(this));
      for (const e of t) Q(window, e, this.touchStopHandler.bind(this));
    }
    touchStartHandler(e) {
      if (e.which > 1) return;
      const t = +Date.now();
      this.safeguard !== t &&
        (this.touchTimeout && clearTimeout(this.touchTimeout),
        (this.safeguard = t),
        (this.touchEvent = {
          time: t,
          target: e.target,
          x: this._page("x", e),
          y: this._page("y", e),
          isTrusted: !0,
          type: "click",
        }));
    }
    touchMoveHandler(e) {
      const t = Math.abs(
          this._page("x", e) - (this.touchEvent && this.touchEvent.x) || 0
        ),
        i = Math.abs(
          this._page("y", e) - (this.touchEvent && this.touchEvent.y) || 0
        );
      (t > 10 || i > 10) && (this.touchEvent = null);
    }
    touchStopHandler(e) {
      const t = +Date.now() - (this.touchEvent && this.touchEvent.time) || 0;
      this.touchEvent && 200 > t
        ? (this.touchTimeout = setTimeout(() => {
            this.handler(this.touchEvent), (this.touchEvent = null);
          }, 200))
        : this.touchEvent &&
          t >= 200 &&
          700 > t &&
          (this.handler(this.touchEvent), (this.touchEvent = null));
    }
    _page(e, t) {
      return (this.hasTouch ? t.touches[0] : t)["page" + e.toUpperCase()];
    }
  }
  var ft = {
    name: "gioEventAutoTracking",
    method: class {
      constructor(e) {
        (this.growingIO = e),
          (this.main = () => {
            Q(document, "submit", this._handleAction),
              Q(document, "change", this._handleAction);
            const { vdsConfig: e } = this.growingIO;
            e.touch
              ? new pt(this._handleAction).main()
              : Q(document, "click", this._handleAction);
          }),
          (this._handleAction = (e, t) => {
            const { vdsConfig: i, emitter: n } = this.growingIO;
            if (!i.autotrack) return !1;
            const r = e.target;
            if (!r) return !1;
            let s = new gt(r, e.type, !0).trackNodes();
            if (("click" !== e.type && (s = $(x(s)) ? [] : [x(s)]), $(s)))
              return !1;
            null == n ||
              n.emit("onComposeBefore", {
                event: t,
                params: null != e ? e : {},
              }),
              s.forEach((t) => {
                const { fullXpath: n, index: r, content: s, href: o } = t;
                if (
                  !q(t.fullXpath || "", "/div#__vconsole") &&
                  !q(t.fullXpath || "", "/div#__giokit") &&
                  (i.debug && console.log("Action：", e.type, Date.now()), n)
                ) {
                  const {
                    dataStore: {
                      eventContextBuilder: t,
                      eventConverter: i,
                      currentPage: a,
                    },
                  } = this.growingIO;
                  i(
                    Object.assign(
                      Object.assign(
                        {
                          eventType: l[e.type],
                          element: [
                            {
                              xpath: n,
                              index: r,
                              textValue: s,
                              hyperlink: o,
                            },
                          ],
                        },
                        t()
                      ),
                      {
                        pageShowTimestamp: a.time,
                      }
                    )
                  );
                }
              });
          });
      }
    },
  };
  const mt = [
      "VIEW_CLICK",
      "VIEW_CHANGE",
      "FORM_SUBMIT",
      "PAGE",
      "CUSTOM",
      "LOGIN_USER_ATTRIBUTES",
    ],
    vt = ["LOGIN_USER_ATTRIBUTES"];
  var It = {
    name: "gioHybridAdapter",
    method: class {
      constructor(e) {
        (this.growingIO = e),
          (this.penetrateHybrid = !0),
          (this.main = (e) => {
            var t;
            (this.projectId = e.projectId),
              E(e.penetrateHybrid) &&
                (this.penetrateHybrid = e.penetrateHybrid),
              this._initHybridBridge();
            const i =
              this.projectId ===
              (null === (t = this.hybridConfig) || void 0 === t
                ? void 0
                : t.projectId);
            if (i) {
              const { emitter: e } = this.growingIO;
              null == e ||
                e.on(ce, ({ newUserId: e, oldUserId: t, userKey: i }) => {
                  this.penetrateHybrid &&
                    (!e && t
                      ? i
                        ? this._clearNativeUserIdAndUserKey()
                        : this._clearNativeUserId()
                      : i
                      ? this._setNativeUserIdAndUserKey(j(e), j(i))
                      : this._setNativeUserId(j(e)));
                }),
                null == e ||
                  e.on(he, ({ newUserKey: e, oldUserKey: t, userId: i }) => {
                    this.penetrateHybrid &&
                      (!e && t
                        ? this._clearNativeUserIdAndUserKey()
                        : this._setNativeUserIdAndUserKey(j(i), j(e)));
                  });
            }
            return i;
          }),
          (this._initHybridBridge = () => {
            var e, t, i;
            (this.hasHybridBridge = !!window.GrowingWebViewJavascriptBridge),
              this.hasHybridBridge &&
                ((null ===
                  (e =
                    null === window || void 0 === window
                      ? void 0
                      : window.GrowingWebViewJavascriptBridge) || void 0 === e
                  ? void 0
                  : e.configuration) ||
                  (window.GrowingWebViewJavascriptBridge.configuration =
                    JSON.parse(
                      window.GrowingWebViewJavascriptBridge.getConfiguration()
                    )),
                (null ===
                  (t =
                    null === window || void 0 === window
                      ? void 0
                      : window.GrowingWebViewJavascriptBridge) || void 0 === t
                  ? void 0
                  : t.configuration) &&
                  (this.hybridConfig =
                    null ===
                      (i =
                        null === window || void 0 === window
                          ? void 0
                          : window.GrowingWebViewJavascriptBridge) ||
                    void 0 === i
                      ? void 0
                      : i.configuration));
          }),
          (this.onSendBefore = ({ requestData: e }) => {
            var t, i;
            this.hasHybridBridge &&
              L(mt, e.eventType) &&
              (L(vt, e.eventType)
                ? this.penetrateHybrid &&
                  (null === (t = window.GrowingWebViewJavascriptBridge) ||
                    void 0 === t ||
                    t.dispatchEvent(JSON.stringify(this.processAttributes(e))))
                : (this.penetrateHybrid ||
                    (F(e, "userId"), F(e, "userKey"), F(e, "cs1")),
                  null === (i = window.GrowingWebViewJavascriptBridge) ||
                    void 0 === i ||
                    i.dispatchEvent(
                      JSON.stringify(this.processAttributes(e))
                    )));
          }),
          (this.processAttributes = (e) => (
            W(e, (t, i) => {
              S(t) || N(t)
                ? W(e[i], (t, n) => {
                    S(t) || N(t)
                      ? (e[i][n] = JSON.stringify(t))
                      : (e[i][n] = j(t));
                  })
                : (e[i] = j(t));
            }),
            e
          )),
          (this._setNativeUserId = (e) => {
            Z(() => window.GrowingWebViewJavascriptBridge.setNativeUserId(e));
          }),
          (this._clearNativeUserId = () => {
            Z(() => window.GrowingWebViewJavascriptBridge.clearNativeUserId());
          }),
          (this._setNativeUserIdAndUserKey = (e, t) => {
            Z(() =>
              window.GrowingWebViewJavascriptBridge.setNativeUserIdAndUserKey(
                e,
                t
              )
            );
          }),
          (this._clearNativeUserIdAndUserKey = () => {
            Z(() =>
              window.GrowingWebViewJavascriptBridge.clearNativeUserIdAndUserKey()
            );
          });
      }
    },
  };
  const wt = ["i", "span", "em", "b", "strong", "svg"];
  var Ot;
  !(function (e) {
    (e[(e.OUTER = 0)] = "OUTER"),
      (e[(e.INNER_COVERED = 1)] = "INNER_COVERED"),
      (e[(e.INNER_SHOW = 2)] = "INNER_SHOW");
  })(Ot || (Ot = {}));
  const bt = [
      "HR",
      "BR",
      "SCRIPT",
      "NOSCRIPT",
      "STYLE",
      "HEAD",
      "BASE",
      "LINK",
      "META",
      "TITLE",
      "BODY",
      "HTML",
      "TEMPLATE",
      "CODE",
      ..._e.UNSUPPORTED_CLICK_TAGS,
    ],
    yt = ["SELECT", "A", "BUTTON", "INPUT", "IMG", "FORM"],
    Et = (e, t, i) => document.elementFromPoint(t, i) === e;
  class St {
    constructor(e, t, i) {
      (this.node = e),
        (this.parentNodeDesc = t),
        (this.devicesInfo = i),
        (this.proxy = new gt(e)),
        (this.tagName = this.node.tagName),
        (this.name = this.tagName.toLowerCase()),
        (this.isIgnore = !!this.node.dataset.growingIgnore),
        (this.isUnSupported = -1 !== bt.indexOf(this.tagName)),
        (this.rect = this.computeWindowRect());
    }
    info() {
      const e = this.desc();
      e.zLevel += this.devicesInfo.webviewZLevel;
      const t = this.getDeviceRect(this.rect);
      return (
        F(e, "isContainer"),
        Object.assign(Object.assign(Object.assign({}, e), t), {
          parentXPath: this.parentNodeDesc.isContainer
            ? this.parentNodeDesc.xpath
            : void 0,
          href: this.proxy.href,
          content: this.proxy.content,
          nodeType: this.nodeType(),
        })
      );
    }
    nodeType() {
      return "input" !== this.name || Te.changeableInput(this.node)
        ? this.node.tagName
        : "INPUT_BTN";
    }
    desc() {
      return {
        index: this.parentNodeDesc.index || this.proxy.index,
        zLevel: this.zLevel(),
        xpath: this.proxy.xpath,
        isContainer: this.isDefinedContainer(),
      };
    }
    cssVisible() {
      const e = this.computedStyle();
      return (
        Number(e.opacity) > 0 &&
        "visible" === e.visibility &&
        "none" !== e.display
      );
    }
    viewportStatus() {
      const { top: e, left: t, width: i, height: n } = this.rect,
        { winWidth: r, winHeight: s } = this.devicesInfo;
      if (0 >= i || 0 >= n) return Ot.OUTER;
      const o = this.node;
      return s > e && r > t && i > 0 && n > 0
        ? Et(o, t + i / 2, e + n / 2) ||
          Et(o, t + 1, e + 1) ||
          Et(o, t + i - 1, e + 1) ||
          Et(o, t + 1, e + n - 1) ||
          Et(o, t + i - 1, e + n - 1)
          ? Ot.INNER_SHOW
          : Ot.INNER_COVERED
        : Ot.OUTER;
    }
    isCircleable() {
      return (
        this.proxy.target === this.proxy.origin &&
        (!!this.isDefinedContainer() ||
          (!(
            "input" === this.name &&
            this.node instanceof HTMLInputElement &&
            "password" === this.node.type
          ) &&
            (-1 !== yt.indexOf(this.name) ||
              (Te.isLeaf(this.node)
                ? !this.isBigBlank()
                : this.hasBackgroundImage() && Te.depthInside(this.node, 4)))))
      );
    }
    isSimpleContainer() {
      return (
        "select" === this.name ||
        (this.isDefaultContainer() &&
          ((function (e, t) {
            if (0 === e.children.length) return !1;
            for (const i of k(e.children))
              if (-1 === t.indexOf(i.tagName.toLowerCase())) return !1;
            return !0;
          })(this.node, wt) ||
            !this.node.childElementCount))
      );
    }
    isDefinedContainer() {
      var e;
      return w(this.isContainer)
        ? this.isDefaultContainer() ||
            this.isMarkContainer() ||
            (Te.isParentOfLeaf(this.node) &&
              (!!(null === (e = this.node.innerText) || void 0 === e
                ? void 0
                : e.trim().length) ||
                (function (e) {
                  const t = e.attributes;
                  if (t.length > 0)
                    for (let e = 0; e < t.length; e++) {
                      const i = t[e].value;
                      if (i && "false" !== i) return !0;
                    }
                  return !1;
                })(this.node))) ||
            "select" === this.name
        : !!this.isContainer;
    }
    isDefaultContainer() {
      return (
        -1 !== _e.SUPPORTED_CONTAINER_TAGS.indexOf(this.tagName) ||
        Te.clickableInput(this.node)
      );
    }
    isMarkContainer() {
      return (
        this.node.hasAttribute("data-growing-container") ||
        this.node.hasAttribute("growing-container")
      );
    }
    isBigBlank() {
      var e, t;
      const i =
          null !==
            (t =
              null === (e = this.node.innerText) || void 0 === e
                ? void 0
                : e.trim().length) && void 0 !== t
            ? t
            : 0,
        { width: n, height: r } = this.rect,
        { winWidth: s, winHeight: o } = this.devicesInfo;
      return !i && (n > s >> 1 || r > o >> 1);
    }
    hasBackgroundImage() {
      const e = this.computedStyle().backgroundImage;
      return !!e && "none" !== e && e.length > 0;
    }
    zLevel() {
      const e = this.computedStyle(),
        t = e.zIndex;
      if ("auto" !== t) return Number(t || "0") + this.parentNodeDesc.zLevel;
      switch (e.position) {
        case "relative":
          return this.parentNodeDesc.zLevel + 2;
        case "sticky":
          return this.parentNodeDesc.zLevel + 3;
        case "absolute":
          return this.parentNodeDesc.zLevel + 4;
        case "fixed":
          return this.parentNodeDesc.zLevel + 5;
        default:
          return this.parentNodeDesc.zLevel + 1;
      }
    }
    computeWindowRect() {
      if (this.rect) return this.rect;
      const e = this.node.getBoundingClientRect(),
        t = e.top,
        i = e.bottom,
        n = e.left;
      let r = e.right - n,
        s = i - t;
      return (
        0 > t
          ? (s = t + s)
          : t + s > this.devicesInfo.winHeight &&
            (s = this.devicesInfo.winHeight - t),
        0 > n
          ? (r = n + r)
          : n + r > this.devicesInfo.winWidth &&
            (r = this.devicesInfo.winWidth - n),
        (this.rect = {
          top: t,
          left: n,
          width: r,
          height: s,
        }),
        this.rect
      );
    }
    computedStyle() {
      return window.getComputedStyle(this.node);
    }
    getDeviceRect(e) {
      const { scale: t, webviewTop: i, webviewLeft: n } = this.devicesInfo;
      return {
        top: e.top * t + i,
        left: e.left * t + n,
        width: e.width * t,
        height: e.height * t,
      };
    }
  }
  const _t = ["DOMContentLoaded", "onreadystatechange"],
    Tt = [
      "scroll",
      "resize",
      "load",
      "beforeunload",
      "popstate",
      "hashchange",
      "pagehide",
      "unload",
    ];
  class Nt {
    constructor(e) {
      (this.growingIO = e), this.addDomChangeListener();
    }
    getDomTree(e, t, i, n, r, s) {
      const o = (function (e, t, i, n, r) {
          const s = document.documentElement.clientWidth;
          return {
            winWidth: s,
            winHeight: document.documentElement.clientHeight,
            scale: i / s,
            webviewTop: t,
            webviewLeft: e,
            webviewWidth: i,
            webviewHeight: n,
            webviewZLevel: r,
          };
        })(e, t, i, n, r),
        a = this.getElementsByParent(
          s || document.body,
          {
            isContainer: !1,
            zLevel: 0,
          },
          o
        ),
        {
          domain: d,
          path: l,
          query: c,
          title: h,
        } = this.growingIO.dataStore.currentPage;
      return {
        page: {
          domain: d,
          path: l,
          query: c,
          title: h,
        },
        elements: a,
      };
    }
    getElementsByParent(e, t, i) {
      const n = [];
      return (
        [].slice
          .call(e.childNodes, 0)
          .filter((e) => 1 === e.nodeType)
          .forEach((e) => {
            const r = new St(e, t, i);
            if (r.cssVisible() && !r.isIgnore) {
              switch (r.viewportStatus()) {
                case Ot.INNER_SHOW:
                  r.isCircleable() && n.push(r.info());
                  break;
                case Ot.INNER_COVERED:
                  r.isDefaultContainer() && n.push(r.info());
              }
              r.isSimpleContainer() ||
                [].push.apply(n, this.getElementsByParent(e, r.desc(), i));
            }
          }),
        n
      );
    }
    addDomChangeListener() {
      let e;
      const t =
        (t = "") =>
        () => {
          var i;
          "beforeunload" === t && e && e.disconnect(),
            null === (i = window.GrowingWebViewJavascriptBridge) ||
              void 0 === i ||
              i.onDomChanged();
        };
      (e = new MutationObserver(t("mutation"))),
        e.observe(document.body, {
          attributes: !0,
          characterData: !0,
          childList: !0,
          subtree: !0,
        }),
        _t.forEach((e) => {
          Q(document, e, t(e));
        }),
        Tt.forEach((e) => {
          Q(window, e, t(e));
        });
    }
  }
  class Ct {
    constructor(e) {
      var t;
      (this.growingIO = e),
        null === (t = this.growingIO.emitter) ||
          void 0 === t ||
          t.on(le, () => {
            if (window.GrowingWebViewJavascriptBridge) {
              const e = this;
              window.GrowingWebViewJavascriptBridge.getDomTree = function () {
                if (arguments.length >= 4)
                  return (
                    Ct.bindGetDomTree(e.growingIO),
                    Ct.domHelper.getDomTree.apply(Ct.domHelper, arguments)
                  );
              };
            }
          });
    }
    static bindGetDomTree(e) {
      this.domHelper ||
        ((this.domHelper = new Nt(e)),
        (window.GrowingWebViewJavascriptBridge.getDomTree =
          this.domHelper.getDomTree.bind(this.domHelper)));
    }
  }
  var At = {
    name: "gioHybridCircle",
    method: Ct,
  };

  function xt(e) {
    for (var t = 1; arguments.length > t; t++) {
      var i = arguments[t];
      for (var n in i) e[n] = i[n];
    }
    return e;
  }
  var Pt = (function e(t, i) {
    function n(e, n, r) {
      if ("undefined" != typeof document) {
        "number" == typeof (r = xt({}, i, r)).expires &&
          (r.expires = new Date(Date.now() + 864e5 * r.expires)),
          r.expires && (r.expires = r.expires.toUTCString()),
          (e = encodeURIComponent(e)
            .replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent)
            .replace(/[()]/g, escape));
        var s = "";
        for (var o in r)
          r[o] &&
            ((s += "; " + o), !0 !== r[o] && (s += "=" + r[o].split(";")[0]));
        return (document.cookie = e + "=" + t.write(n, e) + s);
      }
    }
    return Object.create(
      {
        set: n,
        get: function (e) {
          if ("undefined" != typeof document && (!arguments.length || e)) {
            for (
              var i = document.cookie ? document.cookie.split("; ") : [],
                n = {},
                r = 0;
              r < i.length;
              r++
            ) {
              var s = i[r].split("="),
                o = s.slice(1).join("=");
              try {
                var a = decodeURIComponent(s[0]);
                if (((n[a] = t.read(o, a)), e === a)) break;
              } catch (e) {}
            }
            return e ? n[e] : n;
          }
        },
        remove: function (e, t) {
          n(
            e,
            "",
            xt({}, t, {
              expires: -1,
            })
          );
        },
        withAttributes: function (t) {
          return e(this.converter, xt({}, this.attributes, t));
        },
        withConverter: function (t) {
          return e(xt({}, this.converter, t), this.attributes);
        },
      },
      {
        attributes: {
          value: Object.freeze(i),
        },
        converter: {
          value: Object.freeze(t),
        },
      }
    );
  })(
    {
      read: function (e) {
        return (
          '"' === e[0] && (e = e.slice(1, -1)),
          e.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent)
        );
      },
      write: function (e) {
        return encodeURIComponent(e).replace(
          /%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g,
          decodeURIComponent
        );
      },
    },
    {
      path: "/",
    }
  );
  const Dt = () =>
      "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (e) {
        const t = (16 * Math.random()) | 0;
        return ("x" === e ? t : (3 & t) | 8).toString(16);
      }),
    Rt = () => {
      var e;
      const t = !!(null ===
          (e =
            null === window || void 0 === window ? void 0 : window.navigator) ||
        void 0 === e
          ? void 0
          : e.sendBeacon),
        i = window.navigator.userAgent;
      if (i.match(/(iPad|iPhone|iPod)/g)) {
        const e = Lt(i);
        return t && e > 13;
      }
      return t;
    },
    Lt = (e) => {
      const t = e.toLowerCase().match(/cpu.*os (.*?) like mac os/i);
      return !t || 2 > t.length ? 0 : +t[1].split("_").slice(0, 2).join(".");
    },
    kt = (e) => {
      Pt.set("gioCookie", "yes", {
        domain: e,
      });
      const t = !!Pt.get("gioCookie", {
        domain: e,
      });
      return (
        Pt.remove("gioCookie", {
          domain: e,
        }),
        t
      );
    },
    jt = (e) => (H(e, "_gioenc") ? e.slice(0, -7) : e),
    Ut = (e) => (y(Number(e)) && Z(() => JSON.parse(e))) || e;
  var Gt = {
      name: "gioImpressionTracking",
      method: class {
        constructor(e) {
          var t;
          (this.growingIO = e),
            (this.documentReady = !1),
            (this.main = (e) => {
              "listener" === e
                ? ((this.documentReady = !0),
                  this.growingIO.gioSDKInitialized &&
                    this.initMutationObserver())
                : "emitter" === e &&
                  this.documentReady &&
                  this.initMutationObserver();
            }),
            (this.initIntersectionObserver = () => {
              this.intersectionObserver = new IntersectionObserver((e) => {
                $(e) ||
                  e.map((e) => {
                    const { dataset: t } = e.target;
                    if (e.intersectionRatio > 0) {
                      const {
                          eventId: e,
                          properties: i,
                          items: n,
                        } = this.getImpressionProperties(t),
                        r = t.id;
                      if (r) {
                        if ("once" === t.gioImpType && K(this.sentImps, r))
                          return;
                        this.sentImps[r] = {
                          eventId: e,
                          properties: i,
                          items: n,
                        };
                      }
                      e && this.growingIO.track(e, i, n);
                    }
                  });
              });
            }),
            (this.initMutationObserver = () => {
              if (this.mutationObserver) return !1;
              const e = document.querySelectorAll("[data-gio-imp-track]");
              k(e).map((e) => {
                var t;
                null === (t = this.intersectionObserver) ||
                  void 0 === t ||
                  t.observe(e);
              }),
                (this.mutationObserver = new MutationObserver((e) =>
                  e.map((e) => {
                    var t;
                    if ("attributes" === e.type) {
                      const { dataset: i } = e.target;
                      if (i.gioImpTrack)
                        return null === (t = this.intersectionObserver) ||
                          void 0 === t
                          ? void 0
                          : t.observe(e.target);
                    }
                  })
                )),
                this.mutationObserver.observe(document.body, {
                  attributes: !0,
                  childList: !0,
                  subtree: !0,
                  attributeOldValue: !0,
                  attributeFilter: [
                    "data-gio-imp-track",
                    "data-gio-imp-attrs",
                    "data-gio-imp-items",
                    /^data-gio-track-[a-z]+$/i,
                  ],
                });
            }),
            (this.getImpressionProperties = (e) => {
              let t = {
                eventId: void 0,
                properties: {},
              };
              if (!(null == e ? void 0 : e.gioImpTrack)) return t;
              if (((t.eventId = e.gioImpTrack), K(e, "gioImpAttrs")))
                (t.properties = Z(() =>
                  S(e.gioImpAttrs) ? e.gioImpAttrs : JSON.parse(e.gioImpAttrs)
                )),
                  (t.items = Z(() =>
                    S(e.gioImpItems) ? e.gioImpItems : JSON.parse(e.gioImpItems)
                  ));
              else {
                const i = /^gioTrack(.+)/;
                for (const n in e) {
                  let r;
                  const s = n.match(i);
                  s &&
                    ((r = G(s[1])), "track" !== r && (t.properties[r] = e[n]));
                }
              }
              return (
                (t.properties = Y(t.properties)),
                (t.items = Y(t.items)),
                (/^\w+$/.test(t.eventId) &&
                  !Number.isInteger(Number(A(t.eventId.split(""))))) ||
                  ((t.eventId = null), (t = {})),
                t
              );
            }),
            (this.sentImps = {}),
            window.ActiveXObject ||
            "ActiveXObject" in window ||
            (navigator.userAgent.indexOf("compatible") > -1 &&
              navigator.userAgent.indexOf("MSIE") > -1) ||
            (navigator.userAgent.indexOf("Trident") > -1 &&
              navigator.userAgent.indexOf("rv:11.0") > -1)
              ? J(
                  "IE浏览器不支持半自动埋点，gioImpressionTracking已自动关闭！",
                  "warn"
                )
              : (this.initIntersectionObserver(),
                Q(
                  document,
                  "readystatechange",
                  () => {
                    L(["interactive", "complete"], document.readyState) &&
                      this.main("listener");
                  },
                  {
                    once: !0,
                  }
                ),
                null === (t = this.growingIO.emitter) ||
                  void 0 === t ||
                  t.on(le, () => this.main("emitter")),
                Q(window, "unload", () => {
                  this.intersectionObserver.disconnect(),
                    this.mutationObserver.disconnect();
                }));
        }
      },
    },
    qt = {
      name: "gioWebCircle",
      method: class {
        constructor(e) {
          var t;
          (this.growingIO = e),
            (this.injectCircle = (e, t) => {
              const i = document.createElement("link"),
                n = document.createElement("script");
              (i.rel = "stylesheet"),
                (i.href = e),
                (n.src = t),
                document.head.appendChild(i),
                document.head.appendChild(n);
            }),
            null === (t = this.growingIO.emitter) ||
              void 0 === t ||
              t.on(le, () => {
                window.addEventListener("message", (e) => {
                  const { data: t, source: i } = e,
                    n = window.vds;
                  if (t && i) {
                    const e = i.vds,
                      r = t.cssURL,
                      s = t.jsURL;
                    e &&
                      "SDK_INJECT_CIRCLE_SCRIPT" === t.type &&
                      n.projectId === e.projectId &&
                      n.dataSourceId === e.dataSourceId &&
                      this.injectCircle(r, s);
                  }
                });
              });
        }
      },
    };
  const Ht = ["gioPerformance"];
  class Bt {
    constructor(e) {
      var t, i, n, r;
      (this.growingIO = e),
        (this.innerPluginInit = () => {
          var e;
          Ht.forEach((e) => {
            var t;
            return F(
              null === (t = this.pluginsContext) || void 0 === t
                ? void 0
                : t.plugins,
              e
            );
          }),
            V(
              null === (e = this.pluginsContext) || void 0 === e
                ? void 0
                : e.plugins
            ).forEach((e) => {
              var t;
              const { name: i, method: n } =
                null === (t = this.pluginsContext) || void 0 === t
                  ? void 0
                  : t.plugins[e];
              R(this.pluginItems, (e) => e.name === i) ||
                this.pluginItems.push({
                  name: G(i || e),
                  method: n || ((e) => {}),
                });
            }),
            $(this.pluginItems) || this.installAll();
        }),
        (this.install = (e, t, i) => {
          var n, r;
          const s = t || R(this.pluginItems, (t) => t.name === e);
          if (
            (null === (n = this.growingIO) || void 0 === n
              ? void 0
              : n.plugins)[e]
          )
            return J(`重复加载插件 ${e} 或插件重名，已跳过加载!`, "warn"), !1;
          if (!s) return J(`插件加载失败!不存在名为 ${e} 的插件!`, "error"), !1;
          try {
            return (
              ((null === (r = this.growingIO) || void 0 === r
                ? void 0
                : r.plugins)[e] = new s.method(this.growingIO, i)),
              "cdp" === this.growingIO.gioEnvironment &&
                t &&
                J("加载插件：" + e, "info"),
              !0
            );
          } catch (e) {
            return J("插件加载异常：" + e, "error"), !1;
          }
        }),
        (this.installAll = (e) => {
          (e || this.pluginItems).forEach((t) =>
            this.install(
              t.name,
              e ? t : void 0,
              e ? (null == t ? void 0 : t.options) : void 0
            )
          );
        }),
        (this.uninstall = (e) => {
          var t;
          F(this.pluginItems, e);
          const i = F(
            null === (t = this.growingIO) || void 0 === t ? void 0 : t.plugins,
            e
          );
          return i || J(`卸载插件 ${e} 失败!`, "error"), i;
        }),
        (this.uninstallAll = () => {
          this.pluginItems.forEach((e) => this.uninstall(e.name));
        }),
        (this.lifeError = (e, t) => J(`插件执行错误 ${e.name} ${t}`, "error")),
        (this.onComposeBefore = (e) => {
          this.pluginItems.forEach((t) => {
            var i;
            const n =
              null === (i = this.growingIO.plugins[t.name]) || void 0 === i
                ? void 0
                : i.onComposeBefore;
            if (n && T(n))
              try {
                n(e);
              } catch (e) {
                this.lifeError(t, e);
              }
          });
        }),
        (this.onComposeAfter = (e) => {
          this.pluginItems.forEach((t) => {
            var i;
            const n =
              null === (i = this.growingIO.plugins[t.name]) || void 0 === i
                ? void 0
                : i.onComposeAfter;
            if (n && T(n))
              try {
                n(e);
              } catch (e) {
                this.lifeError(t, e);
              }
          });
        }),
        (this.onSendBefore = (e) => {
          this.pluginItems.forEach((t) => {
            var i;
            const n =
              null === (i = this.growingIO.plugins[t.name]) || void 0 === i
                ? void 0
                : i.onSendBefore;
            if (n && T(n))
              try {
                n(e);
              } catch (e) {
                this.lifeError(t, e);
              }
          });
        }),
        (this.onSendAfter = (e) => {
          this.pluginItems.forEach((t) => {
            var i;
            const n =
              null === (i = this.growingIO.plugins[t.name]) || void 0 === i
                ? void 0
                : i.onSendAfter;
            if (n && T(n))
              try {
                n(e);
              } catch (e) {
                this.lifeError(t, e);
              }
          });
        }),
        (this.pluginsContext = {
          plugins: {},
        }),
        (this.pluginItems = []),
        null === (t = this.growingIO.emitter) ||
          void 0 === t ||
          t.on("onComposeBefore", this.onComposeBefore),
        null === (i = this.growingIO.emitter) ||
          void 0 === i ||
          i.on("onComposeAfter", this.onComposeAfter),
        null === (n = this.growingIO.emitter) ||
          void 0 === n ||
          n.on("onSendBefore", this.onSendBefore),
        null === (r = this.growingIO.emitter) ||
          void 0 === r ||
          r.on("onSendAfter", this.onSendAfter);
    }
  }
  class Kt extends Bt {
    constructor(e) {
      super(e),
        (this.growingIO = e),
        (this.growingIO.gioSDKFull = !0),
        (this.pluginsContext = {
          plugins: {
            gioCompress: ve,
            gioCustomTracking: Ie,
            gioEmbeddedAdapter: Ee,
            gioEventAutoTracking: ft,
            gioHybridAdapter: It,
            gioHybridCircle: At,
            gioImpressionTracking: Gt,
            gioWebCircle: qt,
          },
        });
    }
  }
  const Vt = {
      A: 1,
      a: 1,
      Z: 1,
      z: 1,
      "@": 1,
      "{": 1,
    },
    Wt = (e) => (w(e) ? e : Z(() => "gioenc-" + Ft(e)) || e),
    Mt = (e) =>
      (O(e) && q(e, "gioenc-") && Z(() => Ft(e.replace("gioenc-", "")))) || e,
    Ft = (e) =>
      (e = e || "")
        .split("")
        .map((e) => (Vt[e] ? e : $t(e)))
        .join(""),
    $t = (e) => {
      if (/[0-9]/.test(e)) return 1 ^ +e;
      {
        let t = e.charCodeAt(0);
        return String.fromCharCode(1 ^ t);
      }
    };
  class Xt {
    constructor() {
      (this.getItem = (e) => {
        const t = Z(() => JSON.parse(localStorage.getItem(jt(e)) || "")) || {};
        return S(t) && t.expiredAt > +Date.now() ? Ut(Mt(t.value)) : void 0;
      }),
        (this.setItem = (e, t, i) => {
          const n = null != i ? i : +new Date(9999, 12);
          localStorage.setItem(
            jt(e),
            JSON.stringify({
              value: O(t) && t.length && H(e, "_gioenc") ? Wt(t) : t,
              expiredAt: n,
            })
          );
        }),
        (this.removeItem = (e) => localStorage.removeItem(jt(e))),
        (this.hasItem = (e) => !!localStorage.getItem(jt(e))),
        (this.getKeys = () =>
          k(Array(localStorage.length)).map((e, t) => localStorage.key(t))),
        (this.type = "localStorage");
    }
  }
  const zt = {};
  let Jt;
  const Zt = (() => {
    let e = window.location.hostname;
    const t = Z(() => {
      const t = e.split("."),
        i = x(t);
      if (
        "localhost" !== e &&
        (y(Number(i)) || 0 > Number(i) || Number(i) > 255)
      )
        return ["." + t.slice(-2).join("."), "." + t.slice(-3).join(".")];
    }) || [e];
    let i = "";
    return t.some((e) => !!kt(e) && ((i = e), !0)), i;
  })();
  Jt =
    !L(["", "localhost", "127.0.0.1"], window.location.hostname) &&
    L(["http:", "https:"], window.location.protocol) &&
    Zt
      ? new (class {
          constructor(e) {
            (this.domain = e),
              (this.getItem = (e) => Ut(Mt(Pt.get(jt(e))))),
              (this.setItem = (e, t, i) => {
                let n;
                (n = O(t)
                  ? t.length
                    ? H(e, "_gioenc")
                      ? Wt(t)
                      : t
                    : ""
                  : JSON.stringify(t)),
                  Pt.set(jt(e), n, {
                    expires: i ? new Date(i) : 3650,
                    domain: this.domain,
                  });
              }),
              (this.removeItem = (e) => {
                Pt.remove(jt(e), {
                  domain: this.domain,
                });
              }),
              (this.hasItem = (e) => L(V(Pt.get()), jt(e))),
              (this.getKeys = () => V(Pt.get())),
              (this.type = "Cookie");
          }
        })(Zt)
      : ((e) => {
          try {
            const e = window.localStorage,
              t = "__storage_test__";
            return e.setItem(t, t), e.removeItem(t), !0;
          } catch (e) {
            return !1;
          }
        })()
      ? new Xt()
      : new (class {
          constructor() {
            (this.getItem = (e) => {
              const t = Z(() => JSON.parse(zt[jt(e)] || ""));
              return S(t) && t.expiredAt > +Date.now()
                ? Ut(Mt(t.value))
                : void 0;
            }),
              (this.setItem = (e, t, i) => {
                const n = null != i ? i : +new Date(9999, 12);
                zt[jt(e)] = JSON.stringify({
                  value: O(t) && t.length ? Wt(t) : t,
                  expiredAt: n,
                });
              }),
              (this.removeItem = (e) => F(zt, jt(e))),
              (this.hasItem = (e) => K(zt, jt(e))),
              (this.getKeys = () => V(zt)),
              (this.type = "memory");
          }
        })();
  var Yt = Jt;
  class Qt {
    constructor() {
      var e;
      (this.trackingId = "g0"),
        (this.init = (e) => {
          var t, i, n, r, s, o;
          J("Gio Web SDK 初始化中...", "info");
          const {
            initOptions: a,
            currentPage: d,
            sendVisit: l,
            sendPage: c,
          } = this.dataStore;
          a(e),
            (this.useEmbeddedInherit =
              null ===
                (i =
                  null === (t = this.plugins) || void 0 === t
                    ? void 0
                    : t.gioEmbeddedAdapter) || void 0 === i
                ? void 0
                : i.main(e)),
            (this.useHybridInherit =
              null ===
                (r =
                  null === (n = this.plugins) || void 0 === n
                    ? void 0
                    : n.gioHybridAdapter) || void 0 === r
                ? void 0
                : r.main(e)),
            null == this || this.initCallback(),
            d.hookHistory(),
            d.parsePage(),
            null === (s = this.emitter) || void 0 === s || s.emit(le, this),
            J("Gio Web SDK 初始化完成！", "success"),
            this.useEmbeddedInherit || l(),
            c(),
            (this.gioSDKInitialized = !0),
            (this.vdsConfig.gioSDKInitialized = !0),
            (window[this.vds] = this.vdsConfig),
            null === (o = this.emitter) ||
              void 0 === o ||
              o.emit("SDK_INITIALIZED_COMPLATE", this);
        }),
        (this.setOption = (e, t) => {
          if (L(s, e)) {
            const i = this.dataStore.setOption(e, t);
            return i && o[e] && J(`已${t ? "开启" : "关闭"}${o[e]}`, "info"), i;
          }
          return J(`不存在可修改的配置项：${e}，请检查后重试!`, "warn"), !1;
        }),
        (this.getOption = (e) => this.dataStore.getOption(e)),
        (this.setGeneralProps = (e) => {
          S(e) && !$(e)
            ? ((this.dataStore.generalProps = Object.assign(
                Object.assign({}, this.dataStore.generalProps),
                e
              )),
              V(this.dataStore.generalProps).forEach((e) => {
                L([void 0, null], this.dataStore.generalProps[e]) &&
                  (this.dataStore.generalProps[e] = "");
              }))
            : this.callError("setGeneralProps");
        }),
        (this.clearGeneralProps = (e) => {
          N(e) && !$(e)
            ? e.forEach((e) => {
                F(this.dataStore.generalProps, e);
              })
            : (this.dataStore.generalProps = {});
        }),
        (this.reissuePage = () => {
          this.dataStore.sendPage();
        }),
        (this.notRecommended = () =>
          J(
            "不推荐的方法使用，建议使用 gio('setOption', [optionName], [value])!",
            "info"
          )),
        (this.callError = (e, t = !0, i = "参数不合法") =>
          J(`${t ? "调用" : "设置"} ${e} 失败，${i}!`, "warn")),
        (this.gioEnvironment = "cdp"),
        (this.sdkVersion = "3.8.3"),
        (this.vds = window.gioCompatibilityVds ? "gdp_vds" : "vds"),
        (this.utils = Object.assign(Object.assign(Object.assign({}, z), te), {
          qs: ge,
        })),
        (this.emitter = {
          all: (e = e || new Map()),
          on: function (t, i) {
            var n = e.get(t);
            n ? n.push(i) : e.set(t, [i]);
          },
          off: function (t, i) {
            var n = e.get(t);
            n && (i ? n.splice(n.indexOf(i) >>> 0, 1) : e.set(t, []));
          },
          emit: function (t, i) {
            var n = e.get(t);
            n &&
              n.slice().map(function (e) {
                e(i);
              }),
              (n = e.get("*")) &&
                n.slice().map(function (e) {
                  e(t, i);
                });
          },
        }),
        (this.gioSDKInitialized = !1),
        (this.storage = Yt),
        (this.plugins = new Kt(this)),
        this.plugins.innerPluginInit();
    }
  }
  class ei {
    constructor(e) {
      var t;
      this.growingIO = e;
      const { projectId: i } = this.growingIO.vdsConfig,
        {
          getItem: n,
          setItem: r,
          getKeys: s,
          removeItem: o,
        } = this.growingIO.storage;
      (this.getItem = n),
        (this.setItem = r),
        (this.getKeys = s),
        (this.removeItem = o),
        (this.sIdStorageName = i + "_gdp_session_id"),
        (this.uidStorageName = "gdp_user_id_gioenc"),
        (this.userIdStorageName = i + "_gdp_cs1_gioenc"),
        (this.userKeyStorageName = i + "_gdp_user_key_gioenc"),
        (this.gioIdStorageName = i + "_gdp_gio_id_gioenc"),
        null === (t = this.growingIO.emitter) ||
          void 0 === t ||
          t.on(ue, () => {
            this.growingIO.gioSDKInitialized &&
              (this.growingIO.dataStore.sendVisit(!0),
              this.growingIO.dataStore.sendPage(!0));
          });
    }
    get sessionId() {
      return (
        this.getItem(this.sIdStorageName) ||
        ((this.sessionId = Dt()), this.sessionId)
      );
    }
    set sessionId(e) {
      var t;
      e || (e = Dt());
      const i = this.getItem(this.sIdStorageName) || this.prevSessionId,
        { sessionExpires: n = 30 } = this.growingIO.vdsConfig;
      this.setItem(this.sIdStorageName, e, +Date.now() + 60 * n * 1e3),
        i !== e &&
          (this.getKeys()
            .filter((e) => /.+_gdp_session_id_.+/.test(e))
            .forEach((e) => {
              this.removeItem(e);
            }),
          null === (t = this.growingIO.emitter) ||
            void 0 === t ||
            t.emit(ue, {
              newSessionId: e,
              oldSessionId: i,
            })),
        (this.prevSessionId = e);
    }
    get uid() {
      return this.getItem(this.uidStorageName) || ((this.uid = Dt()), this.uid);
    }
    set uid(e) {
      var t;
      const i = this.getItem(this.uidStorageName) || this.prevUId;
      this.setItem(this.uidStorageName, e),
        i !== e &&
          (null === (t = this.growingIO.emitter) ||
            void 0 === t ||
            t.emit("UID_UPDATE", {
              newUId: e,
              oldUId: i,
            })),
        (this.prevUId = e);
    }
    get userId() {
      return this.getItem(this.userIdStorageName) || "";
    }
    set userId(e) {
      var t;
      const i = this.getItem(this.userIdStorageName) || this.prevUserId;
      this.setItem(this.userIdStorageName, e),
        i !== e &&
          (null === (t = this.growingIO.emitter) ||
            void 0 === t ||
            t.emit(ce, {
              newUserId: e,
              oldUserId: i,
              userKey: this.userKey,
            })),
        e && (this.gioId = e),
        (this.prevUserId = e);
    }
    get userKey() {
      return this.getItem(this.userKeyStorageName) || "";
    }
    set userKey(e) {
      var t;
      const i = this.getItem(this.userKeyStorageName) || this.prevUserKey;
      this.setItem(this.userKeyStorageName, e),
        i !== e &&
          (null === (t = this.growingIO.emitter) ||
            void 0 === t ||
            t.emit(he, {
              newUserKey: e,
              oldUserKey: i,
              userId: this.userId,
            })),
        (this.prevUserKey = e);
    }
    get gioId() {
      return this.getItem(this.gioIdStorageName) || "";
    }
    set gioId(e) {
      var t;
      const i = this.getItem(this.gioIdStorageName) || this.prevGioId;
      this.setItem(this.gioIdStorageName, e),
        i !== e &&
          (null === (t = this.growingIO.emitter) ||
            void 0 === t ||
            t.emit("GIOID_UPDATE", {
              newGioId: e,
              oldGioId: i,
            })),
        (this.prevGioId = e);
    }
  }
  class ti {
    constructor(e) {
      (this.growingIO = e),
        (this.main = () => {
          var e;
          const {
              sdkVersion: t,
              useEmbeddedInherit: i,
              vdsConfig: n,
              userStore: r,
              dataStore: s,
              trackingId: o,
            } = this.growingIO,
            { path: a, query: d } = s.currentPage;
          let l = {
            appVersion: n.version,
            dataSourceId: n.dataSourceId,
            deviceId: r.uid,
            domain: i ? n.appId : window.location.host,
            gioId: r.gioId,
            language: navigator.language,
            path: a,
            platform: n.platform,
            query: d,
            referralPage:
              (null === (e = s.lastPageEvent) || void 0 === e
                ? void 0
                : e.referralPage) || "",
            screenHeight: window.screen.height,
            screenWidth: window.screen.width,
            sdkVersion: t,
            sessionId: r.sessionId,
            timestamp: +Date.now(),
            title: document.title.slice(0, 255),
            userId: r.userId,
          };
          if (
            (n.enableIdMapping && (l.userKey = r.userKey),
            $(n.ignoreFields) ||
              n.ignoreFields.forEach((e) => {
                F(l, e);
              }),
            i && !$(this.minpExtraParams))
          ) {
            const e = Object.assign({}, l);
            W(
              Object.assign(Object.assign({}, l), this.minpExtraParams),
              (t, i) => {
                var r;
                L(n.embeddedIgnore, i)
                  ? ((l[i] = e[i]),
                    "domain" === i && (l[i] = window.location.host))
                  : (l[i] =
                      null !== (r = this.minpExtraParams[i]) && void 0 !== r
                        ? r
                        : l[i]);
              }
            );
          }
          return (l.trackingId = o), l;
        }),
        (this.minpExtraParams = {});
    }
  }
  class ii {
    constructor(e) {
      (this.growingIO = e),
        (this.parsePage = () => {
          const { hashtag: e } = this.growingIO.vdsConfig,
            t = location.pathname,
            i = location.search,
            n = location.hash,
            r = n.indexOf("?");
          (this.domain = window.location.host),
            (this.title = document.title.slice(0, 255)),
            (this.time = +Date.now()),
            (this.path = t),
            (this.query = i),
            e &&
              (r > -1
                ? ((this.path += n.slice(0, r)),
                  (this.query = this.query + "&" + n.slice(r + 1)))
                : (this.path += n)),
            this.query &&
              L(["?", "&"], this.query.charAt(0)) &&
              (this.query = this.query.slice(1));
        }),
        (this._getNoHashHref = () => {
          const {
            protocol: e,
            host: t,
            pathname: i,
            search: n,
          } = window.location;
          return `${e}://${t}${i}${n}`;
        }),
        (this.pageListener = () => {
          const { hashtag: e } = this.growingIO.vdsConfig;
          let t = window.location.href,
            i = this.lastHref;
          e || ((t = this._getNoHashHref()), (i = this.lastNoHashHref)),
            i !== t && (this.parsePage(), this.buildPageEvent());
        }),
        (this.hookHistory = () => {
          const e = window.history.pushState,
            t = window.history.replaceState,
            i = this;
          e &&
            Z(
              () =>
                (window.history.pushState = function () {
                  e.apply(window.history, arguments),
                    setTimeout(i.pageListener);
                })
            ),
            t &&
              Z(
                () =>
                  (window.history.replaceState = function () {
                    t.apply(window.history, arguments),
                      setTimeout(i.pageListener);
                  })
              ),
            Q(window, "popstate", this.pageListener);
          const { hashtag: n } = this.growingIO.vdsConfig;
          n && Q(window, "hashchange", this.pageListener);
        }),
        (this.buildPageEvent = (e) => {
          const {
            dataStore: {
              lastPageEvent: t,
              eventContextBuilder: i,
              eventConverter: n,
            },
          } = this.growingIO;
          let r = Object.assign(
            Object.assign(
              {
                eventType: "PAGE",
              },
              i()
            ),
            {
              protocolType: location.protocol.substring(
                0,
                location.protocol.length - 1
              ),
              referralPage:
                (null == t ? void 0 : t.path) === this.path &&
                (null == t ? void 0 : t.query) === this.query
                  ? null == t
                    ? void 0
                    : t.referralPage
                  : (null == t ? void 0 : t.path)
                  ? this.lastHref
                  : document.referrer,
            }
          );
          $(e) || (r = Object.assign(Object.assign({}, r), e)),
            (r.timestamp = this.time),
            n(r),
            (this.lastHref = window.location.href),
            (this.lastNoHashHref = this._getNoHashHref()),
            (this.lastLocation = Object.assign({}, window.location));
        }),
        (this.title = document.title.slice(0, 255)),
        (this.lastLocation = Object.assign({}, window.location));
    }
  }
  const ni = {
    referralPage: document.referrer,
  };
  class ri {
    constructor(r) {
      var a, l;
      (this.growingIO = r),
        (this.ALLOW_SETTING = Object.assign(
          Object.assign({}, t),
          "saas" === this.growingIO.gioEnvironment ? n : i
        )),
        (this.allowOptKeys = Object.keys(this.ALLOW_SETTING)),
        (this.trackTimers = {}),
        (this.initStorageId = () => {
          const e = this.growingIO.storage.getItem(this.seqStorageIdName) || {};
          let t = Object.assign({}, e);
          F(t, "globalKey"),
            (t = S(t) && !w(t) ? t : {}),
            (this._esid = {}),
            V(t).forEach((e) => {
              this._esid[e] =
                y(Number(t[e])) || t[e] >= 1e9 || 1 > t[e] ? 1 : t[e];
            }),
            M(t, this._esid) || this.setSequenceIds("esid", this._esid);
          const i = Number(e.globalKey);
          (this._gsid = y(i) || i >= 1e9 || 1 > i ? 1 : i),
            i !== this._gsid && this.setSequenceIds("gsid", this._gsid);
        }),
        (this.setSequenceIds = (e, t) => {
          let i = this.growingIO.storage.getItem(this.seqStorageIdName) || {};
          "gsid" === e
            ? (i.globalKey = t)
            : (i = Object.assign(Object.assign({}, i), t)),
            this.growingIO.storage.setItem(this.seqStorageIdName, i);
        }),
        (this.initOptions = (t) => {
          var i, n, r, s, a, l, c;
          const { projectId: h, dataSourceId: u, appId: g } = t;
          this.initialDataSourceId = u;
          const p = {};
          this.allowOptKeys.forEach((i) => {
            const n = this.ALLOW_SETTING[i].type;
            let r = N(n) ? !L(n, X(t[i])) : X(t[i]) !== n;
            "platform" !== i || L(e, t[i]) || (r = !0),
              r
                ? (p[i] = this.ALLOW_SETTING[i].default)
                : "ignoreFields" === i
                ? (p.ignoreFields = t.ignoreFields.filter((e) => L(d, e)))
                : ((p[i] = t[i]),
                  L(["dataCollect", "autotrack"], i) &&
                    (p[i] || J("已关闭" + o[i], "info")));
          }),
            (p.sessionExpires = Math.round(p.sessionExpires)),
            (y(p.sessionExpires) ||
              1 > p.sessionExpires ||
              p.sessionExpires > 360) &&
              (p.sessionExpires = 30),
            "Cookie" === this.growingIO.storage.type &&
              p.cookieDomain &&
              kt(p.cookieDomain) &&
              (this.growingIO.storage.domain = p.cookieDomain),
            (this.growingIO.vdsConfig = Object.assign(
              Object.assign(
                Object.assign(
                  {},
                  null !== (i = window.vds) && void 0 !== i ? i : {}
                ),
                p
              ),
              {
                projectId: h,
                dataSourceId: u,
                appId: g,
                performance: {
                  monitor:
                    null ===
                      (r =
                        null === (n = p.performance) || void 0 === n
                          ? void 0
                          : n.monitor) ||
                    void 0 === r ||
                    r,
                  exception:
                    null ===
                      (a =
                        null === (s = p.performance) || void 0 === s
                          ? void 0
                          : s.exception) ||
                    void 0 === a ||
                    a,
                  network:
                    null !==
                      (c =
                        null === (l = p.performance) || void 0 === l
                          ? void 0
                          : l.network) &&
                    void 0 !== c &&
                    c,
                },
              }
            )),
            (window.vds = this.growingIO.vdsConfig),
            (this.seqStorageIdName = h + "_gdp_sequence_ids");
        }),
        (this.setOption = (e, t) => {
          var i;
          const {
              vdsConfig: n,
              callError: r,
              uploader: o,
              emitter: a,
            } = this.growingIO,
            d = O(e) && L(s, e),
            l =
              d &&
              typeof t ===
                ((null === (i = this.ALLOW_SETTING[e]) || void 0 === i
                  ? void 0
                  : i.type) || "string"),
            c = Object.assign({}, n);
          return d && l
            ? ((n[e] = t),
              "dataCollect" === e &&
                c.dataCollect !== t &&
                (t
                  ? (this.sendVisit(!0), this.sendPage())
                  : this.growingIO.clearTrackTimer()),
              L(["host", "scheme"], e) && (null == o || o.generateHost()),
              null == a ||
                a.emit("OPTION_CHANGE", {
                  optionName: e,
                  optionValue: t,
                }),
              (window.vds[e] = t),
              !0)
            : (r("setOption > " + e), !1);
        }),
        (this.getOption = (e) => {
          const { vdsConfig: t, callError: i } = this.growingIO;
          return e && K(t, j(e))
            ? t[j(e)]
            : w(e)
            ? Object.assign({}, t)
            : void i("getOption > " + e);
        }),
        (this.sendVisit = (e) => {
          const {
            userStore: { sessionId: t },
            vdsConfig: { projectId: i, dataCollect: n },
            storage: r,
          } = this.growingIO;
          if (n) {
            const n = `${i}_gdp_session_id_${t}`,
              s = r.getItem(n);
            (!e && L([!0, "true"], s)) ||
              (this.buildVisitEvent(), r.setItem(n, !0));
          }
        }),
        (this.buildVisitEvent = (e) => {
          const {
              dataStore: { eventContextBuilder: t, eventConverter: i },
            } = this.growingIO,
            n = this.lastVisitEvent;
          let r = Object.assign(
            Object.assign(
              {
                eventType: "VISIT",
              },
              t()
            ),
            {
              referralPage: n.referralPage,
            }
          );
          $(e) ||
            ((r.session = (null == e ? void 0 : e.session) || r.session),
            (r.trackingId = null == e ? void 0 : e.trackingId),
            (r = Object.assign(Object.assign({}, r), e))),
            (null == n ? void 0 : n.path) &&
              ((r.title = n.title),
              (r.path = n.path),
              (r.query = n.query),
              (r.timestamp = n.timestamp)),
            i(r);
        }),
        (this.sendPage = (e) => {
          e && this.currentPage.parsePage(), this.currentPage.buildPageEvent();
        }),
        (this.buildErrorEvent = (e) => {
          const {
            dataStore: { eventContextBuilder: t, eventConverter: i },
          } = this.growingIO;
          i(
            Object.assign(
              {
                eventType: "CUSTOM",
                pageShowTimestamp: this.currentPage.time,
                eventName: "onError",
                attributes: e,
              },
              t()
            )
          );
        }),
        (this.currentPage = new ii(this.growingIO)),
        (this.eventContextBuilderInst = new ti(this.growingIO)),
        (this.eventContextBuilder = this.eventContextBuilderInst.main),
        (this.generalProps = {}),
        (this.localStore = new Xt()),
        (this._lastVisitEvent = ni),
        null === (a = this.growingIO.emitter) ||
          void 0 === a ||
          a.on("onComposeAfter", ({ composedEvent: e }) => {
            ("VISIT" !== e.eventType && "vst" !== e.t) ||
              e.trackingId !== this.growingIO.trackingId ||
              ((this.lastVisitEvent = e), (this._lastVisitEvent = e));
          }),
        (this.lastPageEvent = {}),
        null === (l = this.growingIO.emitter) ||
          void 0 === l ||
          l.on("onComposeAfter", ({ composedEvent: e }) => {
            ("PAGE" !== e.eventType && "page" !== e.t) ||
              e.trackingId !== this.growingIO.trackingId ||
              (this.lastPageEvent = e);
          });
    }
    get esid() {
      const e = this.growingIO.storage.getItem(this.seqStorageIdName) || {};
      let t = Object.assign({}, e);
      return (
        F(t, "globalKey"),
        (t = S(t) && !w(t) ? t : {}),
        (this._esid = {}),
        V(t).forEach((e) => {
          this._esid[e] = y(Number(t[e])) || t[e] >= 1e9 || 1 > t[e] ? 1 : t[e];
        }),
        this._esid
      );
    }
    set esid(e) {
      const t = {};
      V(e).forEach((i) => {
        t[i] = y(e[i]) || e[i] >= 1e9 || 1 > e[i] ? 1 : e[i];
      }),
        M(this._esid, t) ||
          ((this._esid = t), this.setSequenceIds("esid", this._esid));
    }
    get gsid() {
      const e = this.growingIO.storage.getItem(this.seqStorageIdName) || {},
        t = Number(e.globalKey);
      return (this._gsid = y(t) || t >= 1e9 || 1 > t ? 1 : t), this._gsid;
    }
    set gsid(e) {
      y(Number(e)) || e >= 1e9 || 1 > e ? (this._gsid = 1) : (this._gsid = e),
        this.setSequenceIds("gsid", this._gsid);
    }
    get lastVisitEvent() {
      var e;
      const { sessionId: t } = this.growingIO.userStore;
      return this._lastVisitEvent.path
        ? (t !== this._lastVisitEvent.sessionId && (this._lastVisitEvent = ni),
          this._lastVisitEvent)
        : null !==
            (e = Z(() =>
              this.localStore.getItem(t + "_gdp_last_vst_gioenc")
            )) && void 0 !== e
        ? e
        : ni;
    }
    set lastVisitEvent(e) {
      this.localStore
        .getKeys()
        .filter((e) => /.+_gdp_last_vst/.test(e))
        .forEach((e) => {
          this.localStore.removeItem(e);
        });
      const { sessionId: t } = this.growingIO.userStore;
      this.localStore.setItem(t + "_gdp_last_vst_gioenc", JSON.stringify(e));
    }
  }
  class si extends ri {
    constructor(e) {
      super(e),
        (this.growingIO = e),
        (this.eventConverter = (e) => {
          var t;
          const { vdsConfig: i, dataStore: n, uploader: r } = this.growingIO;
          if (i.dataCollect) {
            e.trackingId === this.growingIO.trackingId &&
              ((e.globalSequenceId = n.gsid),
              (e.eventSequenceId = n.esid[e.eventType] || 1));
            const i = {};
            W(e, (e, t) => {
              var n;
              if ("element" === t) {
                const t = null !== (n = A(e)) && void 0 !== n ? n : {};
                W(t, (e, t) => {
                  ($(e) && 0 !== e) || (i[t] = e);
                });
              } else (($(e) || w(e)) && 0 !== e) || (i[t] = e);
            }),
              e.trackingId === this.growingIO.trackingId &&
                ((this.growingIO.dataStore.gsid += 1),
                (this.growingIO.dataStore.esid = Object.assign(
                  Object.assign({}, this.growingIO.dataStore.esid),
                  {
                    [i.eventType]:
                      (this.growingIO.dataStore.esid[i.eventType] || 1) + 1,
                  }
                ))),
              null === (t = this.growingIO.emitter) ||
                void 0 === t ||
                t.emit("onComposeAfter", {
                  composedEvent: Object.assign({}, i),
                }),
              e.trackingId === this.growingIO.trackingId && r.commitRequest(i);
          }
        });
    }
  }
  class oi {
    constructor(e) {
      (this.growingIO = e),
        (this.commitRequest = (e) => {
          const t = Object.assign({}, e);
          this.requestQueue.push(
            Object.assign(Object.assign({}, t), {
              requestType: Rt() ? "Beacon" : "XHR",
            })
          ),
            this.initiateRequest();
        }),
        (this.initiateRequest = () => {
          var e, t;
          if (
            [...this.requestQueue].length > 0 &&
            this.requestingNum < this.requestLimit
          ) {
            const {
              vdsConfig: i,
              emitter: n,
              plugins: r,
              useHybridInherit: s,
            } = this.growingIO;
            if (
              ((this.requestQueue = [...this.requestQueue].filter(
                (e) =>
                  (this.retryIds[e.globalSequenceId || e.esid] || 0) <=
                  this.retryLimit
              )),
              $(this.requestQueue))
            )
              return;
            const o = this.requestQueue.shift(),
              { requestType: a } = o;
            if (
              (null == n ||
                n.emit("onSendBefore", {
                  requestData: o,
                }),
              F(o, ["requestType", "trackingId"]),
              i.debug &&
                console.log(
                  "[GrowingIO Debug]:",
                  JSON.stringify(o, null, 2).replace(
                    /\"/g,
                    (() => {
                      const e = window.navigator.userAgent;
                      return (
                        /(\d+\.\d)?(?:\.\d)?\s+safari\/?(\d+\.\d+)?/i.test(e) &&
                        !/chrome\/(\d+\.\d+)/i.test(e)
                      );
                    })()
                      ? ""
                      : '"'
                  )
                ),
              (this.requestingNum += 1),
              s)
            )
              return this.requestSuccessFn(o), !1;
            let d = Object.assign({}, o);
            switch (
              (i.compress &&
              (null === (e = null == r ? void 0 : r.gioCompress) || void 0 === e
                ? void 0
                : e.compressToUint8Array)
                ? ((this.compressType = "1"),
                  (d =
                    null === (t = null == r ? void 0 : r.gioCompress) ||
                    void 0 === t
                      ? void 0
                      : t.compressToUint8Array(JSON.stringify([d]))))
                : ((this.compressType = "0"), (d = JSON.stringify([d]))),
              a)
            ) {
              case "Beacon":
              default:
                this.sendByBeacon(o, d);
                break;
              case "XHR":
                this.sendByXHR(o, d);
                break;
              case "Image":
                this.sendByImage(o, d);
            }
          }
        }),
        (this.generateURL = () =>
          `${this.requestURL}?stm=${+Date.now()}&compress=${
            this.compressType
          }`),
        (this.sendByBeacon = (e, t) => {
          navigator.sendBeacon(this.generateURL(), t)
            ? this.requestSuccessFn(e)
            : this.requestFailFn(e, "Beacon");
        }),
        (this.sendByXHR = (e, t) => {
          var i;
          const n = L(
              ["unload", "beforeunload", "pagehide"],
              null ===
                (i =
                  null === window || void 0 === window
                    ? void 0
                    : window.event) || void 0 === i
                ? void 0
                : i.type
            ),
            r = new XMLHttpRequest();
          if (r)
            return (
              r.open("POST", this.generateURL(), n),
              (r.onreadystatechange = () => {
                4 === r.readyState && 204 === r.status
                  ? this.requestSuccessFn(e)
                  : this.requestFailFn(e, "XHR");
              }),
              r.setRequestHeader("Content-Type", "text/plain;charset=UTF-8"),
              void r.send(t)
            );
          if (
            null === window || void 0 === window
              ? void 0
              : window.XDomainRequest
          ) {
            const i = new window.XDomainRequest();
            i.open(
              "POST",
              this.generateURL().replace("https://", "http://"),
              n
            ),
              (i.onload = () => {
                204 === i.status
                  ? this.requestSuccessFn(e)
                  : this.requestFailFn(e, "XHR");
              }),
              (i.onerror = i.ontimeout =
                () => {
                  this.requestFailFn(e, "XHR");
                }),
              i.send(t);
          }
        }),
        (this.sendByImage = (e, t) => {
          const i = `${this.generateURL()}&data=${t}`;
          let n = document.createElement("img");
          (n.width = 1),
            (n.height = 1),
            (n.onload = () => {
              this.requestSuccessFn(e), this.clearImage(n);
            }),
            (n.onerror = n.onabort =
              () => {
                this.requestFailFn(e, "Image"), this.clearImage(n);
              }),
            (n.src = i);
        }),
        (this.clearImage = (e) => {
          (e.src = ""),
            (e.onload = () => {}),
            (e.onerror = e.onerabort = () => {}),
            (e = null);
        }),
        (this.requestSuccessFn = (e) => {
          var t;
          this.requestingNum -= 1;
          const i = e.globalSequenceId || e.esid || -1;
          this.retryIds[i] && (this.retryIds[i] = 0),
            (this.growingIO.userStore.sessionId =
              this.growingIO.userStore.sessionId),
            null === (t = this.growingIO.emitter) ||
              void 0 === t ||
              t.emit("onSendAfter", {
                requestData: e,
              }),
            this.initiateRequest();
        }),
        (this.requestFailFn = (e, t) => {
          this.requestingNum -= 1;
          const i = e.globalSequenceId || e.esid || -1;
          this.retryIds[i] || (this.retryIds[i] = 0), (this.retryIds[i] += 1);
          const n = this.requestQueue.some(
            (t) =>
              t.globalSequenceId === e.globalSequenceId && t.esid === e.esid
          );
          let r = t;
          this.retryIds[i] < this.retryLimit + 1 ||
            ((r = "Beacon" === t ? "XHR" : "XHR" === t ? "Image" : void 0),
            (this.retryIds[i] = 0)),
            !n &&
              r &&
              this.requestQueue.push(
                Object.assign(Object.assign({}, e), {
                  requestType: r,
                })
              );
        }),
        (this.requestQueue = []),
        (this.requestLimit = 10),
        (this.requestTimeout = 5e3),
        (this.retryLimit = 1),
        (this.retryIds = {}),
        (this.requestingNum = 0),
        (this.requestURL = "");
    }
  }
  class ai extends oi {
    constructor(e) {
      super(e),
        (this.growingIO = e),
        (this.generateHost = () => {
          let {
            scheme: e,
            host: t = "",
            projectId: i,
          } = this.growingIO.vdsConfig;
          e
            ? H(j(e), "://") || (e += "://")
            : (e =
                (location.protocol.indexOf("http") > -1
                  ? location.protocol.replace(":", "")
                  : "https") + "//"),
            q(t, "http") &&
              (t = t.substring(t.indexOf("://") + (H(j(e), "://") ? 3 : 0))),
            (this.requestURL = `${e}${t}/v3/projects/${i}/collect`);
        }),
        (this.requestURL = ""),
        this.generateHost();
    }
  }
  class di extends Qt {
    constructor() {
      super(),
        (this.registerPlugins = (e) => {
          N(e)
            ? (e.forEach((t, i) => {
                var n, r;
                $(t) || w(t)
                  ? J("插件不合法，跳过加载!", "warn")
                  : (null === (n = t.js) || void 0 === n
                      ? void 0
                      : n.default) &&
                    (e[i] = Object.assign(
                      Object.assign(
                        {},
                        null === (r = t.js) || void 0 === r ? void 0 : r.default
                      ),
                      {
                        options: t.options,
                      }
                    ));
              }),
              (e = D(e)),
              (this.plugins.pluginItems = [...this.plugins.pluginItems, ...e]),
              this.plugins.installAll(e))
            : J("插件注册失败，请检查!", "error");
        }),
        (this.getPlugins = () => this.plugins.pluginItems),
        (this.initCallback = () => {
          var e, t;
          (this.userStore = new ei(this)),
            (this.uploader = new ai(this)),
            null ===
              (t =
                null === (e = this.plugins) || void 0 === e
                  ? void 0
                  : e.gioEventAutoTracking) ||
              void 0 === t ||
              t.main(),
            this.vdsConfig.enableIdMapping || (this.userStore.userKey = "");
        }),
        (this.setTrackerScheme = (e) => {
          L(["http", "https"], e)
            ? (this.dataStore.setOption("scheme", e), this.notRecommended())
            : this.callError("scheme", !1);
        }),
        (this.setTrackerHost = (e) => {
          ae.test(e) || de.test(e)
            ? (this.dataStore.setOption("host", e), this.notRecommended())
            : this.callError("host", !1);
        }),
        (this.setDataCollect = (e) => {
          this.setOption("dataCollect", !!e), this.notRecommended();
        }),
        (this.setAutotrack = (e) => {
          this.setOption("autotrack", !!e), this.notRecommended();
        }),
        (this.enableDebug = (e) => {
          this.setOption("debug", !!e), this.notRecommended();
        }),
        (this.enableHT = (e) => {
          this.setOption("hashtag", !!e), this.notRecommended();
        }),
        (this.getVisitorId = () => this.userStore.uid),
        (this.getDeviceId = () => this.userStore.uid),
        (this.setUserAttributes = (e, t) => {
          var i, n;
          !$(e) && S(e)
            ? null ===
                (n =
                  null === (i = this.plugins) || void 0 === i
                    ? void 0
                    : i.gioCustomTracking) ||
              void 0 === n ||
              n.buildUserAttributesEvent(e, t)
            : this.callError("setUserAttributes");
        }),
        (this.setUserId = (e, t) => {
          if (ie(j(e).trim())) {
            const i = this.userStore.gioId;
            this.vdsConfig.enableIdMapping &&
              (this.userStore.userKey =
                !w(t) && j(t).length > 0 ? j(t).slice(0, 1e3) : ""),
              (e = j(e).slice(0, 1e3)),
              (this.userStore.userId = e),
              i && i !== e && (this.userStore.sessionId = ""),
              i || i === e || this.dataStore.sendVisit(!0);
          } else this.clearUserId(), this.callError("setUserId");
        }),
        (this.clearUserId = () => {
          (this.userStore.userId = ""), (this.userStore.userKey = "");
        }),
        (this.track = (e, t, i, n) => {
          var r, s;
          (
            (null ===
              (s =
                null === (r = this.plugins) || void 0 === r
                  ? void 0
                  : r.gioCustomTracking) || void 0 === s
              ? void 0
              : s.buildCustomEvent) || function () {}
          )(
            e,
            Object.assign(
              Object.assign({}, this.dataStore.generalProps),
              S(t) && !$(t) ? t : {}
            ),
            i,
            n
          );
        }),
        (this.sendPage = (e) => this.dataStore.currentPage.buildPageEvent(e)),
        (this.sendVisit = (e) => this.dataStore.buildVisitEvent(e)),
        (this.trackTimerStart = (e, t) => {
          this.vdsConfig.dataCollect &&
            ee(e, () => {
              const i = Dt();
              T(t)
                ? ((this.dataStore.trackTimers[i] = {
                    eventName: e,
                    leng: 0,
                    start: +Date.now(),
                  }),
                  t(i))
                : J("回调方法不合法，返回timerId失败!");
            });
        }),
        (this.trackTimerPause = (e) => {
          if (e && this.dataStore.trackTimers[e]) {
            const t = this.dataStore.trackTimers[e];
            t.start && (t.leng = t.leng + (+Date.now() - t.start)),
              (t.start = 0);
          }
        }),
        (this.trackTimerResume = (e) => {
          if (e && this.dataStore.trackTimers[e]) {
            const t = this.dataStore.trackTimers[e];
            0 === t.start && (t.start = +Date.now());
          }
        }),
        (this.trackTimerEnd = (e, t) => {
          if (this.vdsConfig.dataCollect) {
            const i = 864e5;
            if (e && this.dataStore.trackTimers[e]) {
              const n = this.dataStore.trackTimers[e];
              if (0 !== n.start) {
                const e = +Date.now() - n.start;
                n.leng = e > 0 ? n.leng + e : 0;
              }
              this.track(
                n.eventName,
                Object.assign(Object.assign({}, t), {
                  event_duration: n.leng > i ? 0 : n.leng / 1e3,
                })
              ),
                this.removeTimer(e);
            } else J("未查找到对应的计时器，请检查!", "error");
          }
        }),
        (this.removeTimer = (e) => {
          e &&
            this.dataStore.trackTimers[e] &&
            delete this.dataStore.trackTimers[e];
        }),
        (this.clearTrackTimer = () => {
          this.dataStore.trackTimers = {};
        }),
        (this.dataStore = new si(this));
    }
  }
  let li;
  return (
    (function () {
      var e, t, i, n, s;
      let o = window.gioCompatibilityVds ? "gdp_vds" : "vds";
      if (null === (e = window[o]) || void 0 === e ? void 0 : e.gioSDKInstalled)
        return (
          (li = window.gdp),
          void J(
            "SDK重复加载，请检查是否重复加载SDK或接入其他平台SDK导致冲突!",
            "warn"
          )
        );
      window[o] = Object.assign(
        Object.assign({}, null !== (t = window[o]) && void 0 !== t ? t : {}),
        {
          gioSDKInstalled: !0,
        }
      );
      const d = new di();
      li = function () {
        var e;
        const t = arguments[0];
        if (O(t) && L(r, t) && d[t]) {
          const e = P(k(arguments));
          if ("init" === t) {
            if (!ne(d)) return;
            if (!re(e)) return;
            const t = se(e);
            if (!t) return;
            const i = oe(e);
            if (!i) return;
            const { projectId: n } = t,
              { dataSourceId: r, appId: s, cdpOptions: o } = i;
            d.init(
              Object.assign(Object.assign({}, o), {
                projectId: n,
                dataSourceId: r,
                appId: s,
              })
            );
          } else if ("registerPlugins" === t) d.registerPlugins(e[0]);
          else {
            if (d.gioSDKInitialized && d.vdsConfig) return d[t](...e);
            J("SDK未初始化!", "error");
          }
        } else
          L(a, t)
            ? J(`方法 ${j(t)} 已被弃用，请移除!`, "warn")
            : J(`不存在名为 ${j(t)} 的方法调用!`, "error");
        window[o] = Object.assign(Object.assign({}, window[o]), {
          _gr_ignore_local_rule:
            null !== (e = window._gr_ignore_local_rule) && void 0 !== e && e,
          gioEnvironment: "cdp",
          gioSDKVersion: d.sdkVersion,
          gioSDKFull: d.gioSDKFull,
          canIUse: (e) => L(r, e) && d[e],
        });
      };
      const l =
          null ===
            (i = null === window || void 0 === window ? void 0 : window.gdp) ||
          void 0 === i
            ? void 0
            : i.q,
        c =
          null ===
            (n = null === window || void 0 === window ? void 0 : window.gdp) ||
          void 0 === n
            ? void 0
            : n.e,
        h =
          null ===
            (s = null === window || void 0 === window ? void 0 : window.gdp) ||
          void 0 === s
            ? void 0
            : s.ef;
      (window.gdp = li),
        (window.gdp.e = c),
        (window.gdp.ef = h),
        N(l) &&
          !$(l) &&
          l.forEach((e) => {
            li.apply(null, e);
          });
    })(),
    li
  );
});

!(function (e, t) {
  "object" == typeof exports && "undefined" != typeof module
    ? (module.exports = t())
    : "function" == typeof define && define.amd
    ? define(t)
    : ((e = "undefined" != typeof globalThis ? globalThis : e || self).gdp =
        t());
})(this, function () {
  "use strict";
  const e = ["web", "wxwv", "minp", "alip", "baidup", "qq", "bytedance"],
    t = {
      autotrack: {
        type: "boolean",
        default: !0,
      },
      compress: {
        type: "boolean",
        default: !0,
      },
      dataCollect: {
        type: "boolean",
        default: !0,
      },
      debug: {
        type: "boolean",
        default: !1,
      },
      hashtag: {
        type: "boolean",
        default: !1,
      },
      touch: {
        type: "boolean",
        default: !1,
      },
      version: {
        type: "string",
        default: "1.0.0",
      },
      platform: {
        type: "string",
        default: "web",
      },
      cookieDomain: {
        type: "string",
        default: "",
      },
      sendType: {
        type: "string",
        default: "beacon",
      },
    },
    i = {
      enableIdMapping: {
        type: "boolean",
        default: !1,
      },
      gtouchHost: {
        type: "string",
        default: "",
      },
      host: {
        type: "string",
        default: "napi.growingio.com",
      },
      ignoreFields: {
        type: "array",
        default: [],
      },
      penetrateHybrid: {
        type: "boolean",
        default: !0,
      },
      scheme: {
        type: "string",
        default:
          location.protocol.indexOf("http") > -1
            ? location.protocol.replace(":", "")
            : "https",
      },
      sessionExpires: {
        type: "number",
        default: 30,
      },
      performance: {
        type: "object",
        default: {
          monitor: !0,
          exception: !0,
        },
      },
      embeddedIgnore: {
        type: "array",
        default: [],
      },
      storageType: {
        type: "string",
        default: "cookie",
      },
      requestTimeout: {
        type: "number",
        default: 5e3,
      },
    },
    n = {},
    r = [
      "clearUserId",
      "getGioInfo",
      "getLocation",
      "getOption",
      "init",
      "setDataCollect",
      "setOption",
      "setUserId",
      "track",
      "setGeneralProps",
      "clearGeneralProps",
      "enableDebug",
      "enableHT",
      "setAutotrack",
      "setTrackerHost",
      "setTrackerScheme",
      "setUserAttributes",
      "getVisitorId",
      "getDeviceId",
      "registerPlugins",
      "getPlugins",
      "sendPage",
      "sendVisit",
      "trackTimerStart",
      "trackTimerPause",
      "trackTimerResume",
      "trackTimerEnd",
      "removeTimer",
      "clearTrackTimer",
      "updateImpression",
    ],
    s = [
      "autotrack",
      "dataCollect",
      "dataSourceId",
      "debug",
      "host",
      "hashtag",
      "scheme",
    ],
    o = {
      autotrack: "无埋点采集",
      dataCollect: "数据采集",
      debug: "调试模式",
    },
    a = ["send", "setConfig", "collectImp", "setPlatformProfile"],
    d = ["screenHeight", "screenWidth"],
    c = {
      click: "VIEW_CLICK",
      change: "VIEW_CHANGE",
      submit: "FORM_SUBMIT",
    };
  var l,
    h,
    u,
    g,
    p,
    f =
      "undefined" != typeof globalThis
        ? globalThis
        : "undefined" != typeof window
        ? window
        : "undefined" != typeof global
        ? global
        : "undefined" != typeof self
        ? self
        : {},
    m =
      "function" == typeof Array.from
        ? Array.from
        : (h ||
            ((h = 1),
            (u = function (e) {
              return "function" == typeof e;
            }),
            (g = function (e) {
              var t = (function (e) {
                var t = Number(e);
                return isNaN(t)
                  ? 0
                  : 0 !== t && isFinite(t)
                  ? (t > 0 ? 1 : -1) * Math.floor(Math.abs(t))
                  : t;
              })(e);
              return Math.min(Math.max(t, 0), 9007199254740991);
            }),
            (p = function (e) {
              var t = e.next();
              return !t.done && t;
            }),
            (l = function (e) {
              var t,
                i,
                n,
                r = this,
                s = arguments.length > 1 ? arguments[1] : void 0;
              if (void 0 !== s) {
                if (!u(s))
                  throw new TypeError(
                    "Array.from: when provided, the second argument must be a function"
                  );
                arguments.length > 2 && (t = arguments[2]);
              }
              var o = (function (e, t) {
                if (null != e && null != t) {
                  var i = e[t];
                  if (null == i) return;
                  if (!u(i)) throw new TypeError(i + " is not a function");
                  return i;
                }
              })(
                e,
                (function (e) {
                  if (null != e) {
                    if (
                      ["string", "number", "boolean", "symbol"].indexOf(
                        typeof e
                      ) > -1
                    )
                      return Symbol.iterator;
                    if (
                      "undefined" != typeof Symbol &&
                      "iterator" in Symbol &&
                      Symbol.iterator in e
                    )
                      return Symbol.iterator;
                    if ("@@iterator" in e) return "@@iterator";
                  }
                })(e)
              );
              if (void 0 !== o) {
                i = u(r) ? Object(new r()) : [];
                var a,
                  d,
                  c = o.call(e);
                if (null == c)
                  throw new TypeError(
                    "Array.from requires an array-like or iterable object"
                  );
                for (n = 0; ; ) {
                  if (!(a = p(c))) return (i.length = n), i;
                  (d = a.value), (i[n] = s ? s.call(t, d, n) : d), n++;
                }
              } else {
                var l = Object(e);
                if (null == e)
                  throw new TypeError(
                    "Array.from requires an array-like object - not null or undefined"
                  );
                var h,
                  f = g(l.length);
                for (i = u(r) ? Object(new r(f)) : Array(f), n = 0; f > n; )
                  (h = l[n]), (i[n] = s ? s.call(t, h, n) : h), n++;
                i.length = f;
              }
              return i;
            })),
          l);
  const v = (e) => L(["undefined", "null"], $(e)),
    I = (e) => "string" === $(e),
    w = (e) => "number" === $(e),
    O = (e) => "NaN" === k(Number(e)),
    b = (e) => "boolean" === $(e),
    y = (e) => "object" === $(e) && !v(e),
    T = (e) => "regexp" === $(e),
    E = (e) => L(["function", "asyncfunction"], $(e)),
    _ = (e) => Array.isArray(e) && "array" === $(e),
    S = (e) => "date" === $(e),
    N = (e) => {
      try {
        return R(e)[0];
      } catch (e) {
        return;
      }
    },
    C = (e) => {
      try {
        const t = R(e);
        return t[t.length - 1];
      } catch (e) {
        return;
      }
    },
    x = (e, t = 1) => (_(e) && w(t) ? e.slice(t > 0 ? t : 1, e.length) : e),
    A = (e) => {
      if (_(e)) {
        let t = 0;
        const i = [];
        for (const n of e) n && !F(n) && (i[t++] = n);
        return i;
      }
      return e;
    },
    P = (e, t) => e[D(e, t)],
    D = (e, t) => {
      let i = -1;
      return _(e) && e.every((e, n) => !t(e) || ((i = n), !1)), i;
    },
    L = (e, t) => ("array" === $(e) || "string" === $(e)) && e.indexOf(t) >= 0,
    R = m,
    k = (e) => (v(e) ? "" : "" + e),
    U = (e, t) => ("string" == typeof e ? e.split(t) : e),
    j = (e) => {
      if (I(e)) {
        const t = U(e, "");
        return `${N(t).toLowerCase()}${x(t).join("")}`;
      }
      return e;
    },
    G = (e, t) => !!I(e) && e.slice(0, t.length) === t,
    q = (e, t) => {
      if (I(e)) {
        const { length: i } = e;
        let n = i;
        n > i && (n = i);
        const r = n;
        return (n -= t.length), n >= 0 && e.slice(n, r) === t;
      }
      return !1;
    },
    H = {}.hasOwnProperty,
    B = (e, t) => !v(e) && H.call(e, t),
    K = (e) => (y(e) ? Object.keys(e) : []),
    W = (e, t) => {
      K(e).forEach((i) => t(e[i], i));
    },
    V = (e, t) => {
      const i = K(e);
      return !(
        !y(e) ||
        !y(t) ||
        i.length !== K(t).length ||
        L(
          i.map((i, n) => (y(e[i]) ? V(e[i], t[i]) : e[i] === t[i])),
          !1
        )
      );
    },
    M = (e, t) => {
      if (!y(e)) return !1;
      try {
        return "string" === $(t)
          ? delete e[t]
          : "array" === $(t)
          ? t.map((t) => delete e[t])
          : (T(t) &&
              K(e).forEach((i) => {
                t.test(i) && M(e, i);
              }),
            !0);
      } catch (e) {
        return !1;
      }
    },
    F = (e) => (_(e) ? 0 === e.length : y(e) ? 0 === K(e).length : !e),
    $ = (e) => ({}.toString.call(e).slice(8, -1).toLowerCase());
  var z = Object.freeze({
    __proto__: null,
    isNil: v,
    isString: I,
    isNumber: w,
    isNaN: O,
    isBoolean: b,
    isObject: y,
    isRegExp: T,
    isFunction: E,
    isArray: _,
    isDate: S,
    fixed: (e, t) =>
      w(e)
        ? Number(e.toFixed(w(t) ? t : 2))
        : I(e) && "NaN" !== k(Number(e))
        ? Number(Number(e).toFixed(w(t) ? t : 2))
        : e,
    head: N,
    last: C,
    drop: x,
    dropWhile: (e, t) => (_(e) ? e.filter((e) => !t(e)) : e),
    compact: A,
    find: P,
    findIndex: D,
    includes: L,
    arrayFrom: R,
    toString: k,
    split: U,
    lowerFirst: j,
    upperFirst: (e) => {
      if (I(e)) {
        const t = U(e, "");
        return `${N(t).toUpperCase()}${x(t).join("")}`;
      }
      return e;
    },
    startsWith: G,
    endsWith: q,
    has: B,
    keys: K,
    forEach: W,
    isEqual: V,
    get: (e, t, i) => {
      let n = e;
      return y(e)
        ? (t.split(".").forEach((e) => {
            n = n ? n[e] : i;
          }),
          n)
        : i;
    },
    unset: M,
    isEmpty: F,
    typeOf: $,
    formatDate: (e) => {
      if (S(e)) {
        const t = (e) => (10 > e ? "0" + e : e);
        return (
          e.getFullYear() +
          "-" +
          t(e.getMonth() + 1) +
          "-" +
          t(e.getDate()) +
          " " +
          t(e.getHours()) +
          ":" +
          t(e.getMinutes()) +
          ":" +
          t(e.getSeconds()) +
          "." +
          t(e.getMilliseconds())
        );
      }
      return e;
    },
  });
  const X = (e, t) => {
      console.log(
        "%c [GrowingIO]：" + e,
        {
          info: "color: #3B82F6;",
          error: "color: #EF4444;",
          warn: "color: #F59E0B;",
          success: "color: #10B981;",
        }[t] || ""
      );
    },
    J = (e) => {
      try {
        return e();
      } catch (e) {
        return;
      }
    },
    Z = (e) => {
      const t = {};
      return (
        y(e) &&
          W(e, (e, i) => {
            var n;
            const r = k(i).slice(0, 100);
            y(e)
              ? (t[r] = Z(e))
              : _(e)
              ? ((t[r] = e.slice(0, 100)),
                "cdp" ===
                  (null === (n = window.vds) || void 0 === n
                    ? void 0
                    : n.gioEnvironment) &&
                  (t[r] = t[r].join("||").slice(0, 1e3)))
              : (t[r] = v(e) ? "" : k(e).slice(0, 1e3));
          }),
        t
      );
    },
    Y = (e, t, i, n = {}) => {
      document.addEventListener
        ? e.addEventListener(
            t,
            i,
            Object.assign(
              Object.assign(
                {},
                {
                  capture: !0,
                }
              ),
              n
            )
          )
        : e.attachEvent
        ? e.attachEvent("on" + t, i)
        : (e["on" + t] = i);
    },
    Q = (e, t) =>
      I(e) && !F(e) && e.match(/^[a-zA-Z_][0-9a-zA-Z_]{0,100}$/)
        ? t()
        : (X(
            "事件名格式不正确，只能包含数字、字母和下划线，且不能以数字开头，字符总长度不能超过100!",
            "error"
          ),
          !1);
  var ee = Object.freeze({
    __proto__: null,
    consoleText: X,
    niceTry: J,
    limitObject: Z,
    addListener: Y,
    flattenObject: (e = {}) => {
      const t = Object.assign({}, e);
      return (
        K(t).forEach((e) => {
          y(t[e])
            ? (K(t[e]).forEach((i) => {
                t[`${e}_${i}`] = k(t[e][i]);
              }),
              M(t, e))
            : _(t[e])
            ? (t[e].forEach((i, n) => {
                y(i)
                  ? K(i).forEach((r) => {
                      t[`${e}_${n}_${r}`] = k(i[r]);
                    })
                  : (t[`${e}_${n}`] = k(i));
              }),
              M(t, e))
            : v(t[e]) || "" === t[e]
            ? M(t, e)
            : (t[e] = k(t[e]));
        }),
        Z(t)
      );
    },
    eventNameValidate: Q,
    getGioFunction: () => {
      var e, t, i, n;
      const r = window._gio_local_vds || "vds",
        s =
          null !==
            (t =
              null === (e = window[r]) || void 0 === e
                ? void 0
                : e.namespace) && void 0 !== t
            ? t
            : "gdp";
      return E(window[s])
        ? window[s]
        : null !==
            (n = null !== (i = window.gdp) && void 0 !== i ? i : window.gio) &&
          void 0 !== n
        ? n
        : function () {};
    },
  });
  const te = (e) => (I(e) && e.length > 0) || (w(e) && e > 0),
    ie =
      /^((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})(\.((2(5[0-5]|[0-4]\d))|[0-1]?\d{1,2})){3}/i,
    ne =
      /^(https?:\/\/)|(([a-zA-Z0-9_-])+(\.)?)*(:\d+)?(\/((\.)?(\?)?=?&?[a-zA-Z0-9_-](\?)?)*)*$/i;
  function re(e) {
    for (var t = 1; arguments.length > t; t++) {
      var i = arguments[t];
      for (var n in i) e[n] = i[n];
    }
    return e;
  }
  var se = (function e(t, i) {
    function n(e, n, r) {
      if ("undefined" != typeof document) {
        "number" == typeof (r = re({}, i, r)).expires &&
          (r.expires = new Date(Date.now() + 864e5 * r.expires)),
          r.expires && (r.expires = r.expires.toUTCString()),
          (e = encodeURIComponent(e)
            .replace(/%(2[346B]|5E|60|7C)/g, decodeURIComponent)
            .replace(/[()]/g, escape));
        var s = "";
        for (var o in r)
          r[o] &&
            ((s += "; " + o), !0 !== r[o] && (s += "=" + r[o].split(";")[0]));
        return (document.cookie = e + "=" + t.write(n, e) + s);
      }
    }
    return Object.create(
      {
        set: n,
        get: function (e) {
          if ("undefined" != typeof document && (!arguments.length || e)) {
            for (
              var i = document.cookie ? document.cookie.split("; ") : [],
                n = {},
                r = 0;
              r < i.length;
              r++
            ) {
              var s = i[r].split("="),
                o = s.slice(1).join("=");
              try {
                var a = decodeURIComponent(s[0]);
                if (((n[a] = t.read(o, a)), e === a)) break;
              } catch (e) {}
            }
            return e ? n[e] : n;
          }
        },
        remove: function (e, t) {
          n(
            e,
            "",
            re({}, t, {
              expires: -1,
            })
          );
        },
        withAttributes: function (t) {
          return e(this.converter, re({}, this.attributes, t));
        },
        withConverter: function (t) {
          return e(re({}, this.converter, t), this.attributes);
        },
      },
      {
        attributes: {
          value: Object.freeze(i),
        },
        converter: {
          value: Object.freeze(t),
        },
      }
    );
  })(
    {
      read: function (e) {
        return (
          '"' === e[0] && (e = e.slice(1, -1)),
          e.replace(/(%[\dA-F]{2})+/gi, decodeURIComponent)
        );
      },
      write: function (e) {
        return encodeURIComponent(e).replace(
          /%(2[346BF]|3[AC-F]|40|5[BDE]|60|7[BCD])/g,
          decodeURIComponent
        );
      },
    },
    {
      path: "/",
    }
  );
  const oe = () =>
      "xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx".replace(/[xy]/g, function (e) {
        const t = (16 * Math.random()) | 0;
        return ("x" === e ? t : (3 & t) | 8).toString(16);
      }),
    ae = (e) => (q(e, "_gioenc") ? e.slice(0, -7) : e),
    de = (e) => (O(Number(e)) && J(() => JSON.parse(e))) || e,
    ce = {
      A: 1,
      a: 1,
      Z: 1,
      z: 1,
      "@": 1,
      "{": 1,
    },
    le = (e) => (v(e) ? e : J(() => "gioenc-" + ue(e)) || e),
    he = (e) =>
      (I(e) && G(e, "gioenc-") && J(() => ue(e.replace("gioenc-", "")))) || e,
    ue = (e) =>
      (e = e || "")
        .split("")
        .map((e) => (ce[e] ? e : ge(e)))
        .join(""),
    ge = (e) => {
      if (/[0-9]/.test(e)) return 1 ^ +e;
      {
        let t = e.charCodeAt(0);
        return String.fromCharCode(1 ^ t);
      }
    };
  class pe {
    constructor(e) {
      (this.domain = e),
        (this.getItem = (e) =>
          de(
            he(
              se.get(ae(e), {
                domain: this.domain,
                path: "/",
              })
            )
          )),
        (this.setItem = (e, t, i) => {
          let n;
          (n = I(t)
            ? t.length
              ? q(e, "_gioenc")
                ? le(t)
                : t
              : ""
            : JSON.stringify(t)),
            se.set(ae(e), n, {
              expires: i ? new Date(i) : 3650,
              domain: this.domain,
              path: "/",
            });
        }),
        (this.removeItem = (e) => {
          se.remove(ae(e), {
            domain: this.domain,
            path: "/",
          });
        }),
        (this.hasItem = (e) => L(K(se.get()), ae(e))),
        (this.getKeys = () => K(se.get())),
        (this.type = "Cookie");
    }
  }
  class fe {
    constructor() {
      (this.getItem = (e) => {
        const t = J(() => JSON.parse(localStorage.getItem(ae(e)) || "")) || {};
        return y(t) && t.expiredAt > +Date.now() ? de(he(t.value)) : void 0;
      }),
        (this.setItem = (e, t, i) => {
          const n = null != i ? i : +new Date(9999, 12);
          localStorage.setItem(
            ae(e),
            JSON.stringify({
              value: I(t) && t.length && q(e, "_gioenc") ? le(t) : t,
              expiredAt: n,
            })
          );
        }),
        (this.removeItem = (e) => localStorage.removeItem(ae(e))),
        (this.hasItem = (e) => !!localStorage.getItem(ae(e))),
        (this.getKeys = () =>
          R(Array(localStorage.length)).map((e, t) => localStorage.key(t))),
        (this.type = "localStorage");
    }
  }
  const me = {};
  class ve {
    constructor() {
      (this.getItem = (e) => {
        const t = J(() => JSON.parse(me[ae(e)] || ""));
        return y(t) && t.expiredAt > +Date.now() ? de(he(t.value)) : void 0;
      }),
        (this.setItem = (e, t, i) => {
          const n = null != i ? i : +new Date(9999, 12);
          me[ae(e)] = JSON.stringify({
            value: I(t) && t.length ? le(t) : t,
            expiredAt: n,
          });
        }),
        (this.removeItem = (e) => M(me, ae(e))),
        (this.hasItem = (e) => B(me, ae(e))),
        (this.getKeys = () => K(me)),
        (this.type = "memory");
    }
  }
  let Ie;
  const we = /^(\.ac\.|\.br\.|\.co\.|\.com\.|\.edu\.|\.gov\.|\.org\.|\.net\.)/,
    Oe = (e) => {
      const t = [];
      try {
        const i = e.split("."),
          n = C(i);
        if (
          i.length >= 2 &&
          (isNaN(Number(n)) || 0 > Number(n) || Number(n) > 255)
        ) {
          const e = "." + i.slice(-2).join(".");
          we.test(e) ? (Ie = e) : t.push(e);
          const n = "." + i.slice(-3).join(".");
          we.test(n) || L(t, n) || t.push(n);
          const r = "." + i.slice(-4).join(".");
          we.test(r) || L(t, r) || t.push(r);
        }
      } catch (e) {}
      return t;
    },
    be = (e) => {
      let t = "";
      return e.every((e) => !ye(e) || ((t = e), !1)), t;
    },
    ye = (e) => {
      try {
        se.set("gioCookie", "yes", {
          domain: e,
        });
        const t = !!se.get("gioCookie", {
          domain: e,
        });
        return (
          se.remove("gioCookie", {
            domain: e,
          }),
          t
        );
      } catch (e) {
        return !1;
      }
    },
    Te = (e) => {
      let t,
        i,
        n,
        { storageType: r, cookieDomain: s, projectId: o } = e;
      if (
        (L(["cookie", "localstorage"], r) || (r = "cookie"),
        "cookie" === r &&
          ((n =
            navigator.userAgent.indexOf("Electron") > -1 ||
            L(["", "localhost", "127.0.0.1"], window.location.hostname) ||
            !L(["http:", "https:"], window.location.protocol)
              ? ""
              : be([
                  ...Oe(window.location.hostname),
                  window.location.hostname,
                ])),
          (i = !!n)),
        "cookie" === r && i)
      ) {
        const e = new pe(n);
        if (s) {
          let t = Oe(s);
          const i = be(F(t) ? [] : [s, ...Oe(s)]);
          i && ye(i)
            ? (e.domain = i)
            : X("指定Cookie域无效或无权限，使用默认域！", "warn");
        }
        t = e;
      } else
        t = (() => {
          try {
            const e = window.localStorage,
              t = "__storage_test__";
            return e.setItem(t, t), e.removeItem(t), !0;
          } catch (e) {
            return !1;
          }
        })()
          ? new fe()
          : new ve();
      return (
        "cookie" === r &&
          Ie &&
          ye(Ie) &&
          ((e, t, i) => {
            if (t && ye(t)) {
              let n = new pe(t);
              [
                i + "_gdp_session_id",
                "gdp_user_id_gioenc",
                i + "_gdp_cs1_gioenc",
                i + "_gdp_user_key_gioenc",
                i + "_gdp_gio_id_gioenc",
                i + "_gdp_sequence_ids",
                i + "_gdp_session_id_sent",
              ].forEach((t) => {
                const i = n.getItem(t);
                n.hasItem(t) && (e.setItem(t, i), n.removeItem(t));
              }),
                (n = void 0);
            }
          })(t, Ie, o),
        t
      );
    };
  var Ee = "OPTION_INITIALIZED",
    _e = "SDK_INITIALIZED",
    Se = "SESSIONID_UPDATE",
    Ne = "SET_USERID",
    Ce = "SET_USERKEY",
    xe = {
      name: "gioCompress",
      method: class {
        constructor(e) {
          (this.growingIO = e),
            (this._compress = (e, t, i) => {
              if (null === e) return "";
              let n,
                r,
                s,
                o = {},
                a = {},
                d = "",
                c = "",
                l = "",
                h = 2,
                u = 3,
                g = 2,
                p = [],
                f = 0,
                m = 0;
              for (s = 0; s < e.length; s += 1)
                if (
                  ((d = e.charAt(s)),
                  {}.hasOwnProperty.call(o, d) || ((o[d] = u++), (a[d] = !0)),
                  (c = l + d),
                  {}.hasOwnProperty.call(o, c))
                )
                  l = c;
                else {
                  if ({}.hasOwnProperty.call(a, l)) {
                    if (256 > l.charCodeAt(0)) {
                      for (n = 0; g > n; n++)
                        (f <<= 1),
                          m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++;
                      for (r = l.charCodeAt(0), n = 0; 8 > n; n++)
                        (f = (f << 1) | (1 & r)),
                          m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++,
                          (r >>= 1);
                    } else {
                      for (r = 1, n = 0; g > n; n++)
                        (f = (f << 1) | r),
                          m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++,
                          (r = 0);
                      for (r = l.charCodeAt(0), n = 0; 16 > n; n++)
                        (f = (f << 1) | (1 & r)),
                          m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++,
                          (r >>= 1);
                    }
                    h--, 0 === h && ((h = Math.pow(2, g)), g++), delete a[l];
                  } else
                    for (r = o[l], n = 0; g > n; n++)
                      (f = (f << 1) | (1 & r)),
                        m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++,
                        (r >>= 1);
                  h--,
                    0 === h && ((h = Math.pow(2, g)), g++),
                    (o[c] = u++),
                    (l = d + "");
                }
              if ("" !== l) {
                if ({}.hasOwnProperty.call(a, l)) {
                  if (256 > l.charCodeAt(0)) {
                    for (n = 0; g > n; n++)
                      (f <<= 1),
                        m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++;
                    for (r = l.charCodeAt(0), n = 0; 8 > n; n++)
                      (f = (f << 1) | (1 & r)),
                        m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++,
                        (r >>= 1);
                  } else {
                    for (r = 1, n = 0; g > n; n++)
                      (f = (f << 1) | r),
                        m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++,
                        (r = 0);
                    for (r = l.charCodeAt(0), n = 0; 16 > n; n++)
                      (f = (f << 1) | (1 & r)),
                        m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++,
                        (r >>= 1);
                  }
                  h--, 0 === h && ((h = Math.pow(2, g)), g++), delete a[l];
                } else
                  for (r = o[l], n = 0; g > n; n++)
                    (f = (f << 1) | (1 & r)),
                      m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++,
                      (r >>= 1);
                h--, 0 === h && ((h = Math.pow(2, g)), g++);
              }
              for (r = 2, n = 0; g > n; n++)
                (f = (f << 1) | (1 & r)),
                  m === t - 1 ? ((m = 0), p.push(i(f)), (f = 0)) : m++,
                  (r >>= 1);
              for (;;) {
                if (((f <<= 1), m === t - 1)) {
                  p.push(i(f));
                  break;
                }
                m++;
              }
              return p.join("");
            }),
            (this.compress = (e) => {
              const t = this;
              return this._compress(e, 16, function (e) {
                return t.f(e);
              });
            }),
            (this.compressToUTF16 = (e) => {
              const t = this;
              return null === e
                ? ""
                : this._compress(e, 15, function (e) {
                    return t.f(e + 32);
                  }) + " ";
            }),
            (this.compressToUint8Array = (e) => {
              const t = this.compress(e),
                i = new Uint8Array(2 * t.length);
              for (let e = 0, n = t.length; n > e; e++) {
                const n = t.charCodeAt(e);
                (i[2 * e] = n >>> 8), (i[2 * e + 1] = n % 256);
              }
              return i;
            }),
            (this.compressToEncodedURIComponent = (e) => {
              if (null === e) return "";
              const t = this;
              return this._compress(e, 6, function (e) {
                return t.keyStrUriSafe.charAt(e);
              });
            }),
            (this.f = String.fromCharCode),
            (this.keyStrUriSafe =
              "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+-$");
        }
      },
    },
    Ae = {
      name: "gioCustomTracking",
      method: class {
        constructor(e) {
          (this.growingIO = e),
            (this.getValidResourceItem = (e) => {
              if (e && y(e) && e.id && e.key) {
                const t = {
                  id: I(e.id) ? e.id : k(e.id),
                  key: I(e.key) ? e.key : k(e.key),
                };
                return e.attributes && (t.attributes = e.attributes), t;
              }
            }),
            (this.getDynamicAttributes = (e) => (
              v(e) ||
                K(e).forEach((t) => {
                  E(e[t])
                    ? (e[t] = e[t]())
                    : y(e[t])
                    ? M(e, t)
                    : _(e[t]) || (e[t] = k(e[t]));
                }),
              e
            )),
            (this.buildCustomEvent = (e, t, i, n) => {
              Q(e, () => {
                const {
                  dataStore: {
                    eventContextBuilder: r,
                    eventConverter: s,
                    currentPage: o,
                  },
                } = this.growingIO;
                let a = Object.assign(
                  {
                    eventType: "CUSTOM",
                    eventName: e,
                    pageShowTimestamp: null == o ? void 0 : o.time,
                    attributes: Z(
                      this.getDynamicAttributes(y(t) && !F(t) ? t : void 0)
                    ),
                    resourceItem: Z(this.getValidResourceItem(i)),
                  },
                  r()
                );
                F(n) || (a = Object.assign(Object.assign({}, a), n)), s(a);
              });
            }),
            (this.buildUserAttributesEvent = (e, t) => {
              const {
                dataStore: { eventContextBuilder: i, eventConverter: n },
              } = this.growingIO;
              let r = Object.assign(
                {
                  eventType: "LOGIN_USER_ATTRIBUTES",
                  attributes: Z(e),
                },
                i()
              );
              F(t) || (r = Object.assign(Object.assign({}, r), t)), n(r);
            });
        }
      },
    },
    Pe = {},
    De = {}.hasOwnProperty;
  function Le(e) {
    try {
      return decodeURIComponent(e.replace(/\+/g, " "));
    } catch (e) {
      return null;
    }
  }
  function Re(e) {
    try {
      return encodeURIComponent(e);
    } catch (e) {
      return null;
    }
  }
  (Pe.stringify = function (e, t) {
    t = t || "";
    var i,
      n,
      r = [];
    for (n in ("string" != typeof t && (t = "?"), e))
      if (De.call(e, n)) {
        if (
          ((i = e[n]) || (null != i && !isNaN(i)) || (i = ""),
          (n = Re(n)),
          (i = Re(i)),
          null === n || null === i)
        )
          continue;
        r.push(n + "=" + i);
      }
    return r.length ? t + r.join("&") : "";
  }),
    (Pe.parse = function (e) {
      for (var t, i = /([^=?#&]+)=?([^&]*)/g, n = {}; (t = i.exec(e)); ) {
        var r = Le(t[1]),
          s = Le(t[2]);
        null === r || null === s || r in n || (n[r] = s);
      }
      return n;
    });
  const ke = {
      gioprojectid: "projectId",
      giodatacollect: "dataCollect",
      gioappid: "domain",
      giodatasourceid: "dataSourceId",
      gios: "sessionId",
      giou: "uid",
      giocs1: "userId",
      gioid: "gioId",
      giouserkey: "userKey",
      gioappchannel: "appChannel",
      giodevicebrand: "deviceBrand",
      giodevicemodel: "deviceModel",
      giodevicetype: "deviceType",
      giolanguage: "language",
      gionetworkstate: "networkState",
      giooperatingsystem: "operatingSystem",
      gioplatform: "platform",
      gioplatformversion: "platformVersion",
      gioscreenheight: "screenHeight",
      gioscreenwidth: "screenWidth",
    },
    Ue = [
      "giodatasourceid",
      "gioplatform",
      "gioappchannel",
      "giodevicebrand",
      "giodevicemodel",
      "giodevicetype",
      "giolanguage",
      "gionetworkstate",
      "giooperatingsystem",
      "gioplatformversion",
      "gioscreenheight",
      "gioscreenwidth",
    ],
    je = ["giocs1", "gios", "giou", "gioid", "giouserkey"],
    Ge = "gio_search_cookie_gioenc";
  var qe = {
      name: "gioEmbeddedAdapter",
      method: class {
        constructor(e) {
          (this.growingIO = e),
            (this.main = () => {
              var e;
              const { projectId: t, appId: i } = this.growingIO.vdsConfig,
                n = this.getGQS();
              let r = !1;
              return (
                "none" !== this.qsFrom &&
                  n.gioprojectid === t &&
                  n.gioappid === i &&
                  (F(n)
                    ? this.growingIO.storage.removeItem(Ge)
                    : this.growingIO.storage.setItem(Ge, Pe.stringify(n)),
                  B(n, "giodatacollect") &&
                    (this.growingIO.vdsConfig.dataCollect = L(
                      ["true", !0],
                      n.giodatacollect
                    )),
                  null === (e = this.growingIO.emitter) ||
                    void 0 === e ||
                    e.on("SDK_INITIALIZED", () => {
                      const {
                        userStore: e,
                        vdsConfig: { sessionExpires: t },
                        dataStore: { eventContextBuilderInst: i },
                      } = this.growingIO;
                      je.forEach((t) => {
                        var i;
                        e[ke[t]] = null !== (i = n[t]) && void 0 !== i ? i : "";
                      }),
                        window.setInterval(() => {
                          e.sessionId = n.gios;
                        }, 0.8 * t * 60 * 1e3),
                        Ue.forEach((e) => {
                          B(n, e) && (i.minpExtraParams[ke[e]] = n[e]);
                        });
                    }),
                  (this.growingIO.setUserId = () => {}),
                  (this.growingIO.clearUserId = () => {}),
                  B(n, "giodatacollect") &&
                    ((this.growingIO.setDataCollect = () => {}),
                    (this.growingIO.setOption = () => {})),
                  (r = !0)),
                this.gioURLRewrite(),
                r
              );
            }),
            (this.getGQS = () => {
              const { hashtag: e } = this.growingIO.vdsConfig,
                t = this.growingIO.storage.getItem(Ge),
                i = window.location.search,
                n = window.location.hash,
                r = e ? n.substring(n.indexOf("?") + 1) : "",
                s = Pe.parse(i),
                o = Pe.parse(r),
                a = Pe.parse((t || "").replace("gioenc-", ""));
              let d = {};
              if (B(s, "gioprojectid")) (d = s), (this.qsFrom = "search");
              else if (B(o, "gioprojectid")) (d = o), (this.qsFrom = "hash");
              else {
                if (!B(a, "gioprojectid")) return (this.qsFrom = "none"), {};
                (d = a), (this.qsFrom = "cookie");
              }
              const c = {},
                l = {},
                h = [
                  "gioappid",
                  "gioprojectid",
                  "giodatacollect",
                  ...je,
                  ...Ue,
                ];
              return (
                K(d).forEach((e) => {
                  const t = e.toLowerCase();
                  L(h, t)
                    ? L(["", "undefined", "null", void 0, null], d[e]) ||
                      ((c[t] = d[e]),
                      L(["true", "TRUE", !0], d[e]) && (c[t] = !0),
                      L(["false", "FALSE", !1], d[e]) && (c[t] = !1))
                    : (l[e] = d[e]);
                }),
                (this.gqs = c),
                (this.ngqs = l),
                c
              );
            }),
            (this.gioURLRewrite = () => {
              const { hashtag: e } = this.growingIO.vdsConfig;
              let t = window.location.search,
                i = window.location.hash,
                n = !1;
              if (
                ("search" === this.qsFrom &&
                  ((t = Pe.stringify(this.ngqs, !0)), (n = !0)),
                e &&
                  "hash" === this.qsFrom &&
                  ((i = `${i.split("?")[0]}${Pe.stringify(this.ngqs, !0)}`),
                  (n = !0)),
                n)
              ) {
                const e = `${window.location.pathname}${t || ""}${i || ""}`;
                window.history.replaceState(null, document.title, e);
              }
            }),
            (this.gqs = {}),
            (this.ngqs = {}),
            (this.qsFrom = "search"),
            this.growingIO.emitter.on(Ee, () => {
              this.growingIO.useEmbeddedInherit = this.main();
            });
        }
      },
    },
    He = {},
    Be = {};
  !(function (e) {
    var t =
      (f && f.__spreadArray) ||
      function (e, t, i) {
        if (i || 2 === arguments.length)
          for (var n, r = 0, s = t.length; s > r; r++)
            (!n && r in t) ||
              (n || (n = [].slice.call(t, 0, r)), (n[r] = t[r]));
        return e.concat(n || [].slice.call(t));
      };
    Object.defineProperty(e, "__esModule", {
      value: !0,
    }),
      (e.GROWING_TITLE_OLD =
        e.GROWING_TITLE =
        e.GROWING_GTITLE =
        e.GROWING_CDP_INDEX =
        e.GROWING_INDEX_OLD =
        e.GROWING_INDEX =
        e.GROWING_CONTAINER =
        e.GROWING_TRACK =
        e.GROWING_IGNORE =
        e.VALID_CLASS_SELECTOR =
        e.VALID_ID_SELECTOR =
        e.EXCLUDE_CLASS_RE =
        e.UNSUPPORTED_TAGS =
        e.TEXT_NODE =
        e.UNSUPPORTED_CLICK_TAGS =
        e.SUPPORTED_ICON_TAGS =
        e.SUPPORTED_CHANGE_TYPES =
        e.SUPPORTED_CLICK_INPUT_TYPES =
        e.SUPPORTED_CONTAINER_TAGS =
        e.LIST_TAGS =
          void 0),
      (e.LIST_TAGS = ["TR", "LI", "DL"]),
      (e.SUPPORTED_CONTAINER_TAGS = t(["A", "BUTTON"], e.LIST_TAGS, !0)),
      (e.SUPPORTED_CLICK_INPUT_TYPES = ["button", "submit", "reset"]),
      (e.SUPPORTED_CHANGE_TYPES = ["radio", "checkbox", "search"]),
      (e.SUPPORTED_ICON_TAGS = ["I", "EM", "svg", "IMG"]),
      (e.UNSUPPORTED_CLICK_TAGS = ["TEXTAREA", "HTML", "BODY"]),
      (e.TEXT_NODE = ["I", "SPAN", "EM", "B", "STRONG"]),
      (e.UNSUPPORTED_TAGS = [
        "tspan",
        "text",
        "g",
        "rect",
        "path",
        "defs",
        "clippath",
        "desc",
        "title",
        "math",
        "use",
      ]),
      (e.EXCLUDE_CLASS_RE =
        /(^| |[^ ]+\-)(clear|clearfix|active|hover|enabled|current|selected|unselected|hidden|display|focus|disabled|undisabled|open|checked|unchecked|undefined|null|ng-|growing-)[^\. ]*/g),
      (e.VALID_ID_SELECTOR = /^[a-zA-Z-\_][a-zA-Z\-\_0-9]+$/),
      (e.VALID_CLASS_SELECTOR = /^([a-zA-Z\-\_0-9]+)$/),
      (e.GROWING_IGNORE = "data-growing-ignore"),
      (e.GROWING_TRACK = "data-growing-track"),
      (e.GROWING_CONTAINER = "data-growing-container"),
      (e.GROWING_INDEX = "data-growing-index"),
      (e.GROWING_INDEX_OLD = "data-growing-idx"),
      (e.GROWING_CDP_INDEX = "data-index"),
      (e.GROWING_GTITLE = "data-growing-title"),
      (e.GROWING_TITLE = "data-title"),
      (e.GROWING_TITLE_OLD = "growing-title");
  })(Be);
  var Ke = {},
    We = {};
  Object.defineProperty(We, "__esModule", {
    value: !0,
  }),
    (We.lastFindIndex =
      We.findIndex =
      We.arrayEquals =
      We.rmBlank =
      We.normalizePath =
      We.splitNoEmpty =
      We.filterText =
        void 0),
    (We.filterText = function (e, t) {
      if (
        (void 0 === t && (t = !0),
        e &&
          (null == (e = e.replace(/[\n \t]+/g, " ").trim())
            ? void 0
            : e.length))
      )
        return e.slice(0, t ? 50 : void 0);
    }),
    (We.splitNoEmpty = function (e, t) {
      return e
        ? e.split(t).filter(function (e) {
            return !!e;
          })
        : [];
    }),
    (We.normalizePath = function (e) {
      var t = e.length;
      return t > 1 && "/" === e.charAt(t - 1) ? e.slice(0, t - 1) : e;
    }),
    (We.rmBlank = function (e) {
      return e ? e.replace(/[\n \t]+/g, "") : "";
    }),
    (We.arrayEquals = function (e, t) {
      if (!e || !t) return !1;
      if (e.length !== t.length) return !1;
      for (var i = 0, n = e.length; n > i; i++) if (e[i] !== t[i]) return !1;
      return !0;
    }),
    (We.findIndex = function (e, t) {
      if (null == e || "function" != typeof t) return -1;
      for (var i = 0; i < e.length; i++) {
        var n = e[i];
        if (t.call(void 0, n)) return i;
      }
      return -1;
    }),
    (We.lastFindIndex = function (e, t) {
      if (null == e || "function" != typeof t) return -1;
      for (var i = e.length - 1; i >= 0; i--) {
        var n = e[i];
        if (t.call(void 0, n)) return i;
      }
      return -1;
    }),
    (function (e) {
      var t =
          (f && f.__spreadArray) ||
          function (e, t, i) {
            if (i || 2 === arguments.length)
              for (var n, r = 0, s = t.length; s > r; r++)
                (!n && r in t) ||
                  (n || (n = [].slice.call(t, 0, r)), (n[r] = t[r]));
            return e.concat(n || [].slice.call(t));
          },
        i =
          (f && f.__importDefault) ||
          function (e) {
            return e && e.__esModule
              ? e
              : {
                  default: e,
                };
          };
      Object.defineProperty(e, "__esModule", {
        value: !0,
      }),
        (e.removeDiffTagOnHeadAndTail =
          e.computeXpath =
          e.getMarkIndex =
          e.getEffectiveNode =
          e.isIgnore =
          e.depthInside =
          e.changeableInput =
          e.clickableInput =
          e.onlyContainsTextChildren =
          e.onlyContainsIconChildren =
          e.supportIconTag =
          e.isContainerTag =
          e.isListTag =
          e.isParentOfLeaf =
          e.isLeaf =
          e.getChildren =
          e.getDeepChildren =
          e.findParent =
          e.isRootNode =
          e.hasValidAttribute =
            void 0);
      var n = We,
        r = Be,
        s = i(m);
      (e.hasValidAttribute = function (e, t) {
        return (
          e instanceof Element &&
          e.hasAttribute(t) &&
          "false" !== e.getAttribute(t)
        );
      }),
        (e.isRootNode = function (e) {
          return !e || -1 !== ["BODY", "HTML", "#document"].indexOf(e.nodeName);
        }),
        (e.findParent = function (t, i) {
          for (var n = t.parentNode; n && !(0, e.isRootNode)(n); ) {
            if (i(n)) return n;
            n = n.parentNode;
          }
        }),
        (e.getDeepChildren = function (i) {
          return (0, s.default)(
            (null == i ? void 0 : i.childNodes) || []
          ).reduce(function (i, n) {
            return n instanceof Element
              ? t(t(t([], i, !0), [n], !1), (0, e.getDeepChildren)(n), !0)
              : i;
          }, []);
        }),
        (e.getChildren = function (e) {
          return (0, s.default)(
            (null == e ? void 0 : e.childNodes) || []
          ).filter(function (e) {
            return e instanceof Element;
          });
        }),
        (e.isLeaf = function (t) {
          return (
            !t.hasChildNodes() ||
            "svg" === t.nodeName ||
            0 === (0, e.getChildren)(t).length
          );
        }),
        (e.isParentOfLeaf = function (t) {
          return (
            !(!t.hasChildNodes() || "svg" === t.nodeName) &&
            0 ===
              (0, s.default)(t.childNodes).filter(function (t) {
                return !(0, e.isLeaf)(t);
              }).length
          );
        }),
        (e.isListTag = function (e) {
          return -1 !== r.LIST_TAGS.indexOf(e.nodeName);
        }),
        (e.isContainerTag = function (t) {
          return (
            (0, e.hasValidAttribute)(t, r.GROWING_CONTAINER) ||
            -1 !== r.SUPPORTED_CONTAINER_TAGS.indexOf(t.nodeName)
          );
        }),
        (e.supportIconTag = function (e) {
          var t = e.nodeName;
          return -1 !== r.SUPPORTED_ICON_TAGS.indexOf(t);
        }),
        (e.onlyContainsIconChildren = function (t) {
          if (t.textContent) return !1;
          var i = (0, e.getChildren)(t);
          if (0 === i.length) return !1;
          for (var n = 0, r = i; n < r.length; n++) {
            var s = r[n];
            if (!(0, e.supportIconTag)(s) && "SPAN" !== s.nodeName) return !1;
          }
          return !0;
        }),
        (e.onlyContainsTextChildren = function (t) {
          return (
            0 !== (0, e.getChildren)(t).length &&
            !(0, e.getDeepChildren)(t)
              .map(function (e) {
                return e.tagName;
              })
              .some(function (e) {
                return -1 === r.TEXT_NODE.indexOf(e);
              })
          );
        }),
        (e.clickableInput = function (e) {
          return (
            e instanceof HTMLInputElement &&
            "INPUT" === e.tagName &&
            -1 !== r.SUPPORTED_CLICK_INPUT_TYPES.indexOf(e.type)
          );
        }),
        (e.changeableInput = function (e) {
          return (
            e instanceof HTMLInputElement &&
            "INPUT" === e.tagName &&
            -1 !== r.SUPPORTED_CHANGE_TYPES.indexOf(e.type)
          );
        }),
        (e.depthInside = function (t, i, n) {
          if ((void 0 === i && (i = 4), void 0 === n && (n = 1), n > i))
            return !1;
          for (
            var r = "svg" === t.tagName ? [] : (0, e.getChildren)(t), s = 0;
            s < r.length;
            s++
          ) {
            var o = r[s];
            if (!(0, e.depthInside)(o, i, n + 1)) return !1;
          }
          return i >= n;
        }),
        (e.isIgnore = function (t) {
          if (
            !(t instanceof Element) ||
            (0, e.hasValidAttribute)(t, r.GROWING_IGNORE)
          )
            return !0;
          for (var i = t.parentNode; i && !(0, e.isRootNode)(i); ) {
            if ((0, e.hasValidAttribute)(i, r.GROWING_IGNORE)) return !0;
            i = i.parentNode;
          }
          return !1;
        }),
        (e.getEffectiveNode = function (t) {
          for (
            var i, n;
            t &&
            ((n = void 0),
            !(
              (i = t) instanceof Element &&
              -1 ===
                r.UNSUPPORTED_TAGS.indexOf(
                  null === (n = i.tagName) || void 0 === n
                    ? void 0
                    : n.toLowerCase()
                )
            )) &&
            t.parentNode;

          )
            t = t.parentNode;
          var s,
            o = t.parentNode;
          return !(0, e.isRootNode)(o) &&
            ((0, e.onlyContainsIconChildren)(o) ||
              ("BUTTON" === (s = o).tagName &&
                (0, e.onlyContainsTextChildren)(s)))
            ? o
            : t;
        }),
        (e.getMarkIndex = function (e) {
          if (e instanceof Element) {
            var t =
              e.getAttribute(r.GROWING_INDEX) ||
              e.getAttribute(r.GROWING_INDEX_OLD) ||
              e.getAttribute(r.GROWING_CDP_INDEX);
            if (t) {
              if (/^\d{1,10}$/.test(t) && +t >= 0 && 2147483647 > +t) return +t;
              window.console.error(
                "[GioNode]：标记的index不符合规范（index必须是大于等于0且小于2147483647的整数字）。",
                t
              );
            }
          }
        }),
        (e.computeXpath = function (e) {
          for (
            var t = e.parentPaths(!0),
              i = Math.min(t.length, +(t.length >= 10) + 4),
              n = ["", "", ""],
              r = 0;
            r < t.length;
            r++
          ) {
            var s = t[r].path,
              o = t[r].name;
            (n[0] = s + n[0]),
              (n[2] = "/".concat(o) + n[2]),
              i > r && (n[1] = s + n[1]);
          }
          return n;
        }),
        (e.removeDiffTagOnHeadAndTail = function (e, t) {
          var i = function (e) {
              return e.nodeName === t.nodeName;
            },
            r = (0, n.findIndex)(e, i),
            s = (0, n.lastFindIndex)(e, i);
          return -1 === r || -1 === s ? [] : e.slice(r, s + 1);
        });
    })(Ke);
  var Ve = {},
    Me = {};
  Object.defineProperty(Me, "__esModule", {
    value: !0,
  });
  var Fe = Be,
    $e = We,
    ze = Ke;
  function Xe(e) {
    var t;
    if (e instanceof Element) {
      var i = e.getAttribute("name");
      if (i) return [i];
      if (e.hasAttribute("class")) {
        var n =
          null === (t = e.getAttribute("class")) || void 0 === t
            ? void 0
            : t.replace(Fe.EXCLUDE_CLASS_RE, "").trim();
        if (null == n ? void 0 : n.length)
          return n
            .split(/\s+/)
            .filter(function (e) {
              return (
                Fe.VALID_CLASS_SELECTOR.test(e) &&
                !e.match(/[a-z][A-Z][a-z][A-Z]/) &&
                !e.match(/[0-9][0-9][0-9][0-9]/)
              );
            })
            .sort();
      }
    }
    return [];
  }
  var Je = (function () {
    function e(e) {
      var t;
      (this.node = e),
        (this.tagName = this.node.nodeName),
        (this.name = this.tagName.toLowerCase()),
        (this.id =
          (t = this.node).id && Fe.VALID_ID_SELECTOR.test(t.id) ? t.id : null),
        (this.classList = Xe(this.node)),
        this.guessListAndIndex();
    }
    return (
      (e.prototype.guessListAndIndex = function () {
        var e,
          t = this;
        this._tagList = (0, ze.isListTag)(this.node);
        var i = (0, ze.removeDiffTagOnHeadAndTail)(
          (0, ze.getChildren)(this.node.parentNode),
          this.node
        );
        if (
          (this._tagList &&
            -1 !==
              (s = i
                .filter(function (e) {
                  return e.tagName === t.tagName;
                })
                .indexOf(this.node)) &&
            (this._index = s + 1),
          i.length >= 3 &&
            (null === (e = this.classList) || void 0 === e ? void 0 : e.length))
        ) {
          for (var n = 0, r = 0, s = 1; s <= i.length; s++) {
            var o = i[s - 1];
            if (o.tagName !== this.tagName) {
              r = 0;
              break;
            }
            (0, $e.arrayEquals)(this.classList, Xe(o)) && (r += 1),
              this.node === o && (n = s);
          }
          3 > r || ((this._pseudoList = !0), (this._index = this._index || n));
        }
      }),
      Object.defineProperty(e.prototype, "path", {
        get: function () {
          var e;
          return (
            this._path ||
              ((this._path = "/".concat(this.name)),
              this.id && (this._path += "#".concat(this.id)),
              (null === (e = this.classList) || void 0 === e
                ? void 0
                : e.length) &&
                (this._path += ".".concat(this.classList.join(".")))),
            this._path
          );
        },
        enumerable: !1,
        configurable: !0,
      }),
      Object.defineProperty(e.prototype, "pseudoList", {
        get: function () {
          return !!this._pseudoList;
        },
        enumerable: !1,
        configurable: !0,
      }),
      Object.defineProperty(e.prototype, "list", {
        get: function () {
          return !!this._tagList || !!this._pseudoList;
        },
        enumerable: !1,
        configurable: !0,
      }),
      Object.defineProperty(e.prototype, "index", {
        get: function () {
          var e;
          return null !== (e = (0, ze.getMarkIndex)(this.node)) && void 0 !== e
            ? e
            : this._index;
        },
        enumerable: !1,
        configurable: !0,
      }),
      Object.defineProperty(e.prototype, "container", {
        get: function () {
          return (0, ze.isContainerTag)(this.node) || this.list;
        },
        enumerable: !1,
        configurable: !0,
      }),
      Object.defineProperty(e.prototype, "parent", {
        get: function () {
          return this.node.parentNode ? new e(this.node.parentNode) : null;
        },
        enumerable: !1,
        configurable: !0,
      }),
      (e.prototype.parentPaths = function (e) {
        void 0 === e && (e = !1);
        for (
          var t = e ? [this] : [], i = this.parent;
          i && !(0, ze.isRootNode)(i.node);

        )
          t.push(i), (i = i.parent);
        return t;
      }),
      e
    );
  })();
  Me.default = Je;
  var Ze = {};
  Object.defineProperty(Ze, "__esModule", {
    value: !0,
  }),
    (Ze.getElementHref = Ze.getImgHref = Ze.getAnchorHref = void 0);
  var Ye = We;
  function Qe(e) {
    if (e.hasAttribute("href")) {
      var t = e.getAttribute("href");
      if (t && 0 !== t.indexOf("javascript"))
        return (0, Ye.normalizePath)(t.slice(0, 320));
    }
  }
  function et(e) {
    if (e.src && -1 === e.src.indexOf("data:image")) return e.src;
  }
  (Ze.getAnchorHref = Qe),
    (Ze.getImgHref = et),
    (Ze.getElementHref = function (e) {
      var t = e;
      if (t)
        switch (e.nodeName.toLowerCase()) {
          case "a":
            return Qe(t);
          case "img":
            return et(t);
        }
    });
  var tt = {},
    it =
      (f && f.__importDefault) ||
      function (e) {
        return e && e.__esModule
          ? e
          : {
              default: e,
            };
      };
  Object.defineProperty(tt, "__esModule", {
    value: !0,
  }),
    (tt.getElementContent = tt.getFormContent = void 0);
  var nt = Ke,
    rt = Ze,
    st = Be,
    ot = it(Me),
    at = We,
    dt = it(m),
    ct = function (e) {
      return e.htmlFor || e.getAttribute("for");
    },
    lt = function (e) {
      var t =
        e.getAttribute(st.GROWING_GTITLE) ||
        e.getAttribute(st.GROWING_TITLE) ||
        e.getAttribute(st.GROWING_TITLE_OLD) ||
        e.getAttribute("title");
      return null == t ? void 0 : t.trim();
    };
  function ht(e) {
    var t = e.node;
    return e.list ? ut(t) : (0, at.filterText)(t.textContent) || void 0;
  }
  function ut(e) {
    for (
      var t = void 0, i = !1, n = 0, r = (0, dt.default)(e.childNodes);
      n < r.length;
      n++
    ) {
      var s = r[n];
      if (s.nodeType === Node.TEXT_NODE) {
        var o = (0, at.filterText)(s.textContent);
        if (o) return o;
      }
      if (
        s.nodeType === Node.ELEMENT_NODE &&
        -1 === ["INPUT", "SELECT"].indexOf(s.nodeName)
      ) {
        if (new ot.default(s).pseudoList) return;
        i = (0, nt.onlyContainsIconChildren)(s) || (0, nt.supportIconTag)(s);
        var a = pt(s);
        if (i) (t = a), (i = !1);
        else if ((a || (a = ut(s)), a)) return a;
      }
    }
    return t;
  }
  function gt(e) {
    for (
      var t = e.getElementsByTagName("input"), i = 0, n = (0, dt.default)(t);
      i < n.length;
      i++
    ) {
      var r = n[i];
      if (
        ("search" === r.type ||
          ("text" === r.type &&
            ("q" === r.id ||
              -1 !== r.id.indexOf("search") ||
              "q" === r.name ||
              -1 !== r.name.indexOf("search")))) &&
        !(0, nt.isIgnore)(r)
      ) {
        var s = pt(r);
        if (s) return s;
      }
    }
  }
  function pt(e) {
    return (
      (function (e) {
        var t = e;
        if (t) {
          var i = lt(t);
          if (i) return i;
          var n,
            r,
            s,
            o = new ot.default(e);
          switch (e.nodeName.toLowerCase()) {
            case "a":
              return (function (e) {
                if (
                  ((0, nt.isLeaf)(e) || (0, nt.onlyContainsIconChildren)(e)) &&
                  e.textContent
                ) {
                  var t = (0, at.filterText)(e.textContent);
                  if (t) return t;
                }
                var i = (0, rt.getAnchorHref)(e);
                if (i) {
                  var n = i.indexOf("?");
                  return n > -1 ? i.slice(0, n) : i;
                }
              })(t);
            case "svg":
              return (function (e) {
                for (
                  var t = 0, i = (0, dt.default)(e.childNodes);
                  t < i.length;
                  t++
                ) {
                  var n = i[t];
                  if (
                    n.nodeType === Node.ELEMENT_NODE &&
                    "use" === n.tagName.toLowerCase() &&
                    n.hasAttribute("xlink:href")
                  )
                    return n.getAttribute("xlink:href");
                }
              })(t);
            case "button":
              return (
                null === (s = (r = t).name) || void 0 === s ? void 0 : s.length
              )
                ? r.name
                : (0, at.filterText)(r.textContent) || ut(r);
            case "img":
              return (function (e) {
                if (e.alt) return e.alt;
                var t = (0, rt.getImgHref)(e);
                if (t) {
                  var i = t.split("?")[0].split("/");
                  if (i.length > 0) return i[i.length - 1];
                }
              })(t);
            case "label":
              return ht(o);
            case "input":
              return (function (e) {
                if ((0, nt.clickableInput)(e)) return e.value;
                if (
                  "password" !== e.type &&
                  (0, nt.hasValidAttribute)(e, st.GROWING_TRACK)
                )
                  return e.value;
                if ((0, nt.changeableInput)(e)) {
                  var t = (0, nt.findParent)(e, function (e) {
                    return "LABEL" === e.nodeName;
                  });
                  if (!t && e.id)
                    for (
                      var i = document.body.getElementsByTagName("label"),
                        n = 0;
                      n < i.length;
                      n++
                    ) {
                      var r = i[n];
                      if (ct(r) === e.id) {
                        t = r;
                        break;
                      }
                    }
                  if (t) {
                    var s = ht(new ot.default(t));
                    if (s && s.length > 0) return s + " (" + e.checked + ")";
                  }
                  return e.value;
                }
              })(t);
            case "select":
              return (
                (n = t),
                (0, dt.default)(n.options)
                  .filter(function (e) {
                    return e.selected;
                  })
                  .map(function (e) {
                    return e.label;
                  })
                  .join(", ") || n.value
              );
            case "form":
              return gt(t);
          }
          return (0, nt.isLeaf)(t)
            ? (function (e) {
                var t = (0, at.filterText)(e.textContent);
                if (t) return t;
              })(t)
            : (0, nt.isParentOfLeaf)(t) && !(0, nt.onlyContainsIconChildren)(t)
            ? (function (e) {
                for (
                  var t = "", i = 0, n = (0, dt.default)(e.childNodes);
                  i < n.length;
                  i++
                ) {
                  var r = n[i];
                  t +=
                    (r.nodeType === Node.TEXT_NODE && r.textContent
                      ? r.textContent.trim()
                      : "") + " ";
                }
                return (0, at.filterText)(t, !1);
              })(t)
            : o.container || (0, nt.onlyContainsIconChildren)(e)
            ? ut(t)
            : void 0;
        }
      })(e) || void 0
    );
  }
  (tt.getFormContent = gt), (tt.getElementContent = pt);
  var ft,
    mt =
      (f && f.__extends) ||
      ((ft = function (e, t) {
        return (
          (ft =
            Object.setPrototypeOf ||
            ({
              __proto__: [],
            } instanceof Array &&
              function (e, t) {
                e.__proto__ = t;
              }) ||
            function (e, t) {
              for (var i in t) ({}.hasOwnProperty.call(t, i) && (e[i] = t[i]));
            }),
          ft(e, t)
        );
      }),
      function (e, t) {
        if ("function" != typeof t && null !== t)
          throw new TypeError(
            "Class extends value " + t + " is not a constructor or null"
          );
        function i() {
          this.constructor = e;
        }
        ft(e, t),
          (e.prototype =
            null === t
              ? Object.create(t)
              : ((i.prototype = t.prototype), new i()));
      }),
    vt =
      (f && f.__importDefault) ||
      function (e) {
        return e && e.__esModule
          ? e
          : {
              default: e,
            };
      };
  Object.defineProperty(Ve, "__esModule", {
    value: !0,
  });
  var It = vt(Me),
    wt = Ze,
    Ot = tt,
    bt = Ke,
    yt = (function (e) {
      function t(t) {
        var i = e.call(this, t) || this;
        i.node = t;
        var n = (0, bt.computeXpath)(i),
          r = n[0],
          s = n[1],
          o = n[2];
        return (i.fullXpath = r), (i.xpath = s), (i.skeleton = o), i;
      }
      return (
        mt(t, e),
        Object.defineProperty(t.prototype, "href", {
          get: function () {
            return (0, wt.getElementHref)(this.node);
          },
          enumerable: !1,
          configurable: !0,
        }),
        Object.defineProperty(t.prototype, "content", {
          get: function () {
            return (0, Ot.getElementContent)(this.node);
          },
          enumerable: !1,
          configurable: !0,
        }),
        t
      );
    })(It.default);
  Ve.default = yt;
  var Tt =
      (f && f.__assign) ||
      function () {
        return (
          (Tt =
            Object.assign ||
            function (e) {
              for (var t, i = 1, n = arguments.length; n > i; i++)
                for (var r in (t = arguments[i]))
                  ({}.hasOwnProperty.call(t, r) && (e[r] = t[r]));
              return e;
            }),
          Tt.apply(this, arguments)
        );
      },
    Et =
      (f && f.__importDefault) ||
      function (e) {
        return e && e.__esModule
          ? e
          : {
              default: e,
            };
      };
  Object.defineProperty(He, "__esModule", {
    value: !0,
  });
  var _t = Be,
    St = Ke,
    Nt = Et(Ve),
    Ct = (function () {
      function e(e, t, i) {
        void 0 === t && (t = null),
          void 0 === i && (i = !0),
          (this.origin = e),
          (this.action = t),
          (this.direct = i),
          (this.target = "self" === t ? e : (0, St.getEffectiveNode)(e)),
          (this.ignore = (0, St.isIgnore)(this.target)),
          (this.vnode = new Nt.default(this.target)),
          (this.tagName = this.vnode.tagName);
      }
      return (
        Object.defineProperty(e.prototype, "content", {
          get: function () {
            return this.vnode.content;
          },
          enumerable: !1,
          configurable: !0,
        }),
        Object.defineProperty(e.prototype, "href", {
          get: function () {
            return this.vnode.href;
          },
          enumerable: !1,
          configurable: !0,
        }),
        Object.defineProperty(e.prototype, "index", {
          get: function () {
            return this.vnode.index;
          },
          enumerable: !1,
          configurable: !0,
        }),
        (e.prototype.inferParentIndex = function () {
          var t = this;
          return (
            this.parentIndex ||
              (0, St.findParent)(this.target, function (i) {
                var n = new e(i, t.action, !1);
                n.traceable() && n.index && (t.parentIndex = n.index);
              }),
            this.parentIndex
          );
        }),
        Object.defineProperty(e.prototype, "xpath", {
          get: function () {
            return this.vnode.xpath;
          },
          enumerable: !1,
          configurable: !0,
        }),
        Object.defineProperty(e.prototype, "fullXpath", {
          get: function () {
            return this.vnode.fullXpath;
          },
          enumerable: !1,
          configurable: !0,
        }),
        Object.defineProperty(e.prototype, "skeleton", {
          get: function () {
            return this.vnode.skeleton;
          },
          enumerable: !1,
          configurable: !0,
        }),
        (e.prototype.info = function (e) {
          return (
            void 0 === e && (e = !0),
            e && this.inferParentIndex(),
            {
              skeleton: this.skeleton,
              fullXpath: this.fullXpath,
              xpath: this.xpath,
              content: this.content,
              href: this.href,
              index: this.parentIndex || this.index,
            }
          );
        }),
        (e.prototype.traceable = function () {
          if (this.ignore) return !1;
          if (this.direct) {
            if ("click" === this.action || "hover" === this.action) {
              if (-1 !== _t.UNSUPPORTED_CLICK_TAGS.indexOf(this.target.tagName))
                return !1;
              if (
                "INPUT" === this.target.tagName &&
                !(0, St.clickableInput)(this.target)
              )
                return !1;
              if (
                !(0, St.isContainerTag)(this.target) &&
                !(0, St.depthInside)(this.target, 5)
              )
                return !1;
            }
            return !0;
          }
          return this.vnode.container;
        }),
        (e.prototype.trackNodes = function () {
          if (!this.traceable()) return [];
          var e = [this];
          if ("submit" !== this.action)
            for (var t = this.parentElement; t; ) {
              if (t.ignore) return [];
              t.traceable() && e.unshift(t), (t = t.parentElement);
            }
          var i = void 0;
          return e.map(function (e) {
            var t = e.info(!1),
              n = t.index;
            return (
              !i && n && (i = n),
              Tt(Tt({}, t), {
                index: i || n,
              })
            );
          });
        }),
        Object.defineProperty(e.prototype, "parentElement", {
          get: function () {
            var t = this.target.parentNode;
            if (t && t.nodeName && !(0, St.isRootNode)(t))
              return new e(t, this.action, !1);
          },
          enumerable: !1,
          configurable: !0,
        }),
        e
      );
    })(),
    xt = (He.default = Ct);
  class At {
    constructor(e) {
      this.handler = e;
      const t = navigator.userAgent,
        i = /chrome/i.exec(t),
        n = /android/i.exec(t);
      this.hasTouch = "ontouchstart" in window && !(i && !n);
    }
    main() {
      const e = this.hasTouch ? ["touchstart"] : ["mousedown"],
        t = this.hasTouch
          ? ["touchend", "touchcancel"]
          : ["mouseup", "mouseleave"],
        i = this.hasTouch ? ["touchmove"] : ["mousemove"];
      for (const t of e) Y(window, t, this.touchStartHandler.bind(this));
      for (const e of i) Y(window, e, this.touchMoveHandler.bind(this));
      for (const e of t) Y(window, e, this.touchStopHandler.bind(this));
    }
    touchStartHandler(e) {
      if (e.which > 1) return;
      const t = +Date.now();
      this.safeguard !== t &&
        (this.touchTimeout && clearTimeout(this.touchTimeout),
        (this.safeguard = t),
        (this.touchEvent = {
          time: t,
          target: e.target,
          x: this._page("x", e),
          y: this._page("y", e),
          isTrusted: !0,
          type: "click",
        }));
    }
    touchMoveHandler(e) {
      const t = Math.abs(
          this._page("x", e) - (this.touchEvent && this.touchEvent.x) || 0
        ),
        i = Math.abs(
          this._page("y", e) - (this.touchEvent && this.touchEvent.y) || 0
        );
      (t > 10 || i > 10) && (this.touchEvent = null);
    }
    touchStopHandler(e) {
      const t = +Date.now() - (this.touchEvent && this.touchEvent.time) || 0;
      this.touchEvent && 200 > t
        ? (this.touchTimeout = setTimeout(() => {
            this.handler(this.touchEvent), (this.touchEvent = null);
          }, 200))
        : this.touchEvent &&
          t >= 200 &&
          700 > t &&
          (this.handler(this.touchEvent), (this.touchEvent = null));
    }
    _page(e, t) {
      return (this.hasTouch ? t.touches[0] : t)["page" + e.toUpperCase()];
    }
  }
  var Pt = {
    name: "gioEventAutoTracking",
    method: class {
      constructor(e) {
        (this.growingIO = e),
          (this.main = () => {
            Y(document, "submit", this._handleAction),
              Y(document, "change", this._handleAction);
            const { vdsConfig: e } = this.growingIO;
            e.touch
              ? new At(this._handleAction).main()
              : Y(document, "click", this._handleAction);
          }),
          (this._handleAction = (e, t) => {
            const { vdsConfig: i, emitter: n } = this.growingIO;
            if (!i.autotrack) return !1;
            const r = e.target;
            if (!r) return !1;
            let s = new xt(r, e.type, !0).trackNodes();
            if (("click" !== e.type && (s = F(C(s)) ? [] : [C(s)]), F(s)))
              return !1;
            null == n ||
              n.emit("onComposeBefore", {
                event: t,
                params: null != e ? e : {},
              }),
              s.forEach((t) => {
                const { fullXpath: n, index: r, content: s, href: o } = t;
                if (
                  !G(t.fullXpath || "", "/div#__vconsole") &&
                  !G(t.fullXpath || "", "/div#__giokit") &&
                  (i.debug && console.log("Action：", e.type, Date.now()), n)
                ) {
                  const {
                    dataStore: {
                      eventContextBuilder: t,
                      eventConverter: i,
                      currentPage: a,
                    },
                  } = this.growingIO;
                  i(
                    Object.assign(
                      Object.assign(
                        {
                          eventType: c[e.type],
                          element: [
                            {
                              xpath: n,
                              index: r,
                              textValue: s,
                              hyperlink: o,
                            },
                          ],
                        },
                        t()
                      ),
                      {
                        pageShowTimestamp: a.time,
                      }
                    )
                  );
                }
              });
          });
      }
    },
  };
  let Dt;
  const Lt = [
      "VIEW_CLICK",
      "VIEW_CHANGE",
      "FORM_SUBMIT",
      "PAGE",
      "CUSTOM",
      "LOGIN_USER_ATTRIBUTES",
    ],
    Rt = ["LOGIN_USER_ATTRIBUTES"];
  var kt = {
    name: "gioHybridAdapter",
    method: class {
      constructor(e) {
        (this.growingIO = e),
          (this.penetrateHybrid = !0),
          (this.onOptionsInit = () => {
            const { vdsConfig: e, emitter: t } = this.growingIO;
            b(e.penetrateHybrid) && (this.penetrateHybrid = e.penetrateHybrid),
              this._initHybridBridge() &&
                ((this.onSendBefore = this.sendBeforeListener),
                this.hybridConfig.projectId ===
                  this.growingIO.vdsConfig.projectId &&
                  (this.growingIO.useHybridInherit = !0)),
              this.growingIO.useHybridInherit &&
                (null == t ||
                  t.on(Ne, ({ newUserId: e, oldUserId: t, userKey: i }) => {
                    this.penetrateHybrid &&
                      (!e && t
                        ? i
                          ? this._clearNativeUserIdAndUserKey()
                          : this._clearNativeUserId()
                        : i
                        ? this._setNativeUserIdAndUserKey(k(e), k(i))
                        : this._setNativeUserId(k(e)));
                  }),
                null == t ||
                  t.on(Ce, ({ newUserKey: e, oldUserKey: t, userId: i }) => {
                    this.penetrateHybrid &&
                      (!e && t
                        ? this._clearNativeUserIdAndUserKey()
                        : this._setNativeUserIdAndUserKey(k(i), k(e)));
                  }));
          }),
          (this._initHybridBridge = () => {
            var e, t, i;
            let n = !1;
            return (
              (this.hasHybridBridge = !!window.GrowingWebViewJavascriptBridge),
              this.hasHybridBridge
                ? ((null ===
                    (e =
                      null === window || void 0 === window
                        ? void 0
                        : window.GrowingWebViewJavascriptBridge) || void 0 === e
                    ? void 0
                    : e.configuration) ||
                    (window.GrowingWebViewJavascriptBridge.configuration =
                      JSON.parse(
                        window.GrowingWebViewJavascriptBridge.getConfiguration()
                      )),
                  (null ===
                    (t =
                      null === window || void 0 === window
                        ? void 0
                        : window.GrowingWebViewJavascriptBridge) || void 0 === t
                    ? void 0
                    : t.configuration) &&
                    (this.hybridConfig =
                      null ===
                        (i =
                          null === window || void 0 === window
                            ? void 0
                            : window.GrowingWebViewJavascriptBridge) ||
                      void 0 === i
                        ? void 0
                        : i.configuration),
                  (n = !0))
                : Dt.consoleText(
                    "gioHybridAdapter：当前不存在 GrowingWebViewJavascriptBridge，Web模式。",
                    "info"
                  ),
              n
            );
          }),
          (this.sendBeforeListener = ({ requestData: e }) => {
            if (this.hasHybridBridge) {
              const t = this.processAttributes(Object.assign({}, e));
              L(Lt, t.eventType) &&
                (L(Rt, t.eventType)
                  ? this.penetrateHybrid && this._dispatchEvent(t)
                  : (this.penetrateHybrid || M(t, ["userId", "userKey", "cs1"]),
                    this._dispatchEvent(t)));
            }
          }),
          (this.processAttributes = (e) => (
            W(e, (t, i) => {
              y(t) || _(t)
                ? W(e[i], (t, n) => {
                    y(t) || _(t)
                      ? (e[i][n] = JSON.stringify(t))
                      : (e[i][n] = k(t));
                  })
                : (e[i] = k(t));
            }),
            e
          )),
          (this._setNativeUserId = (e) => {
            J(() => window.GrowingWebViewJavascriptBridge.setNativeUserId(e));
          }),
          (this._clearNativeUserId = () => {
            J(() => window.GrowingWebViewJavascriptBridge.clearNativeUserId());
          }),
          (this._setNativeUserIdAndUserKey = (e, t) => {
            J(() =>
              window.GrowingWebViewJavascriptBridge.setNativeUserIdAndUserKey(
                e,
                t
              )
            );
          }),
          (this._clearNativeUserIdAndUserKey = () => {
            J(() =>
              window.GrowingWebViewJavascriptBridge.clearNativeUserIdAndUserKey()
            );
          }),
          (this._dispatchEvent = (e) => {
            J(() => {
              var t;
              return null === (t = window.GrowingWebViewJavascriptBridge) ||
                void 0 === t
                ? void 0
                : t.dispatchEvent(JSON.stringify(e));
            });
          });
        const { emitter: t, utils: i } = this.growingIO;
        (Dt = i), t.on(Ee, this.onOptionsInit);
      }
    },
  };
  const Ut = ["i", "span", "em", "b", "strong", "svg"];
  var jt;
  !(function (e) {
    (e[(e.OUTER = 0)] = "OUTER"),
      (e[(e.INNER_COVERED = 1)] = "INNER_COVERED"),
      (e[(e.INNER_SHOW = 2)] = "INNER_SHOW");
  })(jt || (jt = {}));
  const Gt = [
      "HR",
      "BR",
      "SCRIPT",
      "NOSCRIPT",
      "STYLE",
      "HEAD",
      "BASE",
      "LINK",
      "META",
      "TITLE",
      "BODY",
      "HTML",
      "TEMPLATE",
      "CODE",
      ...Be.UNSUPPORTED_CLICK_TAGS,
    ],
    qt = ["SELECT", "A", "BUTTON", "INPUT", "IMG", "FORM"],
    Ht = (e, t, i) => document.elementFromPoint(t, i) === e;
  class Bt {
    constructor(e, t, i) {
      (this.node = e),
        (this.parentNodeDesc = t),
        (this.devicesInfo = i),
        (this.proxy = new xt(e)),
        (this.tagName = this.node.tagName),
        (this.name = this.tagName.toLowerCase()),
        (this.isIgnore = !!this.node.dataset.growingIgnore),
        (this.isUnSupported = -1 !== Gt.indexOf(this.tagName)),
        (this.rect = this.computeWindowRect());
    }
    info() {
      const e = this.desc();
      e.zLevel += this.devicesInfo.webviewZLevel;
      const t = this.getDeviceRect(this.rect);
      return (
        M(e, "isContainer"),
        Object.assign(Object.assign(Object.assign({}, e), t), {
          parentXPath: this.parentNodeDesc.isContainer
            ? this.parentNodeDesc.xpath
            : void 0,
          href: this.proxy.href,
          content: this.proxy.content,
          nodeType: this.nodeType(),
        })
      );
    }
    nodeType() {
      return "input" !== this.name || Ke.changeableInput(this.node)
        ? this.node.tagName
        : "INPUT_BTN";
    }
    desc() {
      return {
        index: this.parentNodeDesc.index || this.proxy.index,
        zLevel: this.zLevel(),
        xpath: this.proxy.xpath,
        isContainer: this.isDefinedContainer(),
      };
    }
    cssVisible() {
      const e = this.computedStyle();
      return (
        Number(e.opacity) > 0 &&
        "visible" === e.visibility &&
        "none" !== e.display
      );
    }
    viewportStatus() {
      const { top: e, left: t, width: i, height: n } = this.rect,
        { winWidth: r, winHeight: s } = this.devicesInfo;
      if (0 >= i || 0 >= n) return jt.OUTER;
      const o = this.node;
      return s > e && r > t && i > 0 && n > 0
        ? Ht(o, t + i / 2, e + n / 2) ||
          Ht(o, t + 1, e + 1) ||
          Ht(o, t + i - 1, e + 1) ||
          Ht(o, t + 1, e + n - 1) ||
          Ht(o, t + i - 1, e + n - 1)
          ? jt.INNER_SHOW
          : jt.INNER_COVERED
        : jt.OUTER;
    }
    isCircleable() {
      return (
        this.proxy.target === this.proxy.origin &&
        (!!this.isDefinedContainer() ||
          (!(
            "input" === this.name &&
            this.node instanceof HTMLInputElement &&
            "password" === this.node.type
          ) &&
            (-1 !== qt.indexOf(this.name) ||
              (Ke.isLeaf(this.node)
                ? !this.isBigBlank()
                : this.hasBackgroundImage() && Ke.depthInside(this.node, 4)))))
      );
    }
    isSimpleContainer() {
      return (
        "select" === this.name ||
        (this.isDefaultContainer() &&
          ((function (e, t) {
            if (0 === e.children.length) return !1;
            for (const i of R(e.children))
              if (-1 === t.indexOf(i.tagName.toLowerCase())) return !1;
            return !0;
          })(this.node, Ut) ||
            !this.node.childElementCount))
      );
    }
    isDefinedContainer() {
      var e;
      return v(this.isContainer)
        ? this.isDefaultContainer() ||
            this.isMarkContainer() ||
            (Ke.isParentOfLeaf(this.node) &&
              (!!(null === (e = this.node.innerText) || void 0 === e
                ? void 0
                : e.trim().length) ||
                (function (e) {
                  const t = e.attributes;
                  if (t.length > 0)
                    for (let e = 0; e < t.length; e++) {
                      const i = t[e].value;
                      if (i && "false" !== i) return !0;
                    }
                  return !1;
                })(this.node))) ||
            "select" === this.name
        : !!this.isContainer;
    }
    isDefaultContainer() {
      return (
        -1 !== Be.SUPPORTED_CONTAINER_TAGS.indexOf(this.tagName) ||
        Ke.clickableInput(this.node)
      );
    }
    isMarkContainer() {
      return (
        this.node.hasAttribute("data-growing-container") ||
        this.node.hasAttribute("growing-container")
      );
    }
    isBigBlank() {
      var e, t;
      const i =
          null !==
            (t =
              null === (e = this.node.innerText) || void 0 === e
                ? void 0
                : e.trim().length) && void 0 !== t
            ? t
            : 0,
        { width: n, height: r } = this.rect,
        { winWidth: s, winHeight: o } = this.devicesInfo;
      return !i && (n > s >> 1 || r > o >> 1);
    }
    hasBackgroundImage() {
      const e = this.computedStyle().backgroundImage;
      return !!e && "none" !== e && e.length > 0;
    }
    zLevel() {
      const e = this.computedStyle(),
        t = e.zIndex;
      if ("auto" !== t) return Number(t || "0") + this.parentNodeDesc.zLevel;
      switch (e.position) {
        case "relative":
          return this.parentNodeDesc.zLevel + 2;
        case "sticky":
          return this.parentNodeDesc.zLevel + 3;
        case "absolute":
          return this.parentNodeDesc.zLevel + 4;
        case "fixed":
          return this.parentNodeDesc.zLevel + 5;
        default:
          return this.parentNodeDesc.zLevel + 1;
      }
    }
    computeWindowRect() {
      if (this.rect) return this.rect;
      const e = this.node.getBoundingClientRect(),
        t = e.top,
        i = e.bottom,
        n = e.left;
      let r = e.right - n,
        s = i - t;
      return (
        0 > t
          ? (s = t + s)
          : t + s > this.devicesInfo.winHeight &&
            (s = this.devicesInfo.winHeight - t),
        0 > n
          ? (r = n + r)
          : n + r > this.devicesInfo.winWidth &&
            (r = this.devicesInfo.winWidth - n),
        (this.rect = {
          top: t,
          left: n,
          width: r,
          height: s,
        }),
        this.rect
      );
    }
    computedStyle() {
      return window.getComputedStyle(this.node);
    }
    getDeviceRect(e) {
      const { scale: t, webviewTop: i, webviewLeft: n } = this.devicesInfo;
      return {
        top: e.top * t + i,
        left: e.left * t + n,
        width: e.width * t,
        height: e.height * t,
      };
    }
  }
  const Kt = ["DOMContentLoaded", "onreadystatechange"],
    Wt = [
      "scroll",
      "resize",
      "load",
      "beforeunload",
      "popstate",
      "hashchange",
      "pagehide",
      "unload",
    ];
  class Vt {
    constructor(e) {
      (this.growingIO = e), this.addDomChangeListener();
    }
    getDomTree(e, t, i, n, r, s) {
      const o = (function (e, t, i, n, r) {
          const s = document.documentElement.clientWidth;
          return {
            winWidth: s,
            winHeight: document.documentElement.clientHeight,
            scale: i / s,
            webviewTop: t,
            webviewLeft: e,
            webviewWidth: i,
            webviewHeight: n,
            webviewZLevel: r,
          };
        })(e, t, i, n, r),
        a = this.getElementsByParent(
          s || document.body,
          {
            isContainer: !1,
            zLevel: 0,
          },
          o
        ),
        {
          domain: d,
          path: c,
          query: l,
          title: h,
        } = this.growingIO.dataStore.currentPage;
      return {
        page: {
          domain: d,
          path: c,
          query: l,
          title: h,
        },
        elements: a,
      };
    }
    getElementsByParent(e, t, i) {
      const n = [];
      return (
        [].slice
          .call(e.childNodes, 0)
          .filter((e) => 1 === e.nodeType)
          .forEach((e) => {
            const r = new Bt(e, t, i);
            if (r.cssVisible() && !r.isIgnore) {
              switch (r.viewportStatus()) {
                case jt.INNER_SHOW:
                  r.isCircleable() && n.push(r.info());
                  break;
                case jt.INNER_COVERED:
                  r.isDefaultContainer() && n.push(r.info());
              }
              r.isSimpleContainer() ||
                [].push.apply(n, this.getElementsByParent(e, r.desc(), i));
            }
          }),
        n
      );
    }
    addDomChangeListener() {
      let e;
      const t =
        (t = "") =>
        () => {
          var i;
          "beforeunload" === t && e && e.disconnect(),
            null === (i = window.GrowingWebViewJavascriptBridge) ||
              void 0 === i ||
              i.onDomChanged();
        };
      (e = new MutationObserver(t("mutation"))),
        e.observe(document.body, {
          attributes: !0,
          characterData: !0,
          childList: !0,
          subtree: !0,
        }),
        Kt.forEach((e) => {
          Y(document, e, t(e));
        }),
        Wt.forEach((e) => {
          Y(window, e, t(e));
        });
    }
  }
  class Mt {
    constructor(e) {
      var t;
      (this.growingIO = e),
        null === (t = this.growingIO.emitter) ||
          void 0 === t ||
          t.on(_e, () => {
            if (window.GrowingWebViewJavascriptBridge) {
              const e = this;
              window.GrowingWebViewJavascriptBridge.getDomTree = function () {
                if (arguments.length >= 4)
                  return (
                    Mt.bindGetDomTree(e.growingIO),
                    Mt.domHelper.getDomTree.apply(Mt.domHelper, arguments)
                  );
              };
            }
          });
    }
    static bindGetDomTree(e) {
      this.domHelper ||
        ((this.domHelper = new Vt(e)),
        (window.GrowingWebViewJavascriptBridge.getDomTree =
          this.domHelper.getDomTree.bind(this.domHelper)));
    }
  }
  var Ft = {
      name: "gioHybridCircle",
      method: Mt,
    },
    $t = {
      name: "gioImpressionTracking",
      method: class {
        constructor(e) {
          var t;
          (this.growingIO = e),
            (this.documentReady = !1),
            (this.main = (e) => {
              "listener" === e
                ? ((this.documentReady = !0),
                  this.growingIO.gioSDKInitialized &&
                    this.initMutationObserver())
                : "emitter" === e &&
                  this.documentReady &&
                  this.initMutationObserver();
            }),
            (this.initIntersectionObserver = () => {
              this.intersectionObserver = new IntersectionObserver((e) => {
                F(e) ||
                  e.map((e) => {
                    const { dataset: t, id: i } = e.target;
                    if (e.intersectionRatio > 0) {
                      const {
                        eventId: e,
                        properties: n,
                        items: r,
                      } = this.getImpressionProperties(t);
                      if (i) {
                        if ("once" === t.gioImpType && B(this.sentImps, i))
                          return;
                        this.sentImps[i] = {
                          eventId: e,
                          properties: n,
                          items: r,
                        };
                      }
                      e && this.growingIO.track(e, n, r);
                    }
                  });
              });
            }),
            (this.initMutationObserver = () => {
              var e;
              this.mutationObserver &&
                (null === (e = this.mutationObserver) ||
                  void 0 === e ||
                  e.disconnect());
              const t = document.querySelectorAll("[data-gio-imp-track]");
              R(t).map((e) => {
                var t;
                null === (t = this.intersectionObserver) ||
                  void 0 === t ||
                  t.observe(e);
              }),
                (this.mutationObserver = new MutationObserver((e) => {
                  e.map((e) => {
                    var t, i;
                    "attributes" === e.type &&
                      (null === (t = e.target.dataset) || void 0 === t
                        ? void 0
                        : t.gioImpTrack) &&
                      (null === (i = this.intersectionObserver) ||
                        void 0 === i ||
                        i.observe(e.target));
                  });
                })),
                this.mutationObserver.observe(document.body, {
                  attributes: !0,
                  childList: !0,
                  subtree: !0,
                  attributeOldValue: !0,
                  attributeFilter: [
                    "data-gio-imp-track",
                    "data-gio-imp-attrs",
                    "data-gio-imp-items",
                    /^data-gio-track-[a-z]+$/i,
                  ],
                });
            }),
            (this.getImpressionProperties = (e) => {
              let t = {
                eventId: void 0,
                properties: {},
              };
              if (!(null == e ? void 0 : e.gioImpTrack)) return t;
              if (((t.eventId = e.gioImpTrack), B(e, "gioImpAttrs")))
                (t.properties = J(() =>
                  y(e.gioImpAttrs) ? e.gioImpAttrs : JSON.parse(e.gioImpAttrs)
                )),
                  (t.items = J(() =>
                    y(e.gioImpItems) ? e.gioImpItems : JSON.parse(e.gioImpItems)
                  ));
              else {
                const i = /^gioTrack(.+)/;
                for (const n in e) {
                  let r;
                  const s = n.match(i);
                  s &&
                    ((r = j(s[1])), "track" !== r && (t.properties[r] = e[n]));
                }
              }
              return (
                (t.properties = Z(t.properties)),
                (t.items = Z(t.items)),
                (/^\w+$/.test(t.eventId) &&
                  !Number.isInteger(Number(N(t.eventId.split(""))))) ||
                  ((t.eventId = null), (t = {})),
                t
              );
            }),
            (this.sentImps = {}),
            window.IntersectionObserver && window.MutationObserver
              ? (this.initIntersectionObserver(),
                Y(
                  document,
                  "readystatechange",
                  () => {
                    L(["interactive", "complete"], document.readyState) &&
                      this.main("listener");
                  },
                  {
                    once: !0,
                  }
                ),
                null === (t = this.growingIO.emitter) ||
                  void 0 === t ||
                  t.on(_e, () => this.main("emitter")),
                Y(window, "unload", () => {
                  var e, t;
                  null === (e = this.intersectionObserver) ||
                    void 0 === e ||
                    e.disconnect(),
                    null === (t = this.mutationObserver) ||
                      void 0 === t ||
                      t.disconnect();
                }))
              : X(
                  "当前浏览器不支持半自动埋点，gioImpressionTracking已自动关闭！",
                  "warn"
                );
        }
      },
    },
    zt = {
      name: "gioWebCircle",
      method: class {
        constructor(e) {
          var t;
          (this.growingIO = e),
            (this.injectCircle = (e, t) => {
              const i = document.createElement("link"),
                n = document.createElement("script");
              (i.rel = "stylesheet"),
                (i.href = e),
                (n.src = t),
                document.head.appendChild(i),
                document.head.appendChild(n);
            }),
            null === (t = this.growingIO.emitter) ||
              void 0 === t ||
              t.on(_e, () => {
                window.addEventListener("message", (e) => {
                  const { data: t, source: i } = e,
                    n = window.vds;
                  if (t && i) {
                    const e = i.vds,
                      r = t.cssURL,
                      s = t.jsURL;
                    e &&
                      "SDK_INJECT_CIRCLE_SCRIPT" === t.type &&
                      n.projectId === e.projectId &&
                      n.dataSourceId === e.dataSourceId &&
                      this.injectCircle(r, s);
                  }
                });
              });
        }
      },
    };
  const Xt = ["gioPerformance"];
  class Jt {
    constructor(e) {
      var t, i, n, r;
      (this.growingIO = e),
        (this.innerPluginInit = () => {
          var e;
          Xt.forEach((e) => {
            var t;
            return M(
              null === (t = this.pluginsContext) || void 0 === t
                ? void 0
                : t.plugins,
              e
            );
          }),
            K(
              null === (e = this.pluginsContext) || void 0 === e
                ? void 0
                : e.plugins
            ).forEach((e) => {
              var t;
              const { name: i, method: n } =
                null === (t = this.pluginsContext) || void 0 === t
                  ? void 0
                  : t.plugins[e];
              P(this.pluginItems, (e) => e.name === i) ||
                this.pluginItems.push({
                  name: j(i || e),
                  method: n || ((e) => {}),
                });
            }),
            F(this.pluginItems) || this.installAll();
        }),
        (this.install = (e, t, i) => {
          var n, r;
          const s = t || P(this.pluginItems, (t) => t.name === e);
          if (
            (null === (n = this.growingIO) || void 0 === n
              ? void 0
              : n.plugins)[e]
          )
            return X(`重复加载插件 ${e} 或插件重名，已跳过加载!`, "warn"), !1;
          if (!s) return X(`插件加载失败!不存在名为 ${e} 的插件!`, "error"), !1;
          try {
            return (
              ((null === (r = this.growingIO) || void 0 === r
                ? void 0
                : r.plugins)[e] = new s.method(this.growingIO, i)),
              "cdp" === this.growingIO.gioEnvironment &&
                t &&
                X("加载插件 " + e, "info"),
              !0
            );
          } catch (e) {
            return X("插件加载异常 " + e, "error"), !1;
          }
        }),
        (this.installAll = (e) => {
          (e || this.pluginItems).forEach((t) => {
            this.install(
              t.name,
              e ? t : void 0,
              e ? (null == t ? void 0 : t.options) : void 0
            ) &&
              !P(this.pluginItems, (e) => e.name === t.name) &&
              this.pluginItems.push({
                name: j(t.name),
                method: t.method ? t.method : () => {},
              });
          });
        }),
        (this.uninstall = (e) => {
          var t;
          M(this.pluginItems, e);
          const i = M(
            null === (t = this.growingIO) || void 0 === t ? void 0 : t.plugins,
            e
          );
          return i || X(`卸载插件 ${e} 失败!`, "error"), i;
        }),
        (this.uninstallAll = () => {
          this.pluginItems.forEach((e) => this.uninstall(e.name));
        }),
        (this.lifeError = (e, t) => X(`插件执行错误 ${e.name} ${t}`, "error")),
        (this.onComposeBefore = (e) => {
          this.pluginItems.forEach((t) => {
            var i;
            const n =
              null === (i = this.growingIO.plugins[t.name]) || void 0 === i
                ? void 0
                : i.onComposeBefore;
            if (n && E(n))
              try {
                n(e);
              } catch (e) {
                this.lifeError(t, e);
              }
          });
        }),
        (this.onComposeAfter = (e) => {
          this.pluginItems.forEach((t) => {
            var i;
            const n =
              null === (i = this.growingIO.plugins[t.name]) || void 0 === i
                ? void 0
                : i.onComposeAfter;
            if (n && E(n))
              try {
                n(e);
              } catch (e) {
                this.lifeError(t, e);
              }
          });
        }),
        (this.onSendBefore = (e) => {
          this.pluginItems.forEach((t) => {
            var i;
            const n =
              null === (i = this.growingIO.plugins[t.name]) || void 0 === i
                ? void 0
                : i.onSendBefore;
            if (n && E(n))
              try {
                n(e);
              } catch (e) {
                this.lifeError(t, e);
              }
          });
        }),
        (this.onSendAfter = (e) => {
          this.pluginItems.forEach((t) => {
            var i;
            const n =
              null === (i = this.growingIO.plugins[t.name]) || void 0 === i
                ? void 0
                : i.onSendAfter;
            if (n && E(n))
              try {
                n(e);
              } catch (e) {
                this.lifeError(t, e);
              }
          });
        }),
        (this.pluginsContext = {
          plugins: {},
        }),
        (this.pluginItems = []),
        null === (t = this.growingIO.emitter) ||
          void 0 === t ||
          t.on("onComposeBefore", this.onComposeBefore),
        null === (i = this.growingIO.emitter) ||
          void 0 === i ||
          i.on("onComposeAfter", this.onComposeAfter),
        null === (n = this.growingIO.emitter) ||
          void 0 === n ||
          n.on("onSendBefore", this.onSendBefore),
        null === (r = this.growingIO.emitter) ||
          void 0 === r ||
          r.on("onSendAfter", this.onSendAfter);
    }
  }
  class Zt extends Jt {
    constructor(e) {
      super(e),
        (this.growingIO = e),
        (this.growingIO.gioSDKFull = !0),
        (this.pluginsContext = {
          plugins: {
            gioCompress: xe,
            gioCustomTracking: Ae,
            gioEmbeddedAdapter: qe,
            gioEventAutoTracking: Pt,
            gioHybridAdapter: kt,
            gioHybridCircle: Ft,
            gioImpressionTracking: $t,
            gioWebCircle: zt,
          },
        });
    }
  }
  class Yt {
    constructor() {
      var e;
      (this.trackingId = "g0"),
        (this.init = (e) => {
          var t, i, n, r, s;
          X("Gio Web SDK 初始化中...", "info");
          const {
            initOptions: o,
            currentPage: a,
            sendVisit: d,
            sendPage: c,
          } = this.dataStore;
          o(e),
            (this.storage = Te(this.vdsConfig)),
            this.initCallback(),
            null === (t = this.emitter) || void 0 === t || t.emit(Ee, this),
            null ===
              (n =
                null === (i = this.plugins) || void 0 === i
                  ? void 0
                  : i.gioEventAutoTracking) ||
              void 0 === n ||
              n.main(),
            a.hookHistory(),
            a.parsePage(),
            null === (r = this.emitter) || void 0 === r || r.emit(_e, this),
            X("Gio Web SDK 初始化完成！", "success"),
            this.useEmbeddedInherit ||
              ((this.dataStore.lastVisitEvent.timestamp = a.time), d()),
            c(),
            (this.gioSDKInitialized = !0),
            (this.vdsConfig.gioSDKInitialized = !0),
            (window[this.vds] = this.vdsConfig),
            null === (s = this.emitter) ||
              void 0 === s ||
              s.emit("SDK_INITIALIZED_COMPLATE", this);
        }),
        (this.setOption = (e, t) => {
          if (L(s, e)) {
            const i = this.dataStore.setOption(e, t);
            return i && o[e] && X(`已${t ? "开启" : "关闭"}${o[e]}`, "info"), i;
          }
          return X(`不存在可修改的配置项：${e}，请检查后重试!`, "warn"), !1;
        }),
        (this.getOption = (e) => this.dataStore.getOption(e)),
        (this.setGeneralProps = (e) => {
          y(e) && !F(e)
            ? ((this.dataStore.generalProps = Object.assign(
                Object.assign({}, this.dataStore.generalProps),
                e
              )),
              K(this.dataStore.generalProps).forEach((e) => {
                L([void 0, null], this.dataStore.generalProps[e]) &&
                  (this.dataStore.generalProps[e] = "");
              }))
            : this.callError("setGeneralProps");
        }),
        (this.clearGeneralProps = (e) => {
          _(e) && !F(e)
            ? e.forEach((e) => {
                M(this.dataStore.generalProps, e);
              })
            : (this.dataStore.generalProps = {});
        }),
        (this.reissuePage = () => {
          this.dataStore.sendPage();
        }),
        (this.notRecommended = () =>
          X(
            "不推荐的方法使用，建议使用 gio('setOption', [optionName], [value])!",
            "info"
          )),
        (this.callError = (e, t = !0, i = "参数不合法") =>
          X(`${t ? "调用" : "设置"} ${e} 失败，${i}!`, "warn")),
        (this.updateImpression = () => {
          var e, t;
          const i =
            null ===
              (t =
                null === (e = this.plugins) || void 0 === e
                  ? void 0
                  : e.gioImpressionTracking) || void 0 === t
              ? void 0
              : t.main;
          i
            ? i("emitter")
            : X(
                "updateImpression 错误! 请集成半自动埋点浏览插件后重试!",
                "error"
              );
        }),
        (this.gioEnvironment = "cdp"),
        (this.sdkVersion = "3.8.6"),
        (this.vds = window.gioCompatibilityVds ? "gdp_vds" : "vds"),
        (this.utils = Object.assign(Object.assign({}, z), ee)),
        (this.emitter = {
          all: (e = e || new Map()),
          on: function (t, i) {
            var n = e.get(t);
            n ? n.push(i) : e.set(t, [i]);
          },
          off: function (t, i) {
            var n = e.get(t);
            n && (i ? n.splice(n.indexOf(i) >>> 0, 1) : e.set(t, []));
          },
          emit: function (t, i) {
            var n = e.get(t);
            n &&
              n.slice().map(function (e) {
                e(i);
              }),
              (n = e.get("*")) &&
                n.slice().map(function (e) {
                  e(t, i);
                });
          },
        }),
        (this.useEmbeddedInherit = !1),
        (this.useHybridInherit = !1),
        (this.gioSDKInitialized = !1),
        (this.plugins = new Zt(this)),
        this.plugins.innerPluginInit();
    }
  }
  class Qt {
    constructor(e) {
      this.growingIO = e;
      const { projectId: t } = this.growingIO.vdsConfig,
        {
          getItem: i,
          setItem: n,
          getKeys: r,
          removeItem: s,
        } = this.growingIO.storage;
      (this.getItem = i),
        (this.setItem = n),
        (this.getKeys = r),
        (this.removeItem = s),
        (this.sIdStorageName = t + "_gdp_session_id"),
        (this.uidStorageName = "gdp_user_id_gioenc"),
        (this.userIdStorageName = t + "_gdp_cs1_gioenc"),
        (this.userKeyStorageName = t + "_gdp_user_key_gioenc"),
        (this.gioIdStorageName = t + "_gdp_gio_id_gioenc");
    }
    get sessionId() {
      return (
        this.getItem(this.sIdStorageName) ||
        ((this.sessionId = oe()), this.sessionId)
      );
    }
    set sessionId(e) {
      var t;
      e || (e = oe());
      const i = this.getItem(this.sIdStorageName) || this.prevSessionId,
        { sessionExpires: n = 30 } = this.growingIO.vdsConfig;
      this.setItem(this.sIdStorageName, e, +Date.now() + 60 * n * 1e3),
        i !== e &&
          (this.getKeys()
            .filter((e) => /.+_gdp_session_id_.{36}/.test(e))
            .forEach((e) => {
              this.removeItem(e);
            }),
          this.setItem(this.growingIO.dataStore.visitStorageName, ""),
          null === (t = this.growingIO.emitter) ||
            void 0 === t ||
            t.emit(Se, {
              newSessionId: e,
              oldSessionId: i,
            })),
        (this.prevSessionId = e);
    }
    get uid() {
      return this.getItem(this.uidStorageName) || ((this.uid = oe()), this.uid);
    }
    set uid(e) {
      var t;
      const i = this.getItem(this.uidStorageName) || this.prevUId;
      this.setItem(this.uidStorageName, e),
        i !== e &&
          (null === (t = this.growingIO.emitter) ||
            void 0 === t ||
            t.emit("UID_UPDATE", {
              newUId: e,
              oldUId: i,
            })),
        (this.prevUId = e);
    }
    get userId() {
      return this.getItem(this.userIdStorageName) || "";
    }
    set userId(e) {
      var t, i;
      const n = this.getItem(this.userIdStorageName) || this.prevUserId;
      this.setItem(this.userIdStorageName, e),
        null === (t = this.growingIO.emitter) ||
          void 0 === t ||
          t.emit(Ne, {
            newUserId: e,
            oldUserId: n,
            userKey: this.userKey,
          }),
        n !== e &&
          (null === (i = this.growingIO.emitter) ||
            void 0 === i ||
            i.emit("USERID_UPDATE", {
              newUserId: e,
              oldUserId: n,
              userKey: this.userKey,
            })),
        e && (this.gioId = e),
        (this.prevUserId = e);
    }
    get userKey() {
      return this.getItem(this.userKeyStorageName) || "";
    }
    set userKey(e) {
      var t, i;
      const n = this.getItem(this.userKeyStorageName) || this.prevUserKey;
      this.setItem(this.userKeyStorageName, e),
        null === (t = this.growingIO.emitter) ||
          void 0 === t ||
          t.emit(Ce, {
            newUserKey: e,
            oldUserKey: n,
            userId: this.userId,
          }),
        n !== e &&
          (null === (i = this.growingIO.emitter) ||
            void 0 === i ||
            i.emit("USERKEY_UPDATE", {
              newUserKey: e,
              oldUserKey: n,
              userId: this.userId,
            })),
        (this.prevUserKey = e);
    }
    get gioId() {
      return this.getItem(this.gioIdStorageName) || "";
    }
    set gioId(e) {
      var t;
      const i = this.getItem(this.gioIdStorageName) || this.prevGioId;
      this.setItem(this.gioIdStorageName, e),
        i !== e &&
          (null === (t = this.growingIO.emitter) ||
            void 0 === t ||
            t.emit("GIOID_UPDATE", {
              newGioId: e,
              oldGioId: i,
            })),
        (this.prevGioId = e);
    }
  }
  class ei {
    constructor(e) {
      (this.growingIO = e),
        (this.main = () => {
          var e, t;
          const {
              sdkVersion: i,
              useEmbeddedInherit: n,
              vdsConfig: r,
              userStore: s,
              dataStore: o,
              trackingId: a,
            } = this.growingIO,
            { path: d, query: c } = o.currentPage;
          let l = {
            appVersion: r.version,
            dataSourceId: r.dataSourceId,
            deviceId: s.uid,
            domain: n ? r.appId : window.location.host,
            gioId: s.gioId,
            language: navigator.language,
            path: d,
            platform: r.platform,
            query: c,
            referralPage:
              (null === (e = o.lastPageEvent) || void 0 === e
                ? void 0
                : e.referralPage) || "",
            screenHeight: window.screen.height,
            screenWidth: window.screen.width,
            sdkVersion: i,
            sessionId: s.sessionId,
            timestamp: +Date.now(),
            title:
              null !== (t = J(() => document.title.slice(0, 255))) &&
              void 0 !== t
                ? t
                : "",
            userId: s.userId,
          };
          if (
            (r.enableIdMapping && (l.userKey = s.userKey),
            F(r.ignoreFields) ||
              r.ignoreFields.forEach((e) => {
                M(l, e);
              }),
            n && !F(this.minpExtraParams))
          ) {
            const e = Object.assign({}, l);
            W(
              Object.assign(Object.assign({}, l), this.minpExtraParams),
              (t, i) => {
                var n;
                L(r.embeddedIgnore, i)
                  ? ((l[i] = e[i]),
                    "domain" === i && (l[i] = window.location.host))
                  : (l[i] =
                      null !== (n = this.minpExtraParams[i]) && void 0 !== n
                        ? n
                        : l[i]);
              }
            );
          }
          return (l.trackingId = a), l;
        }),
        (this.minpExtraParams = {});
    }
  }
  class ti {
    constructor(e) {
      (this.growingIO = e),
        (this.parsePage = () => {
          const { hashtag: e } = this.growingIO.vdsConfig,
            t = location.pathname,
            i = location.search,
            n = location.hash,
            r = n.indexOf("?");
          (this.domain = window.location.host),
            (this.title = document.title.slice(0, 255)),
            (this.time = +Date.now()),
            (this.path = t),
            (this.query = i),
            e &&
              (r > -1
                ? ((this.path += n.slice(0, r)),
                  (this.query = this.query + "&" + n.slice(r + 1)))
                : (this.path += n)),
            this.query &&
              L(["?", "&"], this.query.charAt(0)) &&
              (this.query = this.query.slice(1));
        }),
        (this._getNoHashHref = () => {
          const {
            protocol: e,
            host: t,
            pathname: i,
            search: n,
          } = window.location;
          return `${e}://${t}${i}${n}`;
        }),
        (this.getReferralPage = () => {
          var e, t;
          const {
            dataStore: { lastPageEvent: i },
          } = this.growingIO;
          return (null == i ? void 0 : i.path) === this.path &&
            (null !== (e = null == i ? void 0 : i.query) && void 0 !== e
              ? e
              : "") === (null !== (t = this.query) && void 0 !== t ? t : "")
            ? null == i
              ? void 0
              : i.referralPage
            : (null == i ? void 0 : i.path)
            ? this.lastHref
            : document.referrer;
        }),
        (this.pageListener = () => {
          const { hashtag: e } = this.growingIO.vdsConfig;
          let t = window.location.href,
            i = this.lastHref;
          e || ((t = this._getNoHashHref()), (i = this.lastNoHashHref)),
            i !== t && (this.parsePage(), this.buildPageEvent());
        }),
        (this.hookHistory = () => {
          const e = window.history.pushState,
            t = window.history.replaceState,
            i = this;
          e &&
            J(
              () =>
                (window.history.pushState = function () {
                  e.apply(window.history, arguments),
                    setTimeout(i.pageListener);
                })
            ),
            t &&
              J(
                () =>
                  (window.history.replaceState = function () {
                    t.apply(window.history, arguments),
                      setTimeout(i.pageListener);
                  })
              ),
            Y(window, "popstate", this.pageListener);
          const { hashtag: n } = this.growingIO.vdsConfig;
          n && Y(window, "hashchange", this.pageListener);
        }),
        (this.buildPageEvent = (e) => {
          const {
            dataStore: {
              lastPageEvent: t,
              eventContextBuilder: i,
              eventConverter: n,
            },
          } = this.growingIO;
          let r = Object.assign(
            Object.assign(
              {
                eventType: "PAGE",
              },
              i()
            ),
            {
              protocolType: location.protocol.substring(
                0,
                location.protocol.length - 1
              ),
              referralPage: this.getReferralPage(),
            }
          );
          F(e) || (r = Object.assign(Object.assign({}, r), e)),
            (r.timestamp = this.time),
            n(r),
            (this.lastHref = window.location.href),
            (this.lastNoHashHref = this._getNoHashHref()),
            (this.lastLocation = Object.assign({}, window.location));
        }),
        (this.title = document.title.slice(0, 255)),
        (this.lastLocation = Object.assign({}, window.location));
    }
  }
  const ii = {
    referralPage: document.referrer,
  };
  class ni {
    constructor(r) {
      var a, c, l;
      (this.growingIO = r),
        (this.ALLOW_SETTING = Object.assign(
          Object.assign({}, t),
          "saas" === this.growingIO.gioEnvironment ? n : i
        )),
        (this.allowOptKeys = Object.keys(this.ALLOW_SETTING)),
        (this.trackTimers = {}),
        (this.setSequenceIds = (e, t) => {
          let i = this.growingIO.storage.getItem(this.seqStorageIdName) || {};
          "gsid" === e
            ? (i.globalKey = t)
            : (i = Object.assign(Object.assign({}, i), t)),
            this.growingIO.storage.setItem(this.seqStorageIdName, i);
        }),
        (this.initOptions = (t) => {
          var i, n, r, s, a, c, l;
          const { projectId: h, dataSourceId: u, appId: g } = t;
          this.initialDataSourceId = u;
          const p = {};
          this.allowOptKeys.forEach((i) => {
            const n = this.ALLOW_SETTING[i].type;
            let r = _(n) ? !L(n, $(t[i])) : $(t[i]) !== n;
            "platform" !== i || L(e, t[i]) || (r = !0),
              r
                ? (p[i] = this.ALLOW_SETTING[i].default)
                : "ignoreFields" === i
                ? (p.ignoreFields = t.ignoreFields.filter((e) => L(d, e)))
                : ((p[i] = t[i]),
                  L(["dataCollect", "autotrack"], i) &&
                    (p[i] || X("已关闭" + o[i], "info")));
          }),
            (p.sessionExpires = Math.round(p.sessionExpires)),
            (O(p.sessionExpires) ||
              1 > p.sessionExpires ||
              p.sessionExpires > 360) &&
              (p.sessionExpires = 30),
            (p.storageType = p.storageType.toLowerCase()),
            (p.sendType = p.sendType.toLowerCase()),
            L(["beacon", "xhr", "image"], p.sendType) ||
              (p.sendType = "beacon"),
            (!O(Number(p.requestTimeout)) && p.requestTimeout > 0) ||
              (p.requestTimeout = 5e3),
            (this.growingIO.vdsConfig = Object.assign(
              Object.assign(
                Object.assign(
                  {},
                  null !== (i = window.vds) && void 0 !== i ? i : {}
                ),
                p
              ),
              {
                projectId: h,
                dataSourceId: u,
                appId: g,
                performance: {
                  monitor:
                    null ===
                      (r =
                        null === (n = p.performance) || void 0 === n
                          ? void 0
                          : n.monitor) ||
                    void 0 === r ||
                    r,
                  exception:
                    null ===
                      (a =
                        null === (s = p.performance) || void 0 === s
                          ? void 0
                          : s.exception) ||
                    void 0 === a ||
                    a,
                  network:
                    null !==
                      (l =
                        null === (c = p.performance) || void 0 === c
                          ? void 0
                          : c.network) &&
                    void 0 !== l &&
                    l,
                },
              }
            )),
            (window.vds = this.growingIO.vdsConfig),
            (this.seqStorageIdName = h + "_gdp_sequence_ids"),
            (this.visitStorageName = h + "_gdp_session_id_sent");
        }),
        (this.setOption = (e, t) => {
          var i;
          const {
              vdsConfig: n,
              callError: r,
              uploader: o,
              emitter: a,
            } = this.growingIO,
            d = I(e) && L(s, e),
            c =
              d &&
              typeof t ===
                ((null === (i = this.ALLOW_SETTING[e]) || void 0 === i
                  ? void 0
                  : i.type) || "string"),
            l = Object.assign({}, n);
          return d && c
            ? ((n[e] = t),
              "dataCollect" === e &&
                l.dataCollect !== t &&
                (t
                  ? (this.sendVisit(!0), this.sendPage())
                  : this.growingIO.clearTrackTimer()),
              L(["host", "scheme"], e) && (null == o || o.generateHost()),
              null == a ||
                a.emit("OPTION_CHANGE", {
                  optionName: e,
                  optionValue: t,
                }),
              (window.vds[e] = t),
              !0)
            : (r("setOption > " + e), !1);
        }),
        (this.getOption = (e) => {
          const { vdsConfig: t, callError: i } = this.growingIO;
          return e && B(t, k(e))
            ? t[k(e)]
            : v(e)
            ? Object.assign({}, t)
            : void i("getOption > " + e);
        }),
        (this.sendVisit = (e) => {
          const {
              userStore: { sessionId: t },
              storage: i,
            } = this.growingIO,
            n = i.getItem(this.visitStorageName);
          (!e && t === n) ||
            ((this.lastVisitEvent.timestamp = this.currentPage.time - 1),
            this.buildVisitEvent());
        }),
        (this.buildVisitEvent = (e) => {
          const {
              dataStore: { eventContextBuilder: t, eventConverter: i },
              emitter: n,
              storage: r,
              userStore: s,
            } = this.growingIO,
            {
              referralPage: o,
              title: a,
              path: d,
              query: c,
              timestamp: l,
            } = this.lastVisitEvent;
          let h = Object.assign(
            Object.assign(
              {
                eventType: "VISIT",
              },
              t()
            ),
            {
              referralPage: o || this.currentPage.getReferralPage(),
              timestamp: l,
            }
          );
          d && ((h.title = a), (h.path = d), (h.query = c)),
            F(e) ||
              ((h.session = (null == e ? void 0 : e.session) || h.session),
              (h.trackingId = null == e ? void 0 : e.trackingId),
              (h = Object.assign(Object.assign({}, h), e)));
          const u = ({ requestData: e }) => {
            "VISIT" === e.eventType &&
              e.trackingId === this.growingIO.trackingId &&
              (s.sessionId === e.sessionId &&
                r.setItem(this.visitStorageName, e.sessionId),
              n.off("onSendAfter", u));
          };
          n.on("onSendAfter", u), i(h);
        }),
        (this.sendPage = (e) => {
          e && this.currentPage.parsePage(), this.currentPage.buildPageEvent();
        }),
        (this.buildErrorEvent = (e) => {
          const {
            dataStore: { eventContextBuilder: t, eventConverter: i },
          } = this.growingIO;
          i(
            Object.assign(
              {
                eventType: "CUSTOM",
                pageShowTimestamp: this.currentPage.time,
                eventName: "onError",
                attributes: e,
              },
              t()
            )
          );
        }),
        (this.currentPage = new ti(this.growingIO)),
        (this.eventContextBuilderInst = new ei(this.growingIO)),
        (this.eventContextBuilder = this.eventContextBuilderInst.main),
        (this.generalProps = {}),
        (this.lastVisitEvent = ii),
        null === (a = this.growingIO.emitter) ||
          void 0 === a ||
          a.on("onComposeAfter", ({ composedEvent: e }) => {
            ("VISIT" !== e.eventType && "vst" !== e.t) ||
              e.trackingId !== this.growingIO.trackingId ||
              (this.lastVisitEvent = e);
          }),
        (this.lastPageEvent = {}),
        null === (c = this.growingIO.emitter) ||
          void 0 === c ||
          c.on("onComposeAfter", ({ composedEvent: e }) => {
            ("PAGE" !== e.eventType && "page" !== e.t) ||
              e.trackingId !== this.growingIO.trackingId ||
              (this.lastPageEvent = e);
          }),
        null === (l = this.growingIO.emitter) ||
          void 0 === l ||
          l.on(Se, () => {
            if (this.growingIO.gioSDKInitialized) {
              this.currentPage.parsePage();
              const {
                title: e,
                path: t,
                query: i,
                time: n,
                getReferralPage: r,
              } = this.currentPage;
              (this.lastVisitEvent = {
                referralPage: document.referrer || r(),
                title: e,
                path: t,
                query: i,
                timestamp: n - 1,
              }),
                this.sendVisit(!0),
                this.sendPage(!0);
            }
          });
    }
    get esid() {
      const e = this.growingIO.storage.getItem(this.seqStorageIdName) || {};
      let t = Object.assign({}, e);
      return (
        M(t, "globalKey"),
        (t = y(t) && !v(t) ? t : {}),
        (this._esid = {}),
        K(t).forEach((e) => {
          this._esid[e] = O(Number(t[e])) || t[e] >= 1e9 || 1 > t[e] ? 1 : t[e];
        }),
        this._esid
      );
    }
    set esid(e) {
      const t = {};
      K(e).forEach((i) => {
        t[i] = O(e[i]) || e[i] >= 1e9 || 1 > e[i] ? 1 : e[i];
      }),
        V(this._esid, t) ||
          ((this._esid = t), this.setSequenceIds("esid", this._esid));
    }
    get gsid() {
      const e = this.growingIO.storage.getItem(this.seqStorageIdName) || {},
        t = Number(e.globalKey);
      return (this._gsid = O(t) || t >= 1e9 || 1 > t ? 1 : t), this._gsid;
    }
    set gsid(e) {
      O(Number(e)) || e >= 1e9 || 1 > e ? (this._gsid = 1) : (this._gsid = e),
        this.setSequenceIds("gsid", this._gsid);
    }
  }
  class ri extends ni {
    constructor(e) {
      super(e),
        (this.growingIO = e),
        (this.eventConverter = (e) => {
          var t;
          const { vdsConfig: i, dataStore: n, uploader: r } = this.growingIO;
          if (i.dataCollect) {
            e.trackingId === this.growingIO.trackingId &&
              ((e.globalSequenceId = n.gsid),
              (e.eventSequenceId = n.esid[e.eventType] || 1));
            const i = {};
            W(e, (e, t) => {
              var n;
              if ("element" === t) {
                const t = null !== (n = N(e)) && void 0 !== n ? n : {};
                W(t, (e, t) => {
                  (F(e) && 0 !== e) || (i[t] = e);
                });
              } else ((F(e) || v(e)) && 0 !== e) || (i[t] = e);
            }),
              e.trackingId === this.growingIO.trackingId &&
                ((this.growingIO.dataStore.gsid += 1),
                (this.growingIO.dataStore.esid = Object.assign(
                  Object.assign({}, this.growingIO.dataStore.esid),
                  {
                    [i.eventType]:
                      (this.growingIO.dataStore.esid[i.eventType] || 1) + 1,
                  }
                ))),
              null === (t = this.growingIO.emitter) ||
                void 0 === t ||
                t.emit("onComposeAfter", {
                  composedEvent: Object.assign({}, i),
                }),
              e.trackingId === this.growingIO.trackingId && r.commitRequest(i);
          } else "VISIT" === e.eventType && (this.lastVisitEvent = e);
        });
    }
  }
  class si {
    constructor(e) {
      (this.growingIO = e),
        (this.getSendType = () => {
          const { sendType: e } = this.growingIO.vdsConfig;
          return "beacon" === e
            ? (() => {
                var e;
                const t = !!(null ===
                    (e =
                      null === window || void 0 === window
                        ? void 0
                        : window.navigator) || void 0 === e
                    ? void 0
                    : e.sendBeacon),
                  i = window.navigator.userAgent;
                if (i.match(/(iPad|iPhone|iPod)/g)) {
                  const e = ((e) => {
                    const t = e
                      .toLowerCase()
                      .match(/cpu.*os (.*?) like mac os/i);
                    return !t || 2 > t.length
                      ? 0
                      : +t[1].split("_").slice(0, 2).join(".");
                  })(i);
                  return t && e > 13;
                }
                return t;
              })()
              ? "beacon"
              : "xhr"
            : e;
        }),
        (this.commitRequest = (e) => {
          const t = Object.assign({}, e);
          this.requestQueue.push(
            Object.assign(Object.assign({}, t), {
              requestType: this.getSendType(),
            })
          ),
            this.initiateRequest();
        }),
        (this.initiateRequest = () => {
          var e, t;
          if (
            [...this.requestQueue].length > 0 &&
            this.requestingNum < this.requestLimit
          ) {
            const {
              vdsConfig: i,
              emitter: n,
              plugins: r,
              useHybridInherit: s,
            } = this.growingIO;
            if (
              ((this.requestQueue = [...this.requestQueue].filter(
                (e) =>
                  (this.retryIds[e.globalSequenceId || e.esid] || 0) <=
                  this.retryLimit
              )),
              F(this.requestQueue))
            )
              return;
            const o = this.requestQueue.shift(),
              { requestType: a } = o;
            null == n ||
              n.emit("onSendBefore", {
                requestData: Object.assign({}, o),
              });
            const d = Object.assign({}, o);
            if (
              (M(d, ["requestType", "trackingId"]),
              i.debug &&
                console.log(
                  "[GrowingIO Debug]:",
                  JSON.stringify(d, null, 2).replace(
                    /\"/g,
                    (() => {
                      const e = window.navigator.userAgent;
                      return (
                        /(\d+\.\d)?(?:\.\d)?\s+safari\/?(\d+\.\d+)?/i.test(e) &&
                        !/chrome\/(\d+\.\d+)/i.test(e)
                      );
                    })()
                      ? ""
                      : '"'
                  )
                ),
              (this.requestingNum += 1),
              s)
            )
              return this.requestSuccessFn(o), !1;
            let c = Object.assign({}, d);
            switch (
              (i.compress && (null == r ? void 0 : r.gioCompress)
                ? "image" === a
                  ? ((this.compressType = "11"),
                    (c =
                      null === (e = null == r ? void 0 : r.gioCompress) ||
                      void 0 === e
                        ? void 0
                        : e.compressToEncodedURIComponent(JSON.stringify([c]))))
                  : ((this.compressType = "1"),
                    (c =
                      null === (t = null == r ? void 0 : r.gioCompress) ||
                      void 0 === t
                        ? void 0
                        : t.compressToUint8Array(JSON.stringify([c]))))
                : ((this.compressType = "0"), (c = JSON.stringify([c]))),
              a)
            ) {
              case "beacon":
              default:
                this.sendByBeacon(o, c);
                break;
              case "xhr":
                this.sendByXHR(o, c);
                break;
              case "image":
                this.sendByImage(o, c);
            }
          }
        }),
        (this.generateURL = () =>
          `${this.requestURL}?stm=${+Date.now()}&compress=${
            this.compressType
          }`),
        (this.sendByBeacon = (e, t) => {
          navigator.sendBeacon(this.generateURL(), t)
            ? this.requestSuccessFn(e)
            : this.requestFailFn(e, "beacon");
        }),
        (this.sendByXHR = (e, t) => {
          const i = new XMLHttpRequest();
          if (i)
            return (
              i.open("POST", this.generateURL(), !0),
              (i.onload = () => {
                204 === i.status
                  ? this.requestSuccessFn(e)
                  : this.requestFailFn(e, "xhr");
              }),
              (i.ontimeout =
                i.onerror =
                i.onabort =
                  () => {
                    this.requestFailFn(e, "xhr");
                  }),
              i.setRequestHeader("Content-Type", "text/plain;charset=UTF-8"),
              (i.timeout = this.growingIO.vdsConfig.requestTimeout),
              void i.send(t)
            );
          if (
            null === window || void 0 === window
              ? void 0
              : window.XDomainRequest
          ) {
            const i = new window.XDomainRequest();
            i.open(
              "POST",
              this.generateURL().replace("https://", "http://"),
              !0
            ),
              (i.onload = () => {
                204 === i.status
                  ? this.requestSuccessFn(e)
                  : this.requestFailFn(e, "xhr");
              }),
              (i.onerror = i.ontimeout =
                () => {
                  this.requestFailFn(e, "xhr");
                }),
              i.send(t);
          }
        }),
        (this.sendByImage = (e, t) => {
          const i = `${this.generateURL()}&data=${t}`;
          let n = document.createElement("img");
          (n.width = 1), (n.height = 1);
          let r = window.setTimeout(() => {
            (this.requestingNum -= 1),
              this.clearImage(n),
              window.clearTimeout(r),
              (r = null),
              this.initiateRequest();
          }, this.growingIO.vdsConfig.requestTimeout);
          (n.onload = () => {
            this.requestSuccessFn(e),
              this.clearImage(n),
              window.clearTimeout(r),
              (r = null);
          }),
            (n.onerror = n.onabort =
              () => {
                this.requestSuccessFn(e),
                  this.clearImage(n),
                  window.clearTimeout(r),
                  (r = null);
              }),
            (n.src = i);
        }),
        (this.clearImage = (e) => {
          (e.src = ""),
            (e.onload = () => {}),
            (e.onerror = e.onabort = () => {}),
            (e = null);
        }),
        (this.requestSuccessFn = (e) => {
          var t;
          this.requestingNum -= 1;
          const i = e.globalSequenceId || e.esid || -1;
          this.retryIds[i] && (this.retryIds[i] = 0),
            e.trackingId === this.growingIO.trackingId &&
              this.growingIO.userStore.sessionId === e.sessionId &&
              (this.growingIO.userStore.sessionId = e.sessionId),
            null === (t = this.growingIO.emitter) ||
              void 0 === t ||
              t.emit("onSendAfter", {
                requestData: Object.assign({}, e),
              }),
            this.initiateRequest();
        }),
        (this.requestFailFn = (e, t) => {
          this.requestingNum -= 1;
          const i = e.globalSequenceId || e.esid || -1;
          this.retryIds[i] || (this.retryIds[i] = 0), (this.retryIds[i] += 1);
          const n = this.requestQueue.some(
            (t) =>
              t.globalSequenceId === e.globalSequenceId && t.esid === e.esid
          );
          let r = t;
          if (
            (this.retryIds[i] < this.retryLimit + 1 ||
              ((r = "beacon" === t ? "xhr" : "xhr" === t ? "image" : void 0),
              (this.retryIds[i] = 0)),
            !n && r)
          ) {
            let t = window.setTimeout(() => {
              this.requestQueue.push(
                Object.assign(Object.assign({}, e), {
                  requestType: r,
                })
              ),
                this.initiateRequest(),
                window.clearTimeout(t),
                (t = null);
            }, 800);
          }
          this.initiateRequest();
        }),
        (this.requestQueue = []),
        (this.requestLimit = 10),
        (this.requestTimeout = 5e3),
        (this.retryLimit = 2),
        (this.retryIds = {}),
        (this.requestingNum = 0),
        (this.requestURL = "");
    }
  }
  class oi extends si {
    constructor(e) {
      super(e),
        (this.growingIO = e),
        (this.generateHost = () => {
          let {
            scheme: e,
            host: t = "",
            projectId: i,
          } = this.growingIO.vdsConfig;
          e
            ? q(k(e), "://") || (e += "://")
            : (e =
                (location.protocol.indexOf("http") > -1
                  ? location.protocol.replace(":", "")
                  : "https") + "//"),
            G(t, "http") &&
              (t = t.substring(t.indexOf("://") + (q(k(e), "://") ? 3 : 0))),
            (this.requestURL = `${e}${t}/v3/projects/${i}/collect`);
        }),
        (this.requestURL = ""),
        this.generateHost();
    }
  }
  class ai extends Yt {
    constructor() {
      super(),
        (this.registerPlugins = (e) => {
          _(e)
            ? (e.forEach((t, i) => {
                var n, r;
                F(t) || v(t)
                  ? X("插件不合法，跳过加载!", "warn")
                  : (null === (n = t.js) || void 0 === n
                      ? void 0
                      : n.default) &&
                    (e[i] = Object.assign(
                      Object.assign(
                        {},
                        null === (r = t.js) || void 0 === r ? void 0 : r.default
                      ),
                      {
                        options: t.options,
                      }
                    ));
              }),
              (e = A(e)),
              this.plugins.installAll(e))
            : X("插件注册失败，请检查!", "error");
        }),
        (this.initCallback = () => {
          (this.uploader = new oi(this)), (this.userStore = new Qt(this));
        }),
        (this.getPlugins = () => this.plugins.pluginItems),
        (this.setTrackerScheme = (e) => {
          L(["http", "https"], e)
            ? (this.dataStore.setOption("scheme", e), this.notRecommended())
            : this.callError("scheme", !1);
        }),
        (this.setTrackerHost = (e) => {
          ie.test(e) || ne.test(e)
            ? (this.dataStore.setOption("host", e), this.notRecommended())
            : this.callError("host", !1);
        }),
        (this.setDataCollect = (e) => {
          this.setOption("dataCollect", !!e), this.notRecommended();
        }),
        (this.setAutotrack = (e) => {
          this.setOption("autotrack", !!e), this.notRecommended();
        }),
        (this.enableDebug = (e) => {
          this.setOption("debug", !!e), this.notRecommended();
        }),
        (this.enableHT = (e) => {
          this.setOption("hashtag", !!e), this.notRecommended();
        }),
        (this.getVisitorId = () => this.userStore.uid),
        (this.getDeviceId = () => this.userStore.uid),
        (this.setUserAttributes = (e, t) => {
          var i, n;
          !F(e) && y(e)
            ? null ===
                (n =
                  null === (i = this.plugins) || void 0 === i
                    ? void 0
                    : i.gioCustomTracking) ||
              void 0 === n ||
              n.buildUserAttributesEvent(e, t)
            : this.callError("setUserAttributes");
        }),
        (this.setUserId = (e, t) => {
          if (te(k(e).trim())) {
            const i = this.userStore.gioId;
            this.vdsConfig.enableIdMapping &&
              (this.userStore.userKey =
                !v(t) && k(t).length > 0 ? k(t).slice(0, 1e3) : ""),
              (this.userStore.userId = k(e).slice(0, 1e3)),
              i &&
                i !== this.userStore.userId &&
                (this.userStore.sessionId = "");
          } else this.clearUserId(), this.callError("setUserId");
        }),
        (this.clearUserId = () => {
          (this.userStore.userId = ""), (this.userStore.userKey = "");
        }),
        (this.track = (e, t, i, n) => {
          var r, s;
          (
            (null ===
              (s =
                null === (r = this.plugins) || void 0 === r
                  ? void 0
                  : r.gioCustomTracking) || void 0 === s
              ? void 0
              : s.buildCustomEvent) || function () {}
          )(
            e,
            Object.assign(
              Object.assign({}, this.dataStore.generalProps),
              y(t) && !F(t) ? t : {}
            ),
            i,
            n
          );
        }),
        (this.sendPage = (e) => this.dataStore.currentPage.buildPageEvent(e)),
        (this.sendVisit = (e) => this.dataStore.buildVisitEvent(e)),
        (this.trackTimerStart = (e, t) => {
          this.vdsConfig.dataCollect &&
            Q(e, () => {
              const i = oe();
              E(t)
                ? ((this.dataStore.trackTimers[i] = {
                    eventName: e,
                    leng: 0,
                    start: +Date.now(),
                  }),
                  t(i))
                : X("回调方法不合法，返回timerId失败!");
            });
        }),
        (this.trackTimerPause = (e) => {
          if (e && this.dataStore.trackTimers[e]) {
            const t = this.dataStore.trackTimers[e];
            t.start && (t.leng = t.leng + (+Date.now() - t.start)),
              (t.start = 0);
          }
        }),
        (this.trackTimerResume = (e) => {
          if (e && this.dataStore.trackTimers[e]) {
            const t = this.dataStore.trackTimers[e];
            0 === t.start && (t.start = +Date.now());
          }
        }),
        (this.trackTimerEnd = (e, t) => {
          if (this.vdsConfig.dataCollect) {
            const i = 864e5;
            if (e && this.dataStore.trackTimers[e]) {
              const n = this.dataStore.trackTimers[e];
              if (0 !== n.start) {
                const e = +Date.now() - n.start;
                n.leng = e > 0 ? n.leng + e : 0;
              }
              this.track(
                n.eventName,
                Object.assign(Object.assign({}, t), {
                  event_duration: n.leng > i ? 0 : n.leng / 1e3,
                })
              ),
                this.removeTimer(e);
            } else X("未查找到对应的计时器，请检查!", "error");
          }
        }),
        (this.removeTimer = (e) => {
          e &&
            this.dataStore.trackTimers[e] &&
            delete this.dataStore.trackTimers[e];
        }),
        (this.clearTrackTimer = () => {
          this.dataStore.trackTimers = {};
        }),
        (this.dataStore = new ri(this));
    }
  }
  let di;
  return (
    (function () {
      var e, t, i, n, s;
      let o = window.gioCompatibilityVds ? "gdp_vds" : "vds";
      if (null === (e = window[o]) || void 0 === e ? void 0 : e.gioSDKInstalled)
        return (
          (di = window.gdp),
          void X(
            "SDK重复加载，请检查是否重复加载SDK或接入其他平台SDK导致冲突!",
            "warn"
          )
        );
      window[o] = Object.assign(
        Object.assign({}, null !== (t = window[o]) && void 0 !== t ? t : {}),
        {
          gioSDKInstalled: !0,
        }
      );
      const d = new ai();
      di = function () {
        var e;
        const t = arguments[0];
        if (I(t) && L(r, t) && d[t]) {
          const e = x(R(arguments));
          if ("init" === t) {
            const t = ((e) => {
              var t;
              return e.vdsConfig ||
                e.gioSDKInitialized ||
                (null === (t = window.vds) || void 0 === t
                  ? void 0
                  : t.gioSDKInitialized)
                ? (X(
                    "SDK重复初始化，请检查是否重复加载SDK或接入其他平台SDK导致冲突!",
                    "warn"
                  ),
                  !1)
                : !(
                    L(["", "localhost", "127.0.0.1"], location.hostname) &&
                    !window._gr_ignore_local_rule &&
                    (X("当前SDK不允许在本地环境初始化!", "warn"), 1)
                  );
            })(d);
            if (!t) return;
            const i = ((e) =>
              !F(A(e)) ||
              (X(
                'SDK初始化失败，请使用 gdp("init", "您的GrowingIO项目 accountId", "您项目的 dataSourceId", options); 进行初始化!',
                "error"
              ),
              !1))(e);
            if (!i) return;
            const n = ((e) => {
              const t = N(e);
              let i = C(e);
              return te(k(t).trim())
                ? ((y(i) && i) || (i = {}),
                  {
                    projectId: t,
                    userOptions: i,
                  })
                : (X("SDK初始化失败，accountId 参数不合法!", "error"), !1);
            })(e);
            if (!n) return;
            const r = ((e) => {
              const t = e[1],
                i = e[2],
                n = C(e);
              return t && I(t)
                ? {
                    dataSourceId: t,
                    appId: I(i) ? i : "",
                    cdpOptions: n,
                  }
                : (X("SDK初始化失败，dataSourceId 参数不合法!", "error"), !1);
            })(e);
            if (!r) return;
            const { projectId: s } = n,
              { dataSourceId: o, appId: a, cdpOptions: c } = r;
            d.init(
              Object.assign(Object.assign({}, c), {
                projectId: s,
                dataSourceId: o,
                appId: a,
              })
            );
          } else if ("registerPlugins" === t) d.registerPlugins(e[0]);
          else {
            if (d.gioSDKInitialized && d.vdsConfig) return d[t](...e);
            d.emitter.emit("UNINITIALIZED_CALL", arguments),
              X("SDK未初始化!", "error");
          }
        } else
          L(a, t)
            ? X(`方法 ${k(t)} 已被弃用，请移除!`, "warn")
            : X(`不存在名为 ${k(t)} 的方法调用!`, "error");
        window[o] = Object.assign(Object.assign({}, window[o]), {
          _gr_ignore_local_rule:
            null !== (e = window._gr_ignore_local_rule) && void 0 !== e && e,
          gioEnvironment: "cdp",
          gioSDKVersion: d.sdkVersion,
          gioSDKFull: d.gioSDKFull,
          canIUse: (e) => L(r, e) && d[e],
        });
      };
      const c =
          null ===
            (i = null === window || void 0 === window ? void 0 : window.gdp) ||
          void 0 === i
            ? void 0
            : i.q,
        l =
          null ===
            (n = null === window || void 0 === window ? void 0 : window.gdp) ||
          void 0 === n
            ? void 0
            : n.e,
        h =
          null ===
            (s = null === window || void 0 === window ? void 0 : window.gdp) ||
          void 0 === s
            ? void 0
            : s.ef;
      (window.gdp = di),
        (window.gdp.e = l),
        (window.gdp.ef = h),
        _(c) &&
          !F(c) &&
          c.forEach((e) => {
            di.apply(null, e);
          });
    })(),
    di
  );
});

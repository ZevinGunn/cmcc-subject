!(function () {
  var e = {
      534: function (e) {
        var t = {
          getItem: function (e) {
            try {
              return JSON.parse(localStorage.getItem(e));
            } catch (e) {
              return "";
            }
          },
          clear: function (e) {
            try {
              return localStorage.setItem(e, "");
            } catch (e) {
              return "";
            }
          },
          setItem: function (e, t) {
            try {
              var r = localStorage.getItem(e),
                n = [];
              r && ((n = JSON.parse(r)).length || (n = [n])),
                t.length ? (n = n.concat(t)) : n.push(t),
                localStorage.setItem(e, JSON.stringify(n));
            } catch (e) {}
          },
        };
        e.exports = t;
      },
      900: function (e, t, r) {
        var n = r(452),
          o = !1,
          i = !1,
          s = !1,
          a = !1;
        n.appName &&
          !n.dev &&
          ("hidden" !== document.visibilityState && (a = !0),
          (o = !0),
          (void 0 === n.sendError || n.sendError) && (i = !0),
          void 0 !== n.rate &&
            (o =
              0 !== n.rate &&
              (100 === n.rate || (100 * Math.random()) >> 1 <= n.rate)),
          n.checkNet && (s = !0)),
          (e.exports = {
            needSendPerformance: o,
            needSendError: i,
            needSendRes: function () {
              return n.uploadResTime;
            },
            needSendAPI: function () {
              return n.uploadAPITime;
            },
            needCheckPaint: function () {
              return void 0 === n._needCheckPaint || n._needCheckPaint;
            },
            needCheckNet: s,
            startVisible: a,
          });
      },
      501: function (e, t, r) {
        var n,
          o = r(900),
          i = r(541),
          s = r(28),
          a = r(502).sendBeaconWithInfo,
          u = r(564),
          p = {},
          c = [],
          l = !1;
        function d() {
          var e = c.pop();
          if (e) {
            l = !0;
            var t = new u.XHR();
            t.open("GET", e),
              (t.onerror = function () {
                a(
                  "netReason",
                  "resource",
                  "type: 0; code: " + t.status + "-error; url: " + e
                ),
                  (l = !1),
                  d();
              }),
              (t.ontimeout = function () {
                a(
                  "netReason",
                  "resource",
                  "type: 0; code: " + t.status + "-timeout; url: " + e
                ),
                  (l = !1),
                  d();
              }),
              (t.onload = function () {
                a(
                  "netReason",
                  "resource",
                  "type: 1; code: " + t.status + "; url: " + e
                ),
                  (l = !1),
                  d();
              }),
              t.send();
          } else l = !1;
        }
        function f() {
          if (i.isonload())
            if (l) s.once(f);
            else {
              var e = p;
              (p = {}),
                (c = []),
                Object.keys(e).forEach(function (t) {
                  e[t] && e[t].length && c.push(e[t].pop());
                }),
                d();
            }
          else i.setLoadCallback(f);
        }
        e.exports = {
          add: function (e) {
            var t = e.split("//").pop().split("/")[0];
            p[t] || (p[t] = []),
              p[t].push(e),
              o.needCheckNet && (clearTimeout(n), (n = setTimeout(f, 1e3)));
          },
        };
      },
      452: function (e) {
        var t = {};
        -1 !== navigator.userAgent.indexOf(" sample/true")
          ? window.__SKYNET_APP && (t = window.__SKYNET_APP)
          : (t = window.__SKYNET || {}),
          (e.exports = t);
      },
      79: function (e, t, r) {
        var n = r(452),
          o = (r(564), r(28)),
          i = r(758),
          s = r(447),
          a = r(502).sendBeaconWithInfo,
          u = r(900),
          p = r(541),
          c =
            performance.timing.redirectStart ||
            performance.timing.navigationStart ||
            performance.timing.fetchStart,
          l = document.documentElement.clientHeight;
        n = n || {};
        var d,
          f,
          m,
          h = document.documentElement,
          g = 0,
          w = 0,
          v = 0,
          x = {},
          y = 0,
          b = 0,
          _ = 0,
          S = {},
          O = 0,
          E = 0,
          T = null,
          M = { type: "", time: 0, message: "" },
          P = { node: null, time: 0 },
          k = !1,
          R = null;
        function N() {
          try {
            return Math.round(
              (performance.getEntriesByName("first-paint")[0] || {})
                .startTime || 0
            );
          } catch (e) {
            return new Date() - c;
          }
        }
        function L() {
          try {
            return Math.round(
              (performance.getEntriesByName("first-contentful-paint")[0] || {})
                .startTime || 0
            );
          } catch (e) {
            return 0;
          }
        }
        if (!n.init && u.needSendPerformance) {
          var B = function (e) {
              f || (f = { time: Date.now() });
              var t = 0,
                r = e[0],
                n = r.nodeName.toLowerCase();
              if (
                ("script" !== n &&
                  "style" !== n &&
                  "link" !== n &&
                  "#text" !== n &&
                  1 == ++g &&
                  setTimeout(function () {
                    E = Date.now() - c;
                  }, 0),
                _ < 2 &&
                  "script" !== n &&
                  "style" !== n &&
                  "link" !== n &&
                  "#text" !== n &&
                  r.getBoundingClientRect)
              ) {
                var o = Date.now();
                (site = r.getBoundingClientRect()),
                  (t = site.y || site.top),
                  site.height &&
                    site.height < l &&
                    t + site.height + 20 >= l &&
                    (++_ > 1 && !b && (b = o - c),
                    (T = r),
                    (S = { time: b, node: r }),
                    I());
              }
              e.length &&
                (clearTimeout(m),
                (P.time = Date.now() - c),
                (P.node = e[0]),
                (m = setTimeout(function () {
                  (S = P), O || (O = P.time), I(O);
                }, 300)));
            },
            V = function (e) {
              v++,
                (x[e.url] = {}),
                (x[e.url].timer = setTimeout(function () {
                  (x[e.url].timeout = !0), v--, I();
                }, 1e3 * s.maxXHR));
            },
            I = function (e) {
              w ||
                (function (e) {
                  if (0 !== O && 0 === w) {
                    var t = N() || E,
                      r = L(),
                      i = 0;
                    (O || b) &&
                      v <= 1 &&
                      document.body.innerText.length > 0 &&
                      ((i = Math.max(y || O, b, r) >> 0),
                      clearTimeout(R),
                      (R = setTimeout(function () {
                        (t = N() || E),
                          (i = Math.max(t, y || O, r, b) >> 0),
                          (w = e - c),
                          o.off("__networkBack"),
                          o.off("__networkSend", V),
                          (w = Math.max(e - c, i)),
                          i === y
                            ? ((M.type = "lcp"), (M.time = i))
                            : i === O
                            ? ((M.type = S.type || "lcpfix"),
                              (M.time = i),
                              (M.message = S.node
                                ? (S.node.outerHTML || "").slice(0, 100)
                                : ""))
                            : ((M.type = "bottom"),
                              (M.time = i),
                              (M.message = T
                                ? (T.outerHTML || "").slice(0, 100)
                                : "")),
                          (A = { fp: t, fsp: i, tti: w }),
                          n.USERSENDPROFILE
                            ? H &&
                              (k ||
                                ((k = !0),
                                o.fire("profilekeys", {
                                  fp: t,
                                  fsp: i,
                                  tti: w,
                                  p1: H.p1 || 0,
                                  p2: H.p2 || 0,
                                })))
                            : k ||
                              ((k = !0),
                              o.fire("profilekeys", {
                                fp: t,
                                fsp: i,
                                tti: w,
                                p1: 0,
                                p2: 0,
                              })),
                          i >= 1e4 && a("keypoints", "slow", JSON.stringify(M)),
                          d.disconnect && d.disconnect();
                      }, 1e3)));
                  }
                })(e || Date.now());
            },
            D = function () {
              return !!(
                document.body.innerText.length < 30 &&
                "hidden" !== document.visibilityState &&
                u.needCheckPaint()
              );
            };
          try {
            (d = new MutationObserver(function (e) {
              for (var t, r = 0, n = e.length; r < n; r++)
                (t = e[r]).addedNodes.length && B(t.addedNodes);
            })).observe(h, { childList: !0, attributes: !1, subtree: !0 });
          } catch (e) {
            console.error(e), (window.errors += e.message);
          }
          try {
            u.needSendPerformance &&
              new PerformanceObserver(function (e) {
                var t = e.getEntries(),
                  r = t[t.length - 1];
                (y = Math.round(r.renderTime || r.loadTime)), I();
              }).observe({ type: "largest-contentful-paint", buffered: !0 });
          } catch (e) {}
          var H = null,
            A = null;
          n.USERSENDPROFILE &&
            o.on("userProfile", function (e) {
              (H = e),
                A &&
                  (k ||
                    ((k = !0),
                    o.fire("profilekeys", {
                      fp: A.fp,
                      fsp: A.fsp,
                      tti: A.tti,
                      p1: H.p1 || 0,
                      p2: H.p2 || 0,
                    })));
            }),
            u.needSendPerformance &&
              (o.on("__networkSend", V),
              o.on("__networkBack", function (e) {
                x[e.url].timeout || (v--, clearTimeout(x[e.url].timer), I());
              }),
              u.needSendError &&
                (o.on("longRequest", function (e) {
                  a("xhr", "slow", JSON.stringify(e));
                }),
                o.on("longRun", function (e) {
                  a("jsRun", "slow", JSON.stringify(e));
                }),
                o.on("error", function (e) {
                  ("ajaxError" !== e.name && "fetchError" !== e.name) ||
                  !n.ajaxErrorFilter
                    ? a(e.name, e.type, e.msg)
                    : n.ajaxErrorFilter(e.url) || a(e.name, e.type, e.msg);
                })));
          var C = !1;
          u.needSendPerformance &&
            (setTimeout(function () {
              D() &&
                !C &&
                ((C = !0),
                a(
                  "whiteScreen",
                  "paintError",
                  g +
                    " - " +
                    document.body.innerText +
                    " - " +
                    (Date.now() - c) +
                    " - visible:" +
                    document.visibilityState +
                    " - " +
                    p.getInfo()
                )),
                n.USERSENDPROFILE ||
                  k ||
                  ((k = !0), o.fire("profilekeys", X()));
            }, 1e4),
            o.bindBrowserEvent(window, "beforeunload", function () {
              !C &&
                D() &&
                Date.now() - c > 5e3 &&
                !n.DONTSENDPAINTERROR &&
                ((C = !0),
                a(
                  "whiteScreen",
                  "paintError",
                  "unload - " +
                    g +
                    " - " +
                    document.body.innerText +
                    " - " +
                    (Date.now() - c) +
                    " - " +
                    p.getInfo()
                )),
                k ||
                  a(
                    "upload",
                    "profile",
                    "unload - " + (Date.now() - c) + " - " + p.getInfo()
                  );
            }));
        }
        function X() {
          var e = N() >> 0 || E;
          i.init();
          var t = Math.max(e, y || O, b, L()) >> 0;
          return { fp: e, fsp: t, tti: (w = Math.max(w, t) >> 0) };
        }
        e.exports = X;
      },
      28: function (e) {
        var t = {};
        e.exports = {
          bindBrowserEvent: function (e, t, r, n) {
            var o = !1;
            void 0 !== n && (o = n),
              e.addEventListener
                ? e.addEventListener(t, r, o)
                : e.attachEvent && e.attachEvent("on" + t, r);
          },
          off: function (e, r) {
            var n = t[e];
            if (n && n.length)
              if (r) {
                for (var o = 0, i = n.length; o < i; o++)
                  if (n[o] === r) {
                    n.splice(o, 1);
                    break;
                  }
              } else t[e] = [];
          },
          on: function (e, r) {
            t[e] || (t[e] = []), t[e].push(r);
          },
          fire: function (e, r) {
            var n = t[e];
            if (n && n.length)
              for (var o = 0, i = n.length; o < i && !1 !== n[o](r); o++);
          },
          once: function (e, r) {
            t[e] = [r];
          },
          onceFire: function (e, r) {
            t[e] && (t[e](r), (t[e] = null));
          },
        };
      },
      327: function (e, t, r) {
        var n = "1" === r(242)().debug;
        e.exports = n;
      },
      564: function (e, t, r) {
        function n(e) {
          return (
            (n =
              "function" == typeof Symbol && "symbol" == typeof Symbol.iterator
                ? function (e) {
                    return typeof e;
                  }
                : function (e) {
                    return e &&
                      "function" == typeof Symbol &&
                      e.constructor === Symbol &&
                      e !== Symbol.prototype
                      ? "symbol"
                      : typeof e;
                  }),
            n(e)
          );
        }
        var o = r(452),
          i = r(28),
          s = r(447),
          a = r(900),
          u = r(541),
          p = 1e3 * s.maxXHR,
          c = 1e3 * s.maxJsRun,
          l = window.XMLHttpRequest,
          d = 0;
        function f(e) {
          try {
            return (
              -1 === e.indexOf("cmos/profile") &&
              -1 === e.indexOf("tracker") &&
              -1 === e.indexOf("/pf") &&
              -1 === e.indexOf("/printLog")
            );
          } catch (e) {
            return !0;
          }
        }
        if (!(o = o || {}).init && a.needSendPerformance) {
          try {
            if (window.fetch) {
              var m = window.fetch;
              window.fetch = function (e, t) {
                return new Promise(function (r, s) {
                  var a,
                    c = Date.now(),
                    l = 0;
                  (a = t ? m(e, t) : m(e)),
                    u.addAPI(),
                    a
                      .then(function (t) {
                        var s = "object" === n(e) ? e.url : e;
                        if ((u.addAPIDONE(), (l = Date.now() - c), t.ok))
                          i.fire("apiTime", {
                            time: l,
                            url: s,
                            netType: t.status,
                          }),
                            l > p && i.fire("longRequest", { time: l, url: s });
                        else if (f(s))
                          if (o.xhrStatusFilter)
                            try {
                              -1 === o.xhrStatusFilter.indexOf(t.status) &&
                                i.fire("error", {
                                  name: "fetchError",
                                  type: "network",
                                  msg: s + " status " + t.status,
                                  url: s,
                                });
                            } catch (e) {}
                          else
                            i.fire("apiTime", {
                              time: l,
                              url: s,
                              netType: t.status,
                            }),
                              i.fire("error", {
                                name: "fetchError",
                                type: "network",
                                msg: s + " status " + t.status,
                                url: s,
                              });
                        r(t);
                      })
                      .catch(function (t) {
                        var r = "object" === n(e) ? e.url : e;
                        f(r) &&
                          i.fire("error", {
                            name: "fetchError",
                            type: "network",
                            msg:
                              r +
                              " " +
                              (t.type || t.name) +
                              " " +
                              (t.message || "").substring(100) +
                              " status -1",
                            url: r,
                          }),
                          s(t);
                      });
                });
              };
            }
          } catch (e) {
            i.fire("JsError", {
              name: "jsRun",
              type: "fetchRun",
              msg: e.message,
            });
          }
          (window.XMLHttpRequest = function () {
            (this._id = d++),
              (this._start = 0),
              (this._xhr = new l()),
              (this.readyState = 0),
              (this.status = 0),
              (this.onreadystatechange = null),
              (this.responseText = ""),
              (this.responseURL = ""),
              (this.responseXML = null),
              (this.response = ""),
              (this.responseType = "");
            var e = 0;
            (this.aborted = !1),
              (this.upload = this._xhr.upload),
              (this.withCredentials = this._xhr.withCredentials);
            var t = this,
              r = "",
              n = !1;
            Object.defineProperty(this, "withCredentials", {
              set: function (e) {
                t._xhr.withCredentials = n = e;
              },
              get: function () {
                return n;
              },
            }),
              Object.defineProperty(this, "timeout", {
                set: function (r) {
                  (e = r), (t._xhr.timeout = r);
                },
                get: function () {
                  return e;
                },
              }),
              Object.defineProperty(this, "responseType", {
                set: function (e) {
                  (r = e), (t._xhr.responseType = e);
                },
                get: function () {
                  return r;
                },
              });
          }),
            (XMLHttpRequest.prototype.open = function (e, t, r) {
              void 0 === r && (r = !0),
                (this._url = t),
                (this._type = r),
                (this._method = e),
                (this._start = Date.now()),
                this._xhr.open(e, t, r);
            }),
            (XMLHttpRequest.prototype.send = function (e) {
              var t = this;
              f(t._url) &&
                (i.fire("__networkSend", { url: t._url }), u.addAPI()),
                Object.defineProperty ||
                  "" === this.responseType ||
                  (this._xhr.responseType = this.responseType),
                (this._xhr.onreadystatechange = function (e) {
                  if (4 === t._xhr.readyState) {
                    var r = Date.now() - t._start;
                    if (
                      (t._xhr.status >= 200 && t._xhr.status < 300) ||
                      304 === t._xhr.status
                    ) {
                      if (
                        (u.addAPIDONE(),
                        i.fire("apiTime", {
                          time: r,
                          url: t._url,
                          netType: t._xhr.status,
                        }),
                        r > p &&
                          i.fire("longRequest", { time: r, url: t._url }),
                        (t.responseURL = t._xhr.responseURL),
                        ("" !== this.responseType &&
                          "text" !== this.responseType) ||
                          (t.responseText = t._xhr.responseText),
                        ("" !== this.responseType &&
                          "" !== this.responseType) ||
                          (t.responseXML = t._xhr.responseXML),
                        (t.response = t._xhr.response),
                        "json" === t.responseType &&
                          "string" == typeof t.response)
                      )
                        try {
                          t.response = JSON.parse(t.response);
                        } catch (e) {}
                      t._type && (t._start = Date.now()),
                        setTimeout(function () {
                          var e = Date.now() - t._start - 10;
                          f(t._url) &&
                            i.fire("__networkBack", {
                              url: t._url,
                              useTime: e,
                            }),
                            e > c &&
                              i.fire("longRun", { time: e, url: t._url });
                        }, 10);
                    } else {
                      if (0 !== t._xhr.status && f(t._url))
                        if (o.xhrStatusFilter)
                          try {
                            -1 === o.xhrStatusFilter.indexOf(t._xhr.status) &&
                              i.fire("error", {
                                name: "ajaxError",
                                type: "network",
                                msg: t._url + " status " + t._xhr.status,
                                url: t._url,
                              });
                          } catch (e) {}
                        else
                          i.fire("apiTime", {
                            time: r,
                            url: t._url,
                            netType: t._xhr.status,
                          }),
                            i.fire("error", {
                              name: "ajaxError",
                              type: "network",
                              msg: t._url + " status " + t._xhr.status,
                              url: t._url,
                            });
                      i.fire("__networkBack", {
                        url: t._url,
                        useTime: r,
                        type: "error",
                      });
                    }
                  }
                  (t.readyState = t._xhr.readyState),
                    (t.status = t._xhr.status),
                    t.onreadystatechange && t.onreadystatechange(e);
                }),
                (this._xhr.onload = function (e) {
                  t.onload && t.onload(e);
                }),
                (this._xhr.ontimeout = function (e) {
                  var r = Date.now() - t._start;
                  if (f(t._url))
                    if (o.xhrStatusFilter)
                      try {
                        -1 === o.xhrStatusFilter.indexOf(t._xhr.status) &&
                          i.fire("error", {
                            name: "ajaxError",
                            type: "network",
                            msg:
                              t._url + " status " + t._xhr.status + "-timeout",
                            url: t._url,
                          });
                      } catch (e) {}
                    else
                      i.fire("apiTime", {
                        time: r,
                        url: t._url,
                        netType: t._xhr.status,
                      }),
                        i.fire("error", {
                          name: "ajaxError",
                          type: "network",
                          msg: t._url + " status " + t._xhr.status + "-timeout",
                          url: t._url,
                        });
                  t.ontimeout && t.ontimeout(e);
                }),
                (this._xhr.onabort = function (e) {
                  var r = Date.now() - t._start;
                  if (f(t._url))
                    if (o.xhrStatusFilter)
                      try {
                        -1 === o.xhrStatusFilter.indexOf(t._xhr.status) &&
                          i.fire("error", {
                            name: "ajaxError",
                            type: "network",
                            msg: t._url + " status " + t._xhr.status + "-abort",
                            url: t._url,
                          });
                      } catch (e) {}
                    else
                      i.fire("apiTime", {
                        time: r,
                        url: t._url,
                        netType: t._xhr.status,
                      }),
                        i.fire("error", {
                          name: "ajaxError",
                          type: "network",
                          msg: t._url + " status " + t._xhr.status + "-abort",
                          url: t._url,
                        });
                  t.onabrot && t.onabort(e);
                }),
                (this._xhr.onerror = function (e) {
                  var r = Date.now() - t._start;
                  if (f(t._url))
                    if (o.xhrStatusFilter)
                      try {
                        -1 === o.xhrStatusFilter.indexOf(t._xhr.status) &&
                          i.fire("error", {
                            name: "ajaxError",
                            type: "network",
                            msg: t._url + " status " + t._xhr.status + "-error",
                            url: t._url,
                          });
                      } catch (e) {}
                    else
                      i.fire("apiTime", {
                        time: r,
                        url: t._url,
                        netType: t._xhr.status,
                      }),
                        i.fire("error", {
                          name: "ajaxError",
                          type: "network",
                          msg: t._url + " status " + t._xhr.status + "-error",
                          url: t._url,
                        });
                  t.onerror && t.onerror(e);
                }),
                (this._xhr.onloadend = function (e) {
                  t.onloadend && t.onloadend(e);
                }),
                (this._xhr.onloadstart = function (e) {
                  t.onloadstart && t.onloadstart(e);
                }),
                (this._xhr.onprogress = function (e) {
                  t.onprogress && t.onprogress(e);
                }),
                this._xhr.send(e);
            }),
            (XMLHttpRequest.prototype.setRequestHeader = function (e, t) {
              this._xhr.setRequestHeader(e, t);
            }),
            (XMLHttpRequest.prototype.getResponseHeader = function (e) {
              return this._xhr.getResponseHeader(e);
            }),
            (XMLHttpRequest.prototype.getAllResponseHeaders = function () {
              return this._xhr.getAllResponseHeaders();
            }),
            (XMLHttpRequest.prototype.abort = function () {
              return (this.aborted = !0), this._xhr.abort();
            }),
            (XMLHttpRequest.prototype.addEventListener = function (e, t, r) {
              return this._xhr.addEventListener(e, t, r);
            }),
            (XMLHttpRequest.prototype.removeEventListener = function (e, t, r) {
              return this._xhr.removeEventListener(e, t, r);
            }),
            (XMLHttpRequest.prototype.overrideMimeType = function (e) {
              this._xhr.overrideMimeType(e);
            }),
            (XMLHttpRequest.prototype.__zone_symbol__addEventListener =
              XMLHttpRequest.prototype.addEventListener),
            (XMLHttpRequest.prototype.__zone_symbol__removeEventListener =
              XMLHttpRequest.prototype.removeEventListener);
        }
        e.exports = {
          XHR: l,
          getMaxTime: function () {
            return {};
          },
        };
      },
      502: function (e, t, r) {
        function n(e, t, r) {
          return (
            t in e
              ? Object.defineProperty(e, t, {
                  value: r,
                  enumerable: !0,
                  configurable: !0,
                  writable: !0,
                })
              : (e[t] = r),
            e
          );
        }
        var o,
          i,
          s = r(452),
          a = r(564),
          u = (s || {}).api || "https://mtm.online-cmcc.cn/cmos/profile",
          p = r(883),
          c = r(922),
          l = r(900),
          d = r(327),
          f = r(28),
          m = r(910),
          h = p(),
          g = [],
          w = [],
          v = [],
          x = 0,
          y = [],
          b = "hidden" !== document.visibilityState,
          _ = !1;
        function S(e) {
          y.length < 50 && y.push(e);
        }
        function O() {
          var e = y.shift();
          e && T.post(e, O);
        }
        l.startVisible ||
          document.addEventListener("visibilitychange", function () {
            "hidden" !== document.visibilityState &&
              ((b = !0), _ || ((_ = !0), O()));
          }),
          f.bindBrowserEvent(window, "beforeunload", function () {
            l.needSendPerformance &&
              (w.length &&
                navigator.sendBeacon &&
                (navigator.sendBeacon(u, JSON.stringify(w)), (w.length = 0)),
              g.length &&
                navigator.sendBeacon &&
                (navigator.sendBeacon(u, JSON.stringify(g)), (g.length = 0)),
              v.length &&
                navigator.sendBeacon &&
                (navigator.sendBeacon(u, JSON.stringify(v)), (v.length = 0)));
          });
        var E = null,
          T = {
            post: function (e, t) {
              if (l.needSendPerformance && 0 !== e.length && !(x >= 3))
                if (l.startVisible || b) {
                  var r = JSON.stringify(e),
                    n = new (0, a.XHR)();
                  (n.timeout = 3e3),
                    n.open("POST", u),
                    n.send(r),
                    (n.onreadystatechange = function () {
                      4 === n.readyState &&
                        ((n.status >= 200 && n.status < 300) ||
                          304 === n.status ||
                          x++,
                        t && t());
                    });
                  try {
                    var o = window.leadeon || window.cmcc || {};
                    o.webViewLog &&
                      h.clientVersion.substring(0, 5).replace(/\./g, "") >=
                        925 &&
                      d &&
                      o.webViewLog({ debug: !1, logList: [r] });
                  } catch (e) {}
                } else S(e);
            },
            sendBeacon: function (e) {
              l.needSendPerformance &&
                (x >= 3 ||
                  (0 !== e.length &&
                    (l.startVisible || b
                      ? navigator.sendBeacon &&
                        (navigator.sendBeacon(u, JSON.stringify(e)) || x++)
                      : S(e))));
            },
            sendBeaconWithInfoAll: function (e, t, r) {
              if (l.needSendPerformance)
                if (navigator.sendBeacon)
                  T.sendBeacon({
                    event: f || "error",
                    sys: h.appName,
                    sysV: h.appVersion,
                    clientV: h.clientVersion,
                    pageName: h.page(),
                    os: h.os,
                    osV: h.OSVersion,
                    browser: h.browser,
                    browserV: h.browserVersion,
                    product: h.product,
                    time: Date.now(),
                    errorName: e,
                    errorType: t,
                    errorLog: r,
                    province: m(),
                    uuid: c.getUUID(),
                  });
                else
                  try {
                    T.sendWithInfo(e, t, r, "error", "all");
                  } catch (e) {}
            },
            sendALLInfo: function (e, t, r, n) {
              l.needSendPerformance &&
                l.needSendAPI() &&
                (clearTimeout(E),
                v.push({
                  event: n || "error",
                  sys: h.appName,
                  sysV: h.appVersion,
                  clientV: h.clientVersion,
                  pageName: h.page(),
                  os: h.os,
                  osV: h.OSVersion,
                  browser: h.browser,
                  browserV: h.browserVersion,
                  product: h.product,
                  time: Date.now(),
                  errorName: e,
                  errorType: t,
                  province: m(),
                  errorLog: r,
                  uuid: c.getUUID(),
                }),
                (E = setTimeout(function () {
                  T.sendBeacon(v), (v.length = 0);
                }, 2e3)));
            },
            sendBeaconWithInfo: function (e, t, r, o) {
              var i;
              if (l.needSendPerformance)
                if (navigator.sendBeacon)
                  T.sendBeacon(
                    (n(
                      (i = {
                        event: o || "error",
                        sys: h.appName,
                        sysV: h.appVersion,
                        clientV: h.clientVersion,
                        pageName: h.page(),
                        os: h.os,
                        osV: h.OSVersion,
                        browser: h.browser,
                        browserV: h.browserVersion,
                        product: h.product,
                        time: Date.now(),
                        province: m(),
                        errorName: e,
                        errorType: t,
                      }),
                      "province",
                      m()
                    ),
                    n(i, "errorLog", r),
                    n(i, "uuid", c.getUUID()),
                    i)
                  );
                else
                  try {
                    T.sendWithInfo(e, t, r, o);
                  } catch (e) {}
            },
            send: function (e, t) {
              l.needSendPerformance &&
                (l.startVisible || b
                  ? t
                    ? navigator.sendBeacon
                      ? T.sendBeacon(e)
                      : T.post(e)
                    : (clearTimeout(i),
                      e.length ? (w = w.concat(e)) : w.push(e),
                      (i = setTimeout(function () {
                        w.length &&
                          (navigator.sendBeacon ? T.sendBeacon(w) : T.post(w),
                          (w.length = 0)),
                          clearTimeout(i);
                      }, 1e3)))
                  : S(e));
            },
            sendWithInfo: function (e, t, r, n, i) {
              (i || l.needSendPerformance) &&
                (clearTimeout(o),
                g.push({
                  event: n || "error",
                  sys: h.appName,
                  sysV: h.appVersion,
                  clientV: h.clientVersion,
                  pageName: h.page(),
                  os: h.os,
                  osV: h.OSVersion,
                  browser: h.browser,
                  browserV: h.browserVersion,
                  product: h.product,
                  time: Date.now(),
                  errorName: e,
                  province: m(),
                  errorType: t,
                  errorLog: r,
                  uuid: c.getUUID(),
                }),
                (o = setTimeout(function () {
                  g.length && (T.post(g), (g.length = 0));
                }, 1e3)));
            },
          };
        f.on("apiTime", function (e) {
          T.sendALLInfo(
            "api",
            "network",
            { time: e.time, url: e.url, netType: e.netType },
            "netTime"
          );
        }),
          (e.exports = T);
      },
      817: function (e) {
        var t = { browser: "", bv: "", os: "", ov: "", product: "" },
          r = { MicroMessenger: "WeChat" };
        e.exports = function (e) {
          try {
            var n;
            return e.match(/\([^\)]*\)/g)
              ? (function (e) {
                  var t,
                    n,
                    o = e.match(/\([^\)]*\)/g),
                    i = o[0];
                  i = i.split(" ");
                  var s,
                    a,
                    u,
                    p,
                    c = [];
                  if (-1 !== e.indexOf("iPhone")) {
                    (n = e.split(o[1])[1]),
                      (t = e.split(o[1])[1].split(/\s+/g)),
                      -1 !== e.indexOf("wkwebview")
                        ? (c = ["wkwebview", ""])
                        : -1 !== e.indexOf("MicroMessenger")
                        ? (c = t[2].split("(")[0].split("/"))
                        : -1 !== e.indexOf("AlipayClient")
                        ? (c = [
                            "AlipayClient",
                            n.split("AlipayClient/")[1].split(" ")[0],
                          ])
                        : -1 !== e.indexOf("shydhn") ||
                          -1 !== e.indexOf("GDMobile") ||
                          -1 !== e.indexOf("ynmobileapp_ios") ||
                          -1 !== e.indexOf("sjyyt") ||
                          -1 !== e.indexOf("ImgoTV")
                        ? 1 === (c = t[t.length - 1].split("/")).length &&
                          (c = t[t.length - 2].split("/"))
                        : (c =
                            -1 !== e.indexOf("anhuiAPP")
                              ? [
                                  t[2].split("=")[1],
                                  t[t.length - 2].split("=")[1],
                                ]
                              : -1 !== e.indexOf("10086APP")
                              ? ["10086APP", ""]
                              : -1 !== e.indexOf("woxin_IOS")
                              ? ["woxin", ""]
                              : -1 !== e.indexOf("UCBrowser") ||
                                -1 !== e.indexOf("QQTheme") ||
                                -1 !== e.indexOf("toon")
                              ? t[2].split("/")
                              : -1 !== e.indexOf("Quark")
                              ? ["Quark", e.split("Quark/")[1].split(" ")[0]]
                              : -1 !== e.indexOf("SogouMobileBrowser")
                              ? t[t.length - 1].split("/")
                              : -1 !== e.indexOf("CqmcClient")
                              ? ["CqmcClient", ""]
                              : -1 !== e.indexOf("ysapp_ios")
                              ? ["ysapp", ""]
                              : -1 !== e.indexOf("GxMobileEhallAppMessenger")
                              ? [
                                  "GxMobileEhallAppMessenger",
                                  t[t.length - 1].split("@")[1],
                                ]
                              : -1 !== e.indexOf("Youku")
                              ? ["Youku", t[4].split("/")[1].split("(")[0]]
                              : -1 !== e.indexOf("gmcchh")
                              ? [
                                  "gmcchh",
                                  t[t.length - 2].split("/")[1] ||
                                    t[t.length - 1].split("/")[1],
                                ]
                              : -1 !== e.indexOf("weibo")
                              ? ["weibo", t[t.length - 1].split("__")[2]]
                              : -1 !== e.indexOf("baiduboxapp")
                              ? t[4].split("/")
                              : -1 !== e.indexOf("jsmcc")
                              ? t[t.length - 2].split("/")
                              : -1 !== e.indexOf("scmcc")
                              ? ["scmcc", t[1].split("/")[2]]
                              : -1 !== e.indexOf("iHeYueSX")
                              ? ["iHeYueSX", t[2].split(";")[3]]
                              : -1 !== e.indexOf("Migu")
                              ? [
                                  "Migu",
                                  t[2].split("(")[0].split("/")[2] ||
                                    t[3].split("V")[1],
                                ]
                              : t.length < 3
                              ? (n = e.split(") ")[1].split(" ")[0].split("/"))
                              : e.split(") ")[1].split(" ")[0].split("/")),
                      c[1] || (c = e.split(") ")[1].split(" ")[0].split("/"));
                    for (
                      var l = 0, d = i.length;
                      l < d &&
                      ((u = i[l].replace(/\_/g, ".")), /[a-zA-Z]/.test(u));
                      l++
                    );
                    s = {
                      browser: r[c[0]] || c[0],
                      bv: c[1].split("(")[0],
                      os: "iOS",
                      ov: u,
                      product: i[0].replace("(", "").replace(";", ""),
                    };
                  } else
                    (c =
                      -1 !== e.indexOf("MicroMessenger")
                        ? [
                            "MicroMessenger",
                            e
                              .split("MicroMessenger/")[1]
                              .split("(")[0]
                              .split(" ")[0],
                          ]
                        : -1 !== e.indexOf("MQQBrowser")
                        ? [
                            "MQQBrowser",
                            e.split("MQQBrowser/")[1].split(" ")[0],
                          ]
                        : -1 !== e.indexOf("AlipayClient")
                        ? [
                            "AlipayClient",
                            e.split("AlipayClient/")[1].split(" ")[0],
                          ]
                        : -1 !== e.indexOf("10086APP")
                        ? ["10086APP", ""]
                        : -1 !== e.indexOf("HuaweiBrowser")
                        ? [
                            "HuaweiBrowser",
                            e.split("HuaweiBrowser/")[1].split(" ")[0],
                          ]
                        : -1 !== e.indexOf("UCBrowser")
                        ? ["UCBrowser", e.split("UCBrowser/")[1].split(" ")[0]]
                        : -1 !== e.indexOf("Quark")
                        ? ["Quark", e.split("Quark/")[1].split(" ")[0]]
                        : -1 !== e.indexOf("GDMobile")
                        ? ["GDMobile", e.split("GDMobile/")[1].split(" ")[0]]
                        : -1 !== e.indexOf("MiuiBrowser")
                        ? [
                            "MiuiBrowser",
                            e.split("MiuiBrowser/")[1].split(" ")[0],
                          ]
                        : -1 !== e.indexOf("Youku")
                        ? ["Youku", e.split("Youku/")[1].split(" ")[0]]
                        : -1 !== e.indexOf("Firefox")
                        ? [
                            "Firefox",
                            e.split("Firefox/")[1].split(" ")[0].split("_")[0],
                          ]
                        : -1 !== e.indexOf("HeyTapBrowser")
                        ? [
                            "HeyTapBrowser",
                            e.split("HeyTapBrowser/")[1].split(" ")[0],
                          ]
                        : -1 !== e.indexOf("NokiaBrowser")
                        ? [
                            "NokiaBrowser",
                            e.split("NokiaBrowser/")[1].split(" ")[0],
                          ]
                        : -1 !== e.indexOf("Chrome")
                        ? ["Chrome", e.split("Chrome/")[1].split(" ")[0]]
                        : e.split(") ")[1].split(" ")[0].split("/")),
                      -1 !== e.indexOf("Flyme")
                        ? ((a = e.split("Meizu-")[1].split("/")[0]),
                          (s = {
                            browser: "AppleWebKit",
                            bv: e
                              .split("AppleWebKit")[1]
                              .split("(")[0]
                              .split(" ")[0],
                            os: "Flyme",
                            ov: e.split("Flyme")[1],
                            product: a,
                          }))
                        : -1 !== i[0].indexOf("inux")
                        ? ("ZTE" ===
                            (a =
                              i.length < 4
                                ? ""
                                : "HUAWEI" !== (i[3] || "").replace(";", "")
                                ? i[3].replace(";", "")
                                : (i[4] || "").replace(";", "")) ||
                          "HarmonyOS" === a
                            ? (a = i[4])
                            : "Redmi" === a ||
                              "Le" === a ||
                              "HM" === a ||
                              "OPPO" === a ||
                              "vivo" === a
                            ? (a = i[3] + " " + i[4])
                            : -1 !== e.indexOf("GIONEE") &&
                              ((a =
                                -1 === e.indexOf("GIONEE-")
                                  ? i[3] +
                                    " " +
                                    (-1 !== i[4].indexOf("/") ? "" : i[4])
                                  : e.split("GIONEE-")[1].split("/")[0]),
                              (c = [
                                "AppleWebKit",
                                e
                                  .split("AppleWebKit")[1]
                                  .split("(")[0]
                                  .split(" ")[0]
                                  .replace("/", ""),
                              ])),
                          (p = i[1]),
                          (u = (i[2] || "").replace(")", "")),
                          -1 !== e.indexOf("HarmonyOS")
                            ? ((p = "HarmonyOS"), (u = ""))
                            : "U;" === p &&
                              ((p = i[2]), (u = (i[3] || "").replace(";", ""))),
                          a === u &&
                            (("Redmi" !== (a = i[5]) &&
                              "Le" !== a &&
                              "HM" !== a &&
                              "OPPO" !== a &&
                              "vivo" !== a) ||
                              (a = i[5] + " " + i[6])),
                          "8848" === a && (a = i[5] + " " + i[6]),
                          /[^\d]/.test(a) || (a = ""),
                          a && (a = a.replace(")", "")),
                          u && (u = u.replace(")", "")),
                          a &&
                            -1 !== a.indexOf("Build/") &&
                            (a = -1 !== a.indexOf("-") ? a.split("/")[1] : ""),
                          (s = {
                            browser: r[c[0]] || c[0],
                            bv: c[1],
                            os: p,
                            ov: u,
                            product: a,
                          }))
                        : -1 !== i[0].indexOf("iPad")
                        ? ((u = (
                            (u = "OS" === i[3] ? i[4] : i[3]) || ""
                          ).replace("_", ".")),
                          (s = {
                            browser: r[c[0]] || c[0],
                            bv: c[1],
                            os: "Mac OS",
                            ov: u,
                            product: "iPad",
                          }))
                        : -1 !== i[0].indexOf("Macintosh")
                        ? (s = {
                            browser: r[c[0]] || c[0],
                            bv: c[1],
                            os: "Mac OS",
                            ov: (i[5] || "").replace("_", ".").replace(")", ""),
                            product: "Macintosh",
                          })
                        : -1 !== i[0].indexOf("X11")
                        ? (s = {
                            browser: r[c[0]] || c[0],
                            bv: c[1],
                            os: "Linux X11",
                            ov: "Linux X11",
                            product: "Linux X11",
                          })
                        : -1 !== i[0].indexOf("Windows")
                        ? (s = {
                            browser: r[c[0]] || c[0],
                            bv: c[1],
                            os: "Windows",
                            ov: {
                              5: "Windows XP",
                              6: "windows 7",
                              10: "Windows 10",
                            }[parseInt(i[2] || "") || parseInt(i[4] || "")],
                            product: "Windows",
                          })
                        : -1 !== i[0].indexOf("Android")
                        ? (s = {
                            browser: r[c[0]] || c[0],
                            bv: c[1],
                            os: "Android",
                            ov: i[1].replace(";", ""),
                            product: "",
                          })
                        : -1 !== i[0].indexOf("Symbian") &&
                          (s = {
                            browser: r[c[0]] || c[0],
                            bv: c[1],
                            os: "Symbian",
                            ov: (i[0].split("/")[1] || "").replace(";", ""),
                            product: i[2].split("/")[0],
                          });
                  return (
                    s ||
                      (s = {
                        browser: "",
                        bv: "",
                        os: "",
                        ov: "",
                        product: "",
                      }),
                    (s.product = s.product || ""),
                    s
                  );
                })(e)
              : "Hisense" === (n = e.split(" "))[0]
              ? ((i = (o = n)[2].split("/")),
                (s = o[1].split("/")[0]),
                {
                  browser: (a = o[4].split("/"))[1],
                  bv: a[2],
                  os: i[0],
                  ov: i[1],
                  product: s,
                })
              : -1 !== n[0].indexOf("Xiao")
              ? (function (e) {
                  var t, r, n;
                  return (
                    1 === e.length
                      ? ((t = ["", ""]), (r = "xiaomi"), (n = e[0].split("/")))
                      : 8 === e.length
                      ? ((t = ["Android", e[1].split("/").pop()]),
                        (r = e[0].split("/")[0]),
                        (n = e.pop().split("/")))
                      : ((t = e[2].split("/")),
                        (r = e[0].split("/")[0]),
                        (n = e.pop().split("/"))),
                    { browser: n[1], bv: n[2], os: t[0], ov: t[1], product: r }
                  );
                })(n)
              : -1 !== n[0].indexOf("Xingcheweishi")
              ? {
                  browser: "",
                  bv: "",
                  os: "Xingcheweishi",
                  ov: n[0].split("/")[1],
                  product: "",
                }
              : -1 !== n[0].indexOf("MTK")
              ? (function (e) {
                  var t = e[2].split("/"),
                    r = e[0].split("/")[0],
                    n = e[5].split("/");
                  return {
                    browser: n[0],
                    bv: n[1],
                    os: t[0],
                    ov: t[1],
                    product: r,
                  };
                })(n)
              : t;
          } catch (e) {
            return t;
          }
          var o, i, s, a;
        };
      },
      910: function (e, t, r) {
        var n = r(452);
        e.exports = function () {
          return "function" == typeof n.getProvince ? n.getProvince() : "";
        };
      },
      758: function (e, t, r) {
        var n = r(502),
          o = r(447),
          i = r(900),
          s = r(28),
          a = r(285),
          u = 1e3 * o.maxResource,
          p = {},
          c = {};
        function l(e) {
          return a.errors.some(function (t) {
            return t === e;
          })
            ? 0
            : 1;
        }
        function d() {
          var e = [];
          try {
            e = window.performance.getEntriesByType("resource");
          } catch (e) {}
          for (var t, r = [], o = [], s = 0, a = e.length; s < a; s++)
            ("link" !== e[s].initiatorType &&
              "script" !== e[s].initiatorType &&
              "img" !== e[s].initiatorType) ||
              c[e[s].name] ||
              ((c[e[s].name] = !0),
              o.push({
                name: e[s].name,
                resType:
                  ((t = e[s].name),
                  t.split("?")[0].split(".").pop() || e[s].initiatorType),
                time: e[s].duration >> 0,
                netType: l(e[s].name),
              })),
              "xmlhttprequest" !== e[s].initiatorType &&
                "fetch" !== e[s].initiatorType &&
                "" !== e[s].nextHopProtocol &&
                e[s].duration > u &&
                !p[e[s].name] &&
                -1 === (e[s].name || "").indexOf("dcs.gif") &&
                -1 === (e[s].name || "").indexOf("sa.gif") &&
                ((p[e[s].name] = !0),
                r.push(e[s].name + " - " + (e[s].duration >> 0)));
          o.length &&
            i.needSendRes() &&
            n.sendBeaconWithInfo("resourse", "time", o, "resTime"),
            r.length &&
              i.needSendPerformance &&
              i.needSendError &&
              n.sendBeaconWithInfo("resourse", "slow", { msg: r }),
            setTimeout(d, 5e3);
        }
        s.bindBrowserEvent(window, "beforeunload", function () {
          d();
        });
        var f = !1;
        e.exports = {
          init: function () {
            f || ((f = !0), d());
          },
        };
      },
      541: function (e, t, r) {
        var n = 1e3 * r(447).maxResource,
          o = 0,
          i = 0,
          s = 0,
          a = 0,
          u = 0,
          p = 0,
          c = 0,
          l = !1,
          d = null;
        e.exports = {
          addError: function () {
            o++;
          },
          addAPI: function () {
            i++;
          },
          addAPIDONE: function () {
            s++;
          },
          addErrorRes: function () {
            c++;
          },
          setOnload: function (e) {
            (l = e), d && d();
          },
          getInfo: function () {
            try {
              if (window.performance.getEntries)
                for (
                  var e = performance.getEntriesByType("resource"),
                    t = 0,
                    r = e.length;
                  t < r;
                  t++
                )
                  "link" === e[t].initiatorType
                    ? (u++, e[t].duration > n && p++)
                    : "script" === e[t].initiatorType &&
                      (a++, e[t].duration > n && p++);
            } catch (e) {}
            return (
              "jsError:" +
              o +
              " api:" +
              i +
              " apiDone:" +
              s +
              " jsRes:" +
              a +
              " cssRes:" +
              u +
              " errRes:" +
              c +
              " slow:" +
              p +
              " isonload:" +
              l
            );
          },
          isonload: function () {
            return l;
          },
          setLoadCallback: function (e) {
            d = e;
          },
        };
      },
      447: function (e, t, r) {
        var n = r(452);
        e.exports = {
          maxXHR: ((n || {}).time || {}).api || 3,
          maxJsRun: ((n || {}).time || {}).jsrun || 0.5,
          maxResource: ((n || {}).time || {}).res || 2,
        };
      },
      883: function (e, t, r) {
        var n = r(452),
          o = r(817);
        function i() {
          return (
            document.title,
            (n.formatUrl
              ? "" + n.formatUrl(location.href)
              : n.usePathKey
              ? ("" + location.pathname).replace(/\/$/, "")
              : "" + location.hostname + location.pathname
            ).substring(0, 200)
          );
        }
        (n = n || {}).__versions = "1.5.6";
        var s = o(navigator.userAgent),
          a = (/leadeon\/([^\/]+)/.exec(navigator.userAgent) || ["", "0"])[1];
        e.exports = function (e) {
          var t = n.noSendDevice;
          return {
            browser: t ? "" : ("0" === a ? "" : "webview-") + (s.browser || ""),
            browserVersion: t ? "" : s.bv || "0",
            os: t ? "" : s.os || "0",
            OSVersion: t ? "" : s.ov || "0",
            appName: n.appName || "unknown",
            appVersion: n.appVersion || "0",
            clientVersion: a,
            page: i,
          };
        };
      },
      242: function (e) {
        e.exports = function () {
          var e = location.search.substring(1),
            t = {};
          return (
            e.split("&").forEach(function (e) {
              var r = e.split("=");
              t[r[0]] = r[1];
            }),
            t
          );
        };
      },
      922: function (e, t, r) {
        var n = r(452),
          o = r(534),
          i =
            (performance.timing.navigationStart ||
              performance.timing.redirectStart ||
              performance.timing.fetchStart) + "-";
        function s() {
          for (var e = "", t = 4; t--; )
            e +=
              "01234456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"[
                (63 * Math.random()) >> 0
              ];
          return e;
        }
        var a = o.getItem("cmosClientId");
        a || ((a = s()), o.setItem("cmosClientId", a)),
          (i += s()),
          (e.exports = {
            getUUID: function () {
              var e = "";
              return n.getUID
                ? ((e = n.getUID()), a + "-" + e + "-" + i)
                : a + "-" + i;
            },
          });
      },
      285: function (e, t, r) {
        var n = r(28),
          o = n.bindBrowserEvent,
          i = r(502),
          s = r(883),
          a = r(922),
          u = r(900),
          p = r(541),
          c = r(501),
          l = r(910),
          d = [],
          f = s();
        function m(e) {
          var t,
            r,
            o = e.target || e.srcElement,
            s = "",
            u = o.src || o.href;
          if (o === window) {
            var m = "",
              h = "";
            e.message || e.error
              ? ((m = e.message || (e.error || {}).message || ""),
                (h = (e.error || {}).stack || ""))
              : e.reason && e.reason.message
              ? ((m = "Uncaught (in promise) " + e.reason.message),
                (h = e.reason.stack))
              : e.reason &&
                ((m = "Uncaught (in promise) " + e.reason), (h = "")),
              (m = m.substring(0, 200)),
              window.__SKYNET.errorFilter && window.__SKYNET.errorFilter(m)
                ? (s = "")
                : "" !== m.replace(/\s+/g, "") &&
                  ((r = "9.2.0"),
                  (s =
                    "0" !== (t = f.clientVersion) &&
                    (t[0] < r[0] || t[2] < r[2] || t[4] < r[4]) &&
                    -1 !== m.indexOf("Script error")
                      ? ""
                      : JSON.stringify({
                          line: e.lineno || 0,
                          column: e.colno || 0,
                          msg: m || "",
                          fileName: e.filename || "",
                          stack: h,
                          pageName: f.page(),
                        }))),
              s &&
                (n.fire("JsError", s),
                p.addError(),
                i.send({
                  event: "error",
                  sys: f.appName,
                  sysV: f.appVersion,
                  clientV: f.clientVersion,
                  pageName: f.page(),
                  os: f.os,
                  osV: f.OSVersion,
                  browser: f.browser,
                  browserV: f.browserVersion,
                  product: f.product,
                  errorName: "JsError",
                  errorType: "runtime",
                  errorLog: s,
                  province: l(),
                  time: Date.now(),
                  uuid: a.getUUID(),
                }));
          } else
            u &&
              "mini-img-qrcode-show data:image/png;base64," !== u &&
              "mini-img-qrcode data:image/png;base64," !== u &&
              u !== location.href &&
              (i.sendBeaconWithInfo(
                o.tagName,
                "resource",
                (o.className || "") + " " + u
              ),
              c.add(u),
              d.push(u),
              (-1 === u.indexOf(".js") && -1 === u.indexOf(".css")) ||
                p.addErrorRes());
        }
        e.exports = {
          errors: d,
          catchError: function () {
            u.needSendPerformance &&
              u.needSendError &&
              (o(window, "error", m, !0),
              o(window, "unhandledrejection", m, !0));
          },
        };
      },
    },
    t = {};
  function r(n) {
    var o = t[n];
    if (void 0 !== o) return o.exports;
    var i = (t[n] = { exports: {} });
    return e[n](i, i.exports, r), i.exports;
  }
  !(function () {
    var e = r(452),
      t = r(883),
      n = r(28),
      o = r(502),
      i = r(285),
      s = r(79),
      a = r(758),
      u = r(922),
      p = r(502),
      c = r(900),
      l = r(541),
      d = r(910),
      f = r(900),
      m = n.bindBrowserEvent;
    if (!(e = e || {}).init && f.needSendPerformance) {
      var h = function () {
          var e = new Date().getTime(),
            r = w.unloadEventEnd - w.unloadEventStart,
            n = w.domainLookupStart - w.fetchStart,
            o = w.domainLookupEnd - w.domainLookupStart,
            i = w.responseStart - (w.requestStart || w.fetchStart),
            s = w.responseEnd - w.responseStart,
            a = w.connectEnd - w.connectStart,
            p = w.loadEventEnd - (w.navigationStart || w.fetchStart),
            c = w.domContentLoadedEventEnd - w.responseEnd,
            l = w.domComplete - w.responseEnd,
            f = t();
          return {
            event: "performance",
            sys: f.appName,
            pageName: f.page(),
            sysV: f.appVersion,
            clientV: f.clientVersion,
            time: e,
            fp: 0,
            fsp: 0,
            interactive: 0,
            unload: Math.max(Math.round(r, 0), 0),
            cache: Math.max(Math.round(n, 0), 0),
            tcp: Math.max(Math.round(a || 0), 0),
            dns: Math.max(Math.round(o || 0), 0),
            fb: Math.max(Math.round(i || 0), 0),
            domready: Math.max(Math.round(c || 0), 0),
            fullLoad: Math.max(Math.round(p || 0), 0),
            htmlLoad: Math.max(Math.round(s || 0), 0),
            pageRender: Math.max(Math.round(l || 0), 0),
            os: f.os,
            osV: f.OSVersion,
            browser: f.browser,
            province: d(),
            browserV: f.browserVersion,
            product: f.product,
            uuid: u.getUUID(),
          };
        },
        g = function (t, r) {
          if (!v) {
            v = !0;
            var n = r;
            n || (n = s());
            var i = h();
            (i.fp = Math.round(n.fp)),
              (i.interactive = Math.round(n.tti)),
              (i.fsp = Math.round(n.fsp)),
              (i.p1 = Math.round(n.p1 || 0)),
              (i.p2 = Math.round(n.p2 || 0)),
              (i.webview = e.webview
                ? ((w.navigationStart || w.fetchStart) - e.webview) >> 0
                : 0),
              "unload" === t
                ? ((i.sendType = "unload"), o.sendBeacon(i))
                : o.send(i);
          }
        };
      i.catchError();
      var w,
        v = !1;
      (w = window.performance && performance.timing ? performance.timing : {}),
        m(window, "load", function () {
          l.setOnload(
            (w.loadEventStart - (w.navigationStart || w.fetchStart)) >> 0
          );
        }),
        n.on("profilekeys", function (t) {
          var r = h(),
            n = null;
          r.fullLoad > 0
            ? (a.init(),
              (r.fp = Math.round(t.fp)),
              (r.interactive = Math.round(t.tti)),
              (r.fsp = Math.round(t.fsp)),
              (r.p1 = Math.round(t.p1 || 0)),
              (r.p2 = Math.round(t.p2 || 0)),
              (r.webview = e.webview
                ? ((w.navigationStart || w.fetchStart) - e.webview) >> 0
                : 0),
              (v = !0),
              o.send(r, !0))
            : (t.fp < t.fsp && (n = t),
              m(window, "load", function () {
                setTimeout(function () {
                  a.init(), g("load", n);
                }, 100);
              }));
        }),
        m(window, "beforeunload", function () {
          c.needSendPerformance && g("unload");
        }),
        (e.send = function (e, t) {
          "string" != typeof e && (e = JSON.stringify(e)),
            p.sendBeaconWithInfo("custom", t || "user", e);
        }),
        (e.sendAll = function (e, t) {
          "string" != typeof e && (e = JSON.stringify(e)),
            p.sendBeaconWithInfoAll("custom", t || "user", e);
        }),
        (e.init = !0),
        (e.fire = n.fire);
    }
  })();
})();
